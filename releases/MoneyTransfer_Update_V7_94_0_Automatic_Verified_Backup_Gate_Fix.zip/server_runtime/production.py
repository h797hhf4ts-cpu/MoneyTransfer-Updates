# -*- coding: utf-8 -*-
"""Production-readiness helpers for MoneyTransfer V7.60.
This module does not silently switch the live database. PostgreSQL activation is a separate installer/migration step.
"""
from pathlib import Path
from datetime import datetime
import hashlib, json, os, sqlite3, uuid, shutil
from sqlalchemy import text
from .config import DATA_DIR, load_config
from .database import engine, DATABASE_URL, DATABASE_BACKEND, database_ping

BACKUP_DIR = DATA_DIR / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)
INSTALLATION_FILE = DATA_DIR / "installation.json"

def _installation_info():
    data={}
    if INSTALLATION_FILE.exists():
        try: data=json.loads(INSTALLATION_FILE.read_text(encoding="utf-8-sig"))
        except Exception: data={}
    if not data.get("installation_id"):
        data={"installation_id": str(uuid.uuid4()), "created_at": datetime.utcnow().isoformat(timespec="seconds")+"Z"}
        INSTALLATION_FILE.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    return data

def _sqlite_path():
    if not DATABASE_URL.startswith("sqlite:///"): return None
    return Path(DATABASE_URL[len("sqlite:///"):])

def _sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()

def migration_status():
    try:
        with engine.connect() as c:
            rows=c.execute(text("SELECT version,name,applied_at FROM schema_migrations ORDER BY version")).mappings().all()
        return [dict(r) for r in rows]
    except Exception:
        return []

def create_server_backup(reason="manual"):
    """Create an atomic, verified SQLite backup from the *live engine connection*.

    V7.94 deliberately avoids reopening DATABASE_URL as a filesystem path. That
    removes Windows drive/path parsing differences and guarantees the backup is
    taken from the same live database connection used by the API server.
    """
    if DATABASE_BACKEND != "sqlite":
        raise RuntimeError("النسخ الداخلي الحالي مخصص لـ SQLite. PostgreSQL سيستخدم pg_dump في مرحلة التثبيت الإنتاجي.")
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    safe_reason="".join(ch if (ch.isalnum() or ch in "-_") else "-" for ch in str(reason or "manual"))[:48] or "manual"
    dst=BACKUP_DIR/f"server_{stamp}_{safe_reason}.db"
    tmp=dst.with_suffix(".db.tmp")
    raw=None; target=None
    try:
        raw=engine.raw_connection()
        source=getattr(raw, "driver_connection", None) or getattr(raw, "connection", None)
        if source is None or not isinstance(source, sqlite3.Connection):
            raise RuntimeError("تعذر الوصول إلى اتصال SQLite الحي لإنشاء النسخة الاحتياطية.")
        target=sqlite3.connect(str(tmp), timeout=30)
        source.backup(target)
        target.commit()
        chk=target.execute("PRAGMA integrity_check").fetchone()[0]
        if chk!="ok":
            raise RuntimeError("فشل integrity_check للنسخة: "+str(chk))
        target.close(); target=None
        os.replace(tmp, dst)
    finally:
        try:
            if target is not None: target.close()
        except Exception: pass
        try:
            if raw is not None: raw.close()
        except Exception: pass
        try:
            if tmp.exists(): tmp.unlink()
        except Exception: pass
    digest=_sha256(dst)
    dst.with_suffix(dst.suffix+".sha256").write_text(digest+"  "+dst.name+"\n",encoding="utf-8")
    # Final verification from a fresh read-only connection before reporting success.
    verified=verify_backup(dst.name)
    if not verified.get("ok"):
        try: dst.unlink(missing_ok=True); dst.with_suffix(dst.suffix+".sha256").unlink(missing_ok=True)
        except Exception: pass
        raise RuntimeError("فشل التحقق النهائي من النسخة الاحتياطية: "+str(verified.get("detail","")))
    cfg=load_config(); keep=max(5,min(200,int(cfg.get("backup_retention_count",30) or 30)))
    files=sorted(BACKUP_DIR.glob("server_*.db"),key=lambda x:x.stat().st_mtime,reverse=True)
    for old in files[keep:]:
        try:
            old.unlink(missing_ok=True); old.with_suffix(old.suffix+".sha256").unlink(missing_ok=True)
        except Exception: pass
    return {"file":dst.name,"sha256":digest,"size":dst.stat().st_size,"created_at":datetime.now().isoformat(timespec="seconds"),"reason":reason,"directory":str(BACKUP_DIR),"verified":True}

def list_backups(limit=50):
    out=[]
    for f in sorted(BACKUP_DIR.glob("server_*.db"),key=lambda x:x.stat().st_mtime,reverse=True)[:max(1,min(200,int(limit)))]:
        side=f.with_suffix(f.suffix+".sha256")
        expected=""
        try: expected=side.read_text(encoding="utf-8").split()[0]
        except Exception: pass
        out.append({"file":f.name,"size":f.stat().st_size,"modified_at":datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds"),"sha256":expected})
    return out


def verify_backup(filename):
    """Read-only verification of a backup created by create_server_backup."""
    name=Path(str(filename or "")).name
    if not name or name != str(filename or "") or not name.startswith("server_") or not name.endswith(".db"):
        return {"ok":False,"detail":"invalid backup name"}
    f=BACKUP_DIR/name
    if not f.is_file(): return {"ok":False,"detail":"backup file missing"}
    side=f.with_suffix(f.suffix+".sha256")
    try:
        expected=side.read_text(encoding="utf-8").split()[0]
    except Exception:
        return {"ok":False,"detail":f"{name}: SHA-256 sidecar missing"}
    actual=_sha256(f)
    if expected.lower()!=actual.lower():
        return {"ok":False,"detail":f"{name}: SHA-256 mismatch"}
    try:
        con=sqlite3.connect(f"file:{f.as_posix()}?mode=ro",uri=True,timeout=10)
        try: chk=con.execute("PRAGMA integrity_check").fetchone()[0]
        finally: con.close()
    except Exception as exc:
        return {"ok":False,"detail":f"{name}: integrity check error: {exc}"}
    if chk!="ok": return {"ok":False,"detail":f"{name}: integrity_check={chk}"}
    return {"ok":True,"detail":f"{name}: SHA-256 + integrity_check OK"}

def readiness():
    cfg=load_config(); ok, detail=database_ping(); src=_sqlite_path()
    driver=False
    try:
        import psycopg  # noqa
        driver=True
    except Exception:
        try:
            import psycopg2  # noqa
            driver=True
        except Exception: pass
    checks=[
      {"key":"database","ok":ok,"detail":detail},
      {"key":"migrations","ok":bool(migration_status()),"detail":f"{len(migration_status())} migrations"},
      {"key":"backup_folder","ok":BACKUP_DIR.exists(),"detail":str(BACKUP_DIR)},
      {"key":"private_remote_mode","ok":cfg.get("remote_access_mode","private_network")=="private_network","detail":cfg.get("remote_access_mode","private_network")},
      {"key":"jwt_secret","ok":len(str(cfg.get("jwt_secret","")))>=32,"detail":"configured" if len(str(cfg.get("jwt_secret","")))>=32 else "weak/missing"},
    ]
    if DATABASE_BACKEND=="sqlite":
        checks.append({"key":"sqlite_integrity","ok":bool(src and src.exists()),"detail":str(src) if src else "-"})
    return {
      "ready_for_current_single_server": all(x["ok"] for x in checks),
      "database_backend":DATABASE_BACKEND,
      "postgresql_driver_available":driver,
      "postgresql_activation":"requires dedicated Setup/migration; not automatically enabled by this ZIP",
      "production_mode":bool(cfg.get("production_mode",False)),
      "remote_access_mode":cfg.get("remote_access_mode","private_network"),
      "checks":checks,
      "migration_history":migration_status(),
      "backup_count":len(list_backups(200)),
      "installation":_installation_info(),
    }

def license_foundation():
    ins=_installation_info(); cfg=load_config()
    return {"installation_id":ins["installation_id"],"mode":cfg.get("license_mode","foundation"),"status":"not_enforced","commercial_activation_ready":False,"note":"License enforcement will be activated only after a signed licensing service is introduced."}


from pathlib import Path
import json, secrets, os

BASE_DIR = Path(__file__).resolve().parent
# Production installer keeps mutable server data outside the program files.
# Fallback keeps backward compatibility for portable/development runs.
_data_override = os.environ.get("MONEYTRANSFER_SERVER_DATA_DIR", "").strip()
DATA_DIR = Path(_data_override).expanduser().resolve() if _data_override else (BASE_DIR / "data")
DATA_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_FILE = DATA_DIR / "server_config.json"

DEFAULT_CONFIG = {
    "server_name": "MoneyTransfer Local Server",
    "host": "0.0.0.0",
    "port": 8765,
    "database_url": "sqlite:///__SERVER_DATA__/server.db",
    "jwt_secret": "",
    "token_hours": 12,
    "allow_remote": True,
    "database_backend": "sqlite",
    "production_mode": False,
    "remote_access_mode": "private_network",
    "backup_retention_count": 30,
    "license_mode": "foundation",
}

def load_config():
    if CONFIG_FILE.exists():
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    else:
        data = dict(DEFAULT_CONFIG)

    changed = False
    for k, v in DEFAULT_CONFIG.items():
        if k not in data:
            data[k] = v
            changed = True

    if not data.get("jwt_secret"):
        data["jwt_secret"] = secrets.token_urlsafe(48)
        changed = True

    if changed or not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    # اجعل مسار SQLite محلياً داخل مجلد server/data مهما كان مجلد التشغيل الحالي.
    if str(data.get("database_url", "")).startswith("sqlite:///__SERVER_DATA__/"):
        filename = str(data["database_url"]).split("sqlite:///__SERVER_DATA__/", 1)[1]
        data["database_url"] = "sqlite:///" + str((DATA_DIR / filename).resolve()).replace("\\", "/")
    return data

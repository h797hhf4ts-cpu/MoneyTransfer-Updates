
from fastapi import FastAPI, Depends, HTTPException, Header, Query
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import json
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from .database import get_db
from .models import User, Account, Customer, Transaction, LedgerEntry, AuditLog, Shift, ShiftBalance, Device
from .schemas import (
    LoginIn, TokenOut, AccountOut, AccountCreate, CustomerOut,
    TransactionCreate, TransactionOut,
    SyncPushIn, SyncPushOut, SyncPushItemResult, TransactionReverseIn, TransactionEditIn, AuditOut,
    ShiftCurrentOut, ShiftAccountSnapshotOut, ShiftCloseIn, ShiftOut, ShiftBalanceOut,
    DeviceRegisterIn, DeviceOut, MobileSyncPushIn, MobileSyncPullOut, MeOut,
)
from .security import verify_password, create_token, decode_token
from .services.transaction_service import create_transaction, reverse_transaction, edit_transaction_server
from .seed import init_server_db
from .migrations import apply_migrations


def _load_server_version_info():
    defaults = {
        "app_version": "7.29.1",
        "api_compatibility": "7.26.2",
        "runtime_version": "7.29.1",
        "schema_version": 5,
        "channel": "Stable",
    }
    try:
        version_path = Path(__file__).resolve().parent.parent / "version.json"
        data = json.loads(version_path.read_text(encoding="utf-8-sig"))
        if isinstance(data, dict):
            defaults.update({k: data[k] for k in defaults if k in data})
    except Exception:
        pass
    return defaults

SERVER_VERSION_INFO = _load_server_version_info()
APP_VERSION = str(SERVER_VERSION_INFO["app_version"])
API_COMPAT_VERSION = str(SERVER_VERSION_INFO["api_compatibility"])
RUNTIME_VERSION = str(SERVER_VERSION_INFO["runtime_version"])
SCHEMA_VERSION = int(SERVER_VERSION_INFO["schema_version"])

app = FastAPI(
    title="MoneyTransfer Server API",
    version=API_COMPAT_VERSION,
    description="Local-first API for Windows / Android / iOS clients."
)

@app.middleware("http")
async def no_cache_mobile(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith("/mobile"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

MOBILE_WEB_DIR = Path(__file__).resolve().parent.parent / "mobile_web"
if MOBILE_WEB_DIR.exists():
    app.mount("/mobile", StaticFiles(directory=str(MOBILE_WEB_DIR), html=True), name="mobile")

@app.on_event("startup")
def startup():
    init_server_db()
    apply_migrations()

def current_user(
    authorization: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
    except Exception:
        raise HTTPException(401, "Invalid or expired token")

    user = db.get(User, int(payload["sub"]))
    if not user or not user.active:
        raise HTTPException(401, "User disabled")
    return user

def require_admin(user: User = Depends(current_user)):
    if user.role != "admin":
        raise HTTPException(403, "Admin only")
    return user

def jod_text(fils: int) -> str:
    return f"{fils / 1000:,.3f}"

@app.get("/api/v1/health")
def health():
    return {
        "ok": True,
        "server": "MoneyTransfer",
        "api_version": API_COMPAT_VERSION,
        "runtime_version": RUNTIME_VERSION,
        "pid": __import__("os").getpid(),
        "external_runtime": True,
        "offline_first_ready": True,
    }

@app.post("/api/v1/auth/login", response_model=TokenOut)
def login(payload: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(
        select(User).where(
            User.username == payload.username,
            User.active == True
        )
    )
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid username or password")

    return TokenOut(
        access_token=create_token(user.id, user.username, user.role),
        role=user.role,
        username=user.username,
    )

@app.get("/api/v1/accounts", response_model=list[AccountOut])
def list_accounts(
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    rows = db.scalars(
        select(Account).where(Account.active == True).order_by(Account.id)
    ).all()
    return [
        AccountOut(
            id=a.id,
            name=a.name,
            account_type=a.account_type,
            balance_fils=a.balance_fils,
            balance_jod=jod_text(a.balance_fils),
            active=a.active,
        )
        for a in rows
    ]

@app.post("/api/v1/accounts", response_model=AccountOut)
def create_account(
    payload: AccountCreate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    exists = db.scalar(select(Account).where(Account.name == payload.name))
    if exists:
        raise HTTPException(409, "Account name already exists")

    acc = Account(
        name=payload.name,
        account_type=payload.account_type,
        balance_fils=payload.opening_balance_fils,
        warning_limit_fils=payload.warning_limit_fils,
        active=True,
    )
    db.add(acc)
    db.commit()
    db.refresh(acc)

    return AccountOut(
        id=acc.id,
        name=acc.name,
        account_type=acc.account_type,
        balance_fils=acc.balance_fils,
        balance_jod=jod_text(acc.balance_fils),
        active=acc.active,
    )


@app.get("/api/v1/customers", response_model=list[CustomerOut])
def list_customers(
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    rows = db.scalars(
        select(Customer).where(Customer.active == True).order_by(Customer.name)
    ).all()
    return [
        CustomerOut(
            id=c.id,
            name=c.name,
            phone=c.phone or "",
            address=c.address or "",
            notes=c.notes or "",
            debt_balance_fils=c.debt_balance_fils,
            debt_balance_jod=jod_text(c.debt_balance_fils),
            debt_limit_fils=c.debt_limit_fils,
            debt_limit_jod=jod_text(c.debt_limit_fils),
            active=c.active,
        )
        for c in rows
    ]

@app.get("/api/v1/transactions", response_model=list[TransactionOut])
def list_transactions(
    limit: int = Query(default=100, ge=1, le=1000),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    rows = db.scalars(
        select(Transaction)
        .order_by(Transaction.id.desc())
        .limit(limit)
    ).all()
    return [
        TransactionOut(
            id=t.id,
            client_tx_id=t.client_tx_id,
            created_at=t.created_at,
            op_type=t.op_type,
            amount_fils=t.amount_fils,
            commission_fils=t.commission_fils,
            status=t.status,
            details=t.details,
        )
        for t in rows
    ]

@app.post("/api/v1/transactions", response_model=TransactionOut)
def post_transaction(
    payload: TransactionCreate,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    try:
        tx, state = create_transaction(db, payload, user.id)
    except ValueError as exc:
        db.rollback()
        raise HTTPException(400, str(exc))

    return TransactionOut(
        id=tx.id,
        client_tx_id=tx.client_tx_id,
        created_at=tx.created_at,
        op_type=tx.op_type,
        amount_fils=tx.amount_fils,
        commission_fils=tx.commission_fils,
        status=tx.status,
        details=tx.details,
    )

@app.post("/api/v1/sync/push", response_model=SyncPushOut)
def sync_push(
    payload: SyncPushIn,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    results = []
    for item in payload.items[:200]:
        try:
            tx, state = create_transaction(db, item, user.id)
            results.append(SyncPushItemResult(
                client_tx_id=item.client_tx_id,
                status="duplicate" if state == "duplicate" else "created",
                transaction_id=tx.id,
                message="Already synced" if state == "duplicate" else "Stored on server"
            ))
        except Exception as exc:
            db.rollback()
            results.append(SyncPushItemResult(
                client_tx_id=item.client_tx_id,
                status="rejected",
                message=str(exc)
            ))
    return SyncPushOut(results=results)

@app.get("/api/v1/sync/pull", response_model=list[TransactionOut])
def sync_pull(
    after_id: int = Query(default=0, ge=0),
    limit: int = Query(default=200, ge=1, le=1000),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    """إرجاع العمليات التي رقمها أكبر من آخر رقم وصل للجهاز العميل."""
    rows = db.scalars(
        select(Transaction)
        .where(Transaction.id > after_id)
        .order_by(Transaction.id.asc())
        .limit(limit)
    ).all()
    return [
        TransactionOut(
            id=t.id,
            client_tx_id=t.client_tx_id,
            created_at=t.created_at,
            op_type=t.op_type,
            amount_fils=t.amount_fils,
            commission_fils=t.commission_fils,
            status=t.status,
            details=t.details,
        )
        for t in rows
    ]

@app.get("/api/v1/system/update-info")
def system_update_info(user: User = Depends(current_user)):
    """Stable metadata endpoint used by desktop/mobile update managers."""
    return {
        "product": "MoneyTransfer",
        "app_version": APP_VERSION,
        "api_version": API_COMPAT_VERSION,
        "runtime_version": RUNTIME_VERSION,
        "schema_version": SCHEMA_VERSION,
        "update_channel": "stable",
        "update_architecture": "manifest-v1",
        "supports_staged_updates": True,
        "supports_database_migrations": True,
    }

@app.get("/api/v1/capabilities")
def capabilities(user: User = Depends(current_user)):
    return {
        "server_is_authority": True,
        "offline_clients_supported": True,
        "currency": "JOD",
        "currency_decimals": 3,
        "client_tx_id_required": True,
        "desktop_supported": True,
        "android_supported": True,
        "ios_supported": True,
        "server_authoritative_operations": ["حوالة صادرة", "حوالة واردة", "دفع فاتورة", "نقل أموال", "بيع بطاقة خلوية", "سحب مالي", "دين للعميل", "سداد دين"],
        "server_authoritative_actions": ["create", "reverse", "edit", "audit", "shift_close", "reconciliation", "reports", "account_statement"],
    }


@app.post("/api/v1/transactions/{tx_id}/reverse", response_model=TransactionOut)
def reverse_tx(tx_id: int, payload: TransactionReverseIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    try:
        old, rev = reverse_transaction(db, tx_id, payload.reason.strip(), user.id)
    except ValueError as exc:
        db.rollback(); raise HTTPException(400, str(exc))
    return TransactionOut(id=rev.id,client_tx_id=rev.client_tx_id,created_at=rev.created_at,op_type=rev.op_type,amount_fils=rev.amount_fils,commission_fils=rev.commission_fils,status=rev.status,details=rev.details)

@app.post("/api/v1/transactions/{tx_id}/edit", response_model=TransactionOut)
def edit_tx(tx_id: int, payload: TransactionEditIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    try:
        old,newtx=edit_transaction_server(db,tx_id,payload.replacement,payload.reason.strip(),user.id)
    except ValueError as exc:
        db.rollback(); raise HTTPException(400,str(exc))
    return TransactionOut(id=newtx.id,client_tx_id=newtx.client_tx_id,created_at=newtx.created_at,op_type=newtx.op_type,amount_fils=newtx.amount_fils,commission_fils=newtx.commission_fils,status=newtx.status,details=newtx.details)

@app.get("/api/v1/audit", response_model=list[AuditOut])
def audit(limit:int=Query(default=200,ge=1,le=1000), user:User=Depends(current_user), db:Session=Depends(get_db)):
    if user.role != "admin": raise HTTPException(403,"Admin only")
    rows=db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)).all()
    out=[]
    for a in rows:
        u=db.get(User,a.user_id) if a.user_id else None
        out.append(AuditOut(id=a.id,created_at=a.created_at,username=u.username if u else "",action=a.action,transaction_id=a.transaction_id,details=a.details))
    return out


def _shift_commission_fils(db: Session, shift_id: int) -> int:
    value = db.scalar(
        select(func.coalesce(func.sum(Transaction.commission_fils), 0)).where(
            Transaction.shift_id == shift_id,
            Transaction.status == "active",
        )
    )
    return int(value or 0)

@app.get("/api/v1/shifts/current", response_model=ShiftCurrentOut)
def current_shift(user: User = Depends(current_user), db: Session = Depends(get_db)):
    shift = db.scalar(select(Shift).where(Shift.status == "open").order_by(Shift.id.desc()))
    if not shift:
        raise HTTPException(404, "No open shift")
    accounts = db.scalars(select(Account).where(Account.active == True).order_by(Account.id)).all()
    program_total = sum(int(a.balance_fils) for a in accounts)
    commission = _shift_commission_fils(db, shift.id)
    return ShiftCurrentOut(
        id=shift.id, business_date=shift.business_date, started_at=shift.started_at,
        status=shift.status, total_commission_fils=commission,
        total_commission_jod=jod_text(commission), program_total_fils=program_total,
        program_total_jod=jod_text(program_total),
        accounts=[ShiftAccountSnapshotOut(
            account_id=a.id, account_name=a.name,
            system_balance_fils=int(a.balance_fils), system_balance_jod=jod_text(int(a.balance_fils))
        ) for a in accounts]
    )

@app.post("/api/v1/shifts/{shift_id}/close", response_model=ShiftOut)
def close_shift(shift_id: int, payload: ShiftCloseIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    shift = db.get(Shift, shift_id)
    if not shift or shift.status != "open":
        raise HTTPException(400, "Shift is not open or was already closed")

    active_accounts = db.scalars(select(Account).where(Account.active == True).order_by(Account.id)).all()
    account_map = {a.id: a for a in active_accounts}
    submitted = {int(x.account_id): x for x in payload.accounts}
    if set(submitted) != set(account_map):
        raise HTTPException(400, "Reconciliation must include every active account exactly once")

    db.query(ShiftBalance).filter(ShiftBalance.shift_id == shift.id).delete()
    program_total = 0
    actual_total = 0
    balances = []
    for account_id, acc in account_map.items():
        item = submitted[account_id]
        system_fils = int(acc.balance_fils)
        actual_fils = int(item.actual_balance_fils)
        diff = actual_fils - system_fils
        reason = item.reason.strip()
        if diff != 0 and not reason:
            raise HTTPException(400, f"Reason required for account '{acc.name}'")
        row = ShiftBalance(
            shift_id=shift.id, account_id=acc.id,
            system_balance_fils=system_fils, actual_balance_fils=actual_fils,
            difference_fils=diff, reason=reason,
        )
        db.add(row)
        program_total += system_fils
        actual_total += actual_fils
        balances.append((acc, system_fils, actual_fils, diff, reason))

    now = __import__('datetime').datetime.now()
    commission = _shift_commission_fils(db, shift.id)
    shift.ended_at = now
    shift.status = "closed"
    shift.total_commission_fils = commission
    shift.program_total_fils = program_total
    shift.actual_total_fils = actual_total
    shift.difference_fils = actual_total - program_total
    db.add(AuditLog(
        user_id=user.id, action="shift_close", transaction_id=None,
        details=f"shift={shift.id} | difference_fils={shift.difference_fils}"
    ))
    new_shift = Shift(
        business_date=now.strftime("%Y-%m-%d"), started_at=now, status="open"
    )
    db.add(new_shift)
    db.commit()
    db.refresh(shift)
    return ShiftOut(
        id=shift.id, business_date=shift.business_date, started_at=shift.started_at,
        ended_at=shift.ended_at, status=shift.status,
        total_commission_fils=int(shift.total_commission_fils),
        program_total_fils=int(shift.program_total_fils),
        actual_total_fils=int(shift.actual_total_fils),
        difference_fils=int(shift.difference_fils),
        balances=[ShiftBalanceOut(
            account_id=a.id, account_name=a.name, system_balance_fils=sysf,
            actual_balance_fils=actf, difference_fils=diff, reason=reason
        ) for a,sysf,actf,diff,reason in balances]
    )

@app.get("/api/v1/shifts", response_model=list[ShiftOut])
def shift_history(limit: int = Query(default=100, ge=1, le=500), user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Shift).where(Shift.status == "closed").order_by(Shift.id.desc()).limit(limit)).all()
    result=[]
    for shift in rows:
        bs=db.scalars(select(ShiftBalance).where(ShiftBalance.shift_id == shift.id).order_by(ShiftBalance.id)).all()
        bal_out=[]
        for b in bs:
            a=db.get(Account,b.account_id)
            bal_out.append(ShiftBalanceOut(
                account_id=b.account_id, account_name=a.name if a else str(b.account_id),
                system_balance_fils=int(b.system_balance_fils), actual_balance_fils=int(b.actual_balance_fils),
                difference_fils=int(b.difference_fils), reason=b.reason or ""))
        result.append(ShiftOut(
            id=shift.id,business_date=shift.business_date,started_at=shift.started_at,ended_at=shift.ended_at,status=shift.status,
            total_commission_fils=int(shift.total_commission_fils),program_total_fils=int(shift.program_total_fils),
            actual_total_fils=int(shift.actual_total_fils),difference_fils=int(shift.difference_fils),balances=bal_out))
    return result


# ===== V7.8 server-authoritative reports / statements =====
def _parse_report_dt(value: str, end: bool = False):
    from datetime import datetime
    value=(value or '').strip()
    if not value:
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S','%Y-%m-%dT%H:%M:%S','%Y-%m-%d'):
        try:
            dt=datetime.strptime(value,fmt)
            if fmt=='%Y-%m-%d' and end:
                dt=dt.replace(hour=23,minute=59,second=59)
            return dt
        except ValueError:
            pass
    raise HTTPException(400,'Invalid date; use YYYY-MM-DD or YYYY-MM-DD HH:MM:SS')

@app.get('/api/v1/reports/summary')
def report_summary(
    date_from: str = Query(default=''), date_to: str = Query(default=''),
    user: User = Depends(current_user), db: Session = Depends(get_db),
):
    start=_parse_report_dt(date_from,False); end=_parse_report_dt(date_to,True)
    stmt=select(Transaction).where(Transaction.status=='active')
    if start is not None: stmt=stmt.where(Transaction.created_at>=start)
    if end is not None: stmt=stmt.where(Transaction.created_at<=end)
    rows=list(db.scalars(stmt.order_by(Transaction.created_at,Transaction.id)).all())
    # V7.9.0: separate commercial activity from accounting-only movements.
    accounting_only = {"تسوية رصيد", "رصيد افتتاحي", "مطابقة وردية"}
    correction_prefixes = ("عكس:", "عكس: ")
    groups={}
    business_rows=[]
    accounting_rows=[]
    correction_rows=[]
    for t in rows:
        is_accounting = t.op_type in accounting_only
        is_correction = any((t.op_type or "").startswith(p) for p in correction_prefixes)
        category = "accounting" if is_accounting else ("correction" if is_correction else "business")
        g=groups.setdefault(t.op_type,{'op_type':t.op_type,'category':category,'count':0,'amount_fils':0,'commission_fils':0})
        g['count']+=1
        g['amount_fils']+=int(t.amount_fils or 0)
        g['commission_fils']+=int(t.commission_fils or 0)
        if is_accounting: accounting_rows.append(t)
        elif is_correction: correction_rows.append(t)
        else: business_rows.append(t)
    # Net profit must include correction/reversal commission so cancelled commission is removed.
    net_commission = sum(int(t.commission_fils or 0) for t in rows if t.op_type not in accounting_only)
    return {
        'source':'server',
        'business_count':len(business_rows),
        'business_amount_fils':sum(int(t.amount_fils or 0) for t in business_rows),
        'net_commission_fils':net_commission,
        'accounting_count':len(accounting_rows),
        'accounting_amount_fils':sum(int(t.amount_fils or 0) for t in accounting_rows),
        'correction_count':len(correction_rows),
        # Backward-compatible fields for older clients.
        'count':len(rows),
        'amount_fils':sum(int(t.amount_fils or 0) for t in rows),
        'commission_fils':net_commission,
        'groups':sorted(groups.values(),key=lambda x:(x.get('category',''),x['op_type']))
    }

@app.get('/api/v1/reports/account-statement')
def account_statement(
    accounts: str = Query(default=''),
    user: User = Depends(current_user), db: Session = Depends(get_db),
):
    wanted=[x.strip() for x in accounts.split('|') if x.strip()]
    q=select(Account).where(Account.active==True)
    if wanted: q=q.where(Account.name.in_(wanted))
    accs=list(db.scalars(q.order_by(Account.id)).all())
    result=[]
    for acc in accs:
        entries=list(db.execute(
            select(LedgerEntry,Transaction)
            .join(Transaction,Transaction.id==LedgerEntry.transaction_id)
            .where(LedgerEntry.account_id==acc.id,Transaction.status=='active')
            .order_by(Transaction.created_at,Transaction.id,LedgerEntry.id)
        ).all())
        total_delta=sum(int(e.amount_fils) for e,t in entries)
        running=int(acc.balance_fils)-total_delta
        moves=[]
        for e,t in entries:
            delta=int(e.amount_fils); before=running; after=before+delta; running=after
            # Commission is shown only when this ledger row is explicitly tagged as commission.
            comm=int(t.commission_fils or 0) if e.entry_type=='commission' else 0
            moves.append({
                'account':acc.name,'id':t.id,'time':t.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'op':t.op_type,'details':t.details or '',
                'before_fils':before,'out_fils':(-delta if delta<0 else 0),
                'in_fils':(delta if delta>0 else 0),'commission_fils':comm,
                'net_fils':delta,'after_fils':after,'entry_type':e.entry_type,
            })
        result.append({'account':acc.name,'current_balance_fils':int(acc.balance_fils),'movements':moves})
    return {'source':'server','accounts':result}


# ===== PHASE 2 MOBILE API V7.12 =====
@app.get("/api/v2/session/me", response_model=MeOut)
def mobile_me(user: User = Depends(current_user)):
    from datetime import datetime
    return MeOut(user_id=user.id, username=user.username, role=user.role, server_time=datetime.now())

@app.post("/api/v2/devices/register", response_model=DeviceOut)
def register_device(payload: DeviceRegisterIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    from datetime import datetime
    d=db.scalar(select(Device).where(Device.device_id==payload.device_id))
    if d is None:
        d=Device(device_id=payload.device_id,user_id=user.id,platform=payload.platform,
                 device_name=payload.device_name,app_version=payload.app_version,
                 last_tx_cursor=0,active=True)
        db.add(d)
    else:
        if not d.active: raise HTTPException(403,"Device disabled")
        d.user_id=user.id; d.platform=payload.platform; d.device_name=payload.device_name
        d.app_version=payload.app_version; d.last_seen_at=datetime.now()
    db.commit(); db.refresh(d)
    return DeviceOut(device_id=d.device_id,platform=d.platform,device_name=d.device_name,
                     app_version=d.app_version,last_tx_cursor=int(d.last_tx_cursor or 0),active=bool(d.active))

def _mobile_device(db: Session, device_id: str, user: User):
    from datetime import datetime
    d=db.scalar(select(Device).where(Device.device_id==device_id))
    if d is None: raise HTTPException(404,"Device not registered")
    if not d.active: raise HTTPException(403,"Device disabled")
    if d.user_id not in (None,user.id): raise HTTPException(403,"Device belongs to another user")
    d.user_id=user.id; d.last_seen_at=datetime.now(); return d

@app.post("/api/v2/sync/push", response_model=SyncPushOut)
def mobile_sync_push(payload: MobileSyncPushIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d=_mobile_device(db,payload.device_id,user)
    results=[]
    for item in payload.items[:200]:
        try:
            tx,state=create_transaction(db,item,user.id)
            results.append(SyncPushItemResult(client_tx_id=item.client_tx_id,
                status="duplicate" if state=="duplicate" else "created", transaction_id=tx.id,
                message="Already synced" if state=="duplicate" else "Stored on server"))
        except Exception as exc:
            db.rollback()
            # reload after rollback so device metadata stays usable
            d=_mobile_device(db,payload.device_id,user)
            results.append(SyncPushItemResult(client_tx_id=item.client_tx_id,status="rejected",message=str(exc)))
    db.commit()
    return SyncPushOut(results=results)

@app.get("/api/v2/sync/pull", response_model=MobileSyncPullOut)
def mobile_sync_pull(device_id: str, after_id: int = Query(default=0,ge=0),
                     limit: int = Query(default=200,ge=1,le=1000),
                     user: User = Depends(current_user), db: Session = Depends(get_db)):
    d=_mobile_device(db,device_id,user)
    rows=list(db.scalars(select(Transaction).where(Transaction.id>after_id).order_by(Transaction.id.asc()).limit(limit+1)).all())
    has_more=len(rows)>limit; rows=rows[:limit]
    cursor=rows[-1].id if rows else after_id
    if cursor>int(d.last_tx_cursor or 0): d.last_tx_cursor=cursor
    db.commit()
    out=[TransactionOut(id=t.id,client_tx_id=t.client_tx_id,created_at=t.created_at,op_type=t.op_type,
         amount_fils=t.amount_fils,commission_fils=t.commission_fils,status=t.status,details=t.details) for t in rows]
    return MobileSyncPullOut(server_cursor=cursor,has_more=has_more,transactions=out)

@app.get("/api/v2/mobile/bootstrap")
def mobile_bootstrap(device_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d=_mobile_device(db,device_id,user)
    accounts=db.scalars(select(Account).where(Account.active==True).order_by(Account.id)).all()
    customers=db.scalars(select(Customer).where(Customer.active==True).order_by(Customer.name)).all()
    shift=db.scalar(select(Shift).where(Shift.status=="open").order_by(Shift.id.desc()))
    max_tx=int(db.scalar(select(func.coalesce(func.max(Transaction.id),0))) or 0)
    db.commit()
    return {
      "api_version":"7.22.0","currency":"JOD","currency_decimals":3,"server_cursor":max_tx,
      "user":{"id":user.id,"username":user.username,"role":user.role},
      "device":{"device_id":d.device_id,"platform":d.platform},
      "shift":None if not shift else {"id":shift.id,"business_date":shift.business_date,"started_at":shift.started_at,"status":shift.status},
      "accounts":[{"id":a.id,"name":a.name,"type":a.account_type,"balance_fils":int(a.balance_fils)} for a in accounts],
      "customers":[{"id":c.id,"name":c.name,"debt_balance_fils":int(c.debt_balance_fils),"debt_limit_fils":int(c.debt_limit_fils)} for c in customers],
      "sync":{"push":"/api/v2/sync/push","pull":"/api/v2/sync/pull","max_batch":200}
    }

@app.get("/api/v2/mobile/health")
def mobile_health():
    return {"ok":True,"api_version":"7.22.0","phase":2,"mobile_sync_ready":True}

# ===== PHASE 2 COMPLETE MOBILE API V7.20 =====
def _mobile_tx_dict(db: Session, t: Transaction):
    entries=list(db.scalars(select(LedgerEntry).where(LedgerEntry.transaction_id==t.id).order_by(LedgerEntry.id)).all())
    moves=[]
    for e in entries:
        a=db.get(Account,e.account_id)
        moves.append({
            "account_id":e.account_id,
            "account_name":a.name if a else str(e.account_id),
            "amount_fils":int(e.amount_fils),
            "entry_type":e.entry_type,
        })
    u=db.get(User,t.performed_by_id) if t.performed_by_id else None
    c=db.get(Customer,t.customer_id) if t.customer_id else None
    return {
        "id":t.id,"client_tx_id":t.client_tx_id,"created_at":t.created_at,
        "op_type":t.op_type,"amount_fils":int(t.amount_fils),
        "commission_fils":int(t.commission_fils or 0),"status":t.status,
        "details":t.details or "","performed_by":u.username if u else "",
        "shift_id":t.shift_id,"customer_id":t.customer_id,
        "customer_name":c.name if c else "","movements":moves,
    }

@app.get('/api/v2/mobile/transactions')
def mobile_transactions(
    limit:int=Query(default=100,ge=1,le=1000),
    status:str=Query(default=''),
    op_type:str=Query(default=''),
    date_from:str=Query(default=''),
    date_to:str=Query(default=''),
    user:User=Depends(current_user), db:Session=Depends(get_db),
):
    q=select(Transaction)
    if status.strip(): q=q.where(Transaction.status==status.strip())
    if op_type.strip(): q=q.where(Transaction.op_type==op_type.strip())
    if date_from.strip():
        start=_parse_report_dt(date_from,False)
        if start is not None: q=q.where(Transaction.created_at>=start)
    if date_to.strip():
        end=_parse_report_dt(date_to,True)
        if end is not None: q=q.where(Transaction.created_at<=end)
    rows=list(db.scalars(q.order_by(Transaction.id.desc()).limit(limit)).all())
    return {"items":[_mobile_tx_dict(db,t) for t in rows],"count":len(rows)}

@app.get('/api/v2/mobile/account-statement')
def mobile_account_statement(
    account_id:int=Query(...,ge=1), limit:int=Query(default=300,ge=1,le=1000),
    user:User=Depends(current_user), db:Session=Depends(get_db),
):
    acc=db.get(Account,account_id)
    if not acc or not acc.active: raise HTTPException(404,'Account not found')
    rows=list(db.execute(
        select(LedgerEntry,Transaction)
        .join(Transaction,Transaction.id==LedgerEntry.transaction_id)
        .where(LedgerEntry.account_id==account_id)
        .order_by(Transaction.id.desc(),LedgerEntry.id.desc()).limit(limit)
    ).all())
    items=[]
    for e,t in rows:
        items.append({
            "transaction_id":t.id,"created_at":t.created_at,"op_type":t.op_type,
            "details":t.details or "","status":t.status,
            "amount_fils":int(e.amount_fils),"entry_type":e.entry_type,
            "commission_fils":int(t.commission_fils or 0) if e.entry_type=='commission' else 0,
            "customer_name":(db.get(Customer,t.customer_id).name if t.customer_id and db.get(Customer,t.customer_id) else ''),
        })
    return {"account":{"id":acc.id,"name":acc.name,"balance_fils":int(acc.balance_fils)},"items":items}

@app.get('/api/v2/mobile/report-summary')
def mobile_report_summary(
    date_from:str=Query(default=''), date_to:str=Query(default=''),
    user:User=Depends(current_user), db:Session=Depends(get_db),
):
    start=_parse_report_dt(date_from,False); end=_parse_report_dt(date_to,True)
    q=select(Transaction).where(Transaction.status=='active')
    if start is not None: q=q.where(Transaction.created_at>=start)
    if end is not None: q=q.where(Transaction.created_at<=end)
    rows=list(db.scalars(q.order_by(Transaction.created_at,Transaction.id)).all())
    accounting_only={"تسوية رصيد","رصيد افتتاحي","مطابقة وردية"}
    groups={}
    commercial_count=0; commercial_amount=0; accounting_count=0; net_comm=0
    for t in rows:
        op=t.op_type
        is_accounting=op in accounting_only
        is_correction=op.startswith('عكس:') or op.startswith('عكس: ')
        category='محاسبي' if is_accounting else ('تصحيح/عكس' if is_correction else 'تجاري')
        g=groups.setdefault((category,op),{"category":category,"op_type":op,"count":0,"amount_fils":0,"commission_fils":0})
        g['count']+=1; g['amount_fils']+=int(t.amount_fils or 0); g['commission_fils']+=int(t.commission_fils or 0)
        net_comm+=int(t.commission_fils or 0)
        if is_accounting: accounting_count+=1
        elif not is_correction:
            commercial_count+=1; commercial_amount+=int(t.amount_fils or 0)
    return {
        "commercial_count":commercial_count,"commercial_amount_fils":commercial_amount,
        "accounting_count":accounting_count,"net_commission_fils":net_comm,
        "groups":list(groups.values())
    }

@app.get('/api/v2/mobile/shift')
def mobile_shift(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return current_shift(user,db)

@app.get('/api/v2/mobile/shifts')
def mobile_shifts(limit:int=Query(default=30,ge=1,le=100),user:User=Depends(current_user),db:Session=Depends(get_db)):
    return shift_history(limit,user,db)

@app.post('/api/v2/mobile/shifts/{shift_id}/close')
def mobile_close_shift(shift_id:int,payload:ShiftCloseIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if user.role!='admin': raise HTTPException(403,'Admin only')
    return close_shift(shift_id,payload,user,db)

@app.post('/api/v2/mobile/transactions/{tx_id}/reverse')
def mobile_reverse_tx(tx_id:int,payload:TransactionReverseIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if user.role!='admin': raise HTTPException(403,'Admin only')
    return reverse_tx(tx_id,payload,user,db)

@app.get('/api/v2/mobile/devices')
def mobile_devices(user:User=Depends(current_user),db:Session=Depends(get_db)):
    if user.role!='admin': raise HTTPException(403,'Admin only')
    rows=list(db.scalars(select(Device).order_by(Device.last_seen_at.desc())).all())
    return [{"device_id":d.device_id,"platform":d.platform,"device_name":d.device_name,
             "app_version":d.app_version,"last_tx_cursor":int(d.last_tx_cursor or 0),
             "active":bool(d.active),"last_seen_at":d.last_seen_at} for d in rows]



MOBILE_OPERATION_RULES = {
    "حوالة صادرة": {"source": True, "destination": True, "commission": True, "customer": False, "same_account": False},
    "حوالة واردة": {"source": True, "destination": True, "commission": True, "customer": False, "same_account": False},
    "دفع فاتورة": {"source": True, "destination": True, "commission": True, "customer": False, "same_account": False},
    "نقل أموال": {"source": True, "destination": True, "commission": True, "customer": False, "same_account": False},
    "بيع بطاقة خلوية": {"source": True, "destination": True, "commission": True, "customer": False, "same_account": True},
    "سحب مالي": {"source": True, "destination": False, "commission": False, "customer": False, "same_account": False},
    "دين للعميل": {"source": True, "destination": False, "commission": False, "customer": True, "same_account": False},
    "سداد دين": {"source": False, "destination": True, "commission": False, "customer": True, "same_account": False},
}

@app.get('/api/v2/mobile/transaction-rules')
def mobile_transaction_rules(user:User=Depends(current_user)):
    return {"api_version":"7.22.0","rules":MOBILE_OPERATION_RULES}

@app.get('/api/v2/mobile/capabilities')
def mobile_capabilities(user:User=Depends(current_user)):
    admin=user.role=='admin'
    return {
        "api_version":"7.22.0","phase2_complete":True,"role":user.role,
        "permissions":{
            "operations":True,"accounts":True,"customers":True,"reports":True,
            "statements":True,"history":True,"shift_view":True,
            "reverse":admin,"shift_close":admin,"device_admin":admin,
        },
        "offline_queue":True,"idempotency":True,"currency":"JOD","decimals":3,
        "operation_rules":MOBILE_OPERATION_RULES,
    }

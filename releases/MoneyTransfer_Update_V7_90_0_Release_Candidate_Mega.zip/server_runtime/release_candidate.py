# -*- coding: utf-8 -*-
"""Release-candidate diagnostics. Read-only except explicit backup action elsewhere."""
from datetime import datetime
from sqlalchemy import text
from .database import engine, DATABASE_BACKEND, database_ping
from .production import readiness, list_backups


def _scalar(sql, default=0):
    try:
        with engine.connect() as c:
            v=c.execute(text(sql)).scalar()
        return default if v is None else v
    except Exception:
        return default


def financial_invariants():
    checks=[]
    # Ledger must balance per transaction. Reversals/corrections are entries too and should net to zero.
    unbalanced=int(_scalar("SELECT COUNT(*) FROM (SELECT transaction_id FROM ledger_entries GROUP BY transaction_id HAVING COALESCE(SUM(amount_fils),0) <> 0) x",0))
    checks.append({"key":"ledger_balanced","ok":unbalanced==0,"detail":f"unbalanced_transactions={unbalanced}"})
    orphan_entries=int(_scalar("SELECT COUNT(*) FROM ledger_entries le LEFT JOIN transactions t ON t.id=le.transaction_id WHERE t.id IS NULL",0))
    checks.append({"key":"no_orphan_ledger_entries","ok":orphan_entries==0,"detail":f"orphans={orphan_entries}"})
    duplicate_client=int(_scalar("SELECT COUNT(*) FROM (SELECT client_tx_id FROM transactions WHERE client_tx_id IS NOT NULL AND client_tx_id<>'' GROUP BY client_tx_id HAVING COUNT(*)>1) x",0))
    checks.append({"key":"idempotency_unique","ok":duplicate_client==0,"detail":f"duplicate_client_tx_id={duplicate_client}"})
    bad_debt=int(_scalar("SELECT COUNT(*) FROM customers WHERE debt_fils < 0",0))
    checks.append({"key":"customer_debt_nonnegative","ok":bad_debt==0,"detail":f"negative_debts={bad_debt}"})
    return checks


def rc_report():
    prod=readiness(); db_ok,db_detail=database_ping(); fin=financial_invariants()
    backups=list_backups(200)
    checks=[
        {"key":"database_ping","ok":bool(db_ok),"detail":db_detail},
        {"key":"production_readiness","ok":bool(prod.get("ready_for_current_single_server")),"detail":DATABASE_BACKEND},
        {"key":"backup_exists","ok":bool(backups),"detail":f"count={len(backups)}"},
    ] + fin
    passed=sum(1 for x in checks if x["ok"]); total=len(checks)
    return {
        "generated_at":datetime.now().isoformat(timespec="seconds"),
        "release_candidate":True,
        "score":round((passed/total)*100) if total else 0,
        "passed":passed,"total":total,
        "commercial_release_ready":all(x["ok"] for x in checks),
        "checks":checks,
        "notes":[
            "PostgreSQL activation is still a dedicated deployment step.",
            "Signed commercial licensing and signed native mobile packages remain separate release gates."
        ]
    }

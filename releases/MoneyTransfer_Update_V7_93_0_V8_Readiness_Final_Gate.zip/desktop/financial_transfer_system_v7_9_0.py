# -*- coding: utf-8 -*-
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import datetime
import os
import tempfile
import subprocess
import shutil
import re
import hashlib
import hmac
import secrets
import webbrowser
from urllib.parse import quote
from urllib.request import urlopen, Request
from urllib.error import URLError
import json
import uuid
import threading
import csv
import zipfile
from pathlib import Path


# ===== Single source of truth for application versions =====
def _load_version_info():
    """Load program versions from app-root/version.json.

    All UI/update diagnostics use this source so visible and updater versions
    cannot drift apart after a ZIP update.
    """
    defaults = {
        "app_version": "7.36.0",
        "api_compatibility": "7.26.2",
        "runtime_version": "7.36.0",
        "schema_version": 5,
        "channel": "Stable",
    }
    try:
        from pathlib import Path as _Path
        version_path = _Path(__file__).resolve().parent.parent / "version.json"
        data = json.loads(version_path.read_text(encoding="utf-8-sig"))
        if isinstance(data, dict):
            defaults.update({k: data[k] for k in defaults if k in data})
    except Exception:
        pass
    return defaults

VERSION_INFO = _load_version_info()
APP_VERSION = str(VERSION_INFO.get("app_version", "7.36.0"))
API_COMPAT_VERSION = str(VERSION_INFO.get("api_compatibility", "7.26.2"))
RUNTIME_VERSION = str(VERSION_INFO.get("runtime_version", APP_VERSION))
UPDATE_CHANNEL = str(VERSION_INFO.get("channel", "Stable"))
# ==========================================================


# ===== Global zebra rows for every table/report =====
_original_treeview_insert = ttk.Treeview.insert

def _zebra_treeview_insert(self, parent, index, iid=None, **kw):
    try:
        count = len(self.get_children(parent))
        zebra_tag = "row_light" if count % 2 == 0 else "row_alt"
        existing = kw.get("tags", ())
        if isinstance(existing, str):
            existing = (existing,)
        kw["tags"] = tuple(existing) + (zebra_tag,)
    except Exception:
        pass

    if iid is None:
        return _original_treeview_insert(self, parent, index, **kw)
    return _original_treeview_insert(self, parent, index, iid=iid, **kw)

ttk.Treeview.insert = _zebra_treeview_insert
# ===================================================

DB_NAME = os.environ.get("MONEYTRANSFER_DESKTOP_DB", "financial_pos.db")
SERVER_URL = os.environ.get("MONEYTRANSFER_SERVER_URL", "http://127.0.0.1:8765").rstrip("/")
SERVER_POLL_MS = 5000
SERVER_TOKEN = None


PERMISSIONS = [
    ("operations", "تنفيذ العمليات"),
    ("edit_transactions", "تعديل العمليات"),
    ("cancel_transactions", "إلغاء وعكس العمليات"),
    ("statements", "كشف الحساب"),
    ("accounts", "عرض الحسابات"),
    ("balance_adjust", "تسوية / تعديل الأرصدة"),
    ("customers", "العملاء والديون"),
    ("reports", "التقارير"),
    ("reconcile", "مطابقة الأرصدة"),
    ("end_shift", "إنهاء الوردية"),
    ("audit", "سجل التدقيق"),
    ("settings", "الإعدادات"),
    ("backup", "النسخ الاحتياطي"),
    ("share", "مشاركة التقارير"),
]

def hash_password(password):
    salt = secrets.token_hex(16)
    iterations = 200000
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"),
        bytes.fromhex(salt), iterations
    ).hex()
    return f"pbkdf2_sha256${iterations}${salt}${digest}"

def verify_password(password, stored):
    if not stored:
        return False
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, iterations, salt, digest = stored.split("$", 3)
            candidate = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"),
                bytes.fromhex(salt), int(iterations)
            ).hex()
            return hmac.compare_digest(candidate, digest)
        except Exception:
            return False
    # Legacy V1-V6.4 plaintext support; migrated to hash after successful login.
    return hmac.compare_digest(password, stored)


DEFAULT_ACCOUNTS = [
    ("النقد كاش", "نقد"),
    ("البنك الإسلامي", "بنك"),
    ("محفظة أورنج موني", "محفظة"),
    ("محفظة أورنج موني وكيل", "محفظة"),
    ("محفظة أورنج موني وكيل RMEJ", "محفظة"),
    ("البنك العربي", "بنك"),
    ("إي فواتيركم", "خدمات دفع"),
]

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','employee')),
            active INTEGER NOT NULL DEFAULT 1,
            recovery_email TEXT DEFAULT '',
            recovery_whatsapp TEXT DEFAULT ''
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            account_type TEXT NOT NULL,
            balance REAL NOT NULL DEFAULT 0,
            warning_limit REAL NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            debt_balance REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT ''
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            op_type TEXT NOT NULL,
            source_account TEXT,
            destination_account TEXT,
            amount REAL NOT NULL DEFAULT 0,
            commission REAL NOT NULL DEFAULT 0,
            commission_account TEXT,
            customer_name TEXT,
            details TEXT DEFAULT '',
            performed_by TEXT,
            status TEXT NOT NULL DEFAULT 'active',
            reversed_transaction_id INTEGER
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS shifts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            status TEXT NOT NULL DEFAULT 'open',
            total_commission REAL NOT NULL DEFAULT 0,
            program_total REAL NOT NULL DEFAULT 0,
            actual_total REAL NOT NULL DEFAULT 0,
            difference REAL NOT NULL DEFAULT 0
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS shift_balances(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shift_id INTEGER NOT NULL,
            account_name TEXT NOT NULL,
            system_balance REAL NOT NULL,
            actual_balance REAL NOT NULL,
            difference REAL NOT NULL,
            FOREIGN KEY(shift_id) REFERENCES shifts(id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            username TEXT,
            action TEXT NOT NULL,
            details TEXT DEFAULT ''
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS shift_difference_reasons(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shift_id INTEGER NOT NULL,
            account_name TEXT NOT NULL,
            reason TEXT NOT NULL,
            FOREIGN KEY(shift_id) REFERENCES shifts(id)
        )
    """)

    # أعمدة إضافية آمنة للنسخ القديمة من قاعدة البيانات.
    tx_cols = [r[1] for r in cur.execute("PRAGMA table_info(transactions)").fetchall()]
    if "shift_id" not in tx_cols:
        cur.execute("ALTER TABLE transactions ADD COLUMN shift_id INTEGER")
    if "server_tx_id" not in tx_cols:
        cur.execute("ALTER TABLE transactions ADD COLUMN server_tx_id INTEGER")
    if "client_tx_id" not in tx_cols:
        cur.execute("ALTER TABLE transactions ADD COLUMN client_tx_id TEXT")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_transactions_server_tx_id ON transactions(server_tx_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_transactions_client_tx_id ON transactions(client_tx_id)")

    # ربط العمليات القديمة بالوردية المفتوحة غير ممكن بدقة، لذلك نربط فقط العمليات الجديدة.

    # تاريخ العمل للوردية يبقى تاريخ بدايتها حتى لو أغلقت بعد منتصف الليل.
    shift_cols = [r[1] for r in cur.execute("PRAGMA table_info(shifts)").fetchall()]
    if "business_date" not in shift_cols:
        cur.execute("ALTER TABLE shifts ADD COLUMN business_date TEXT")
    cur.execute("""
        UPDATE shifts
        SET business_date=substr(started_at,1,10)
        WHERE business_date IS NULL OR business_date=''
    """)

    # تطوير المستخدمين والصلاحيات بدون حذف أي بيانات قديمة.
    user_cols = [r[1] for r in cur.execute("PRAGMA table_info(users)").fetchall()]
    for col_name, col_def in [
        ("recovery_email", "TEXT DEFAULT ''"),
        ("recovery_whatsapp", "TEXT DEFAULT ''")
    ]:
        if col_name not in user_cols:
            cur.execute(f"ALTER TABLE users ADD COLUMN {col_name} {col_def}")

    cur.execute("""
        CREATE TABLE IF NOT EXISTS user_permissions(
            user_id INTEGER NOT NULL,
            permission TEXT NOT NULL,
            allowed INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(user_id, permission),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    # تطوير جدول العملاء بدون حذف أي بيانات قديمة.
    customer_cols = [r[1] for r in cur.execute("PRAGMA table_info(customers)").fetchall()]
    for col_name, col_def in [
        ("phone", "TEXT DEFAULT ''"),
        ("address", "TEXT DEFAULT ''"),
        ("debt_limit", "REAL NOT NULL DEFAULT 0"),
        ("active", "INTEGER NOT NULL DEFAULT 1")
    ]:
        if col_name not in customer_cols:
            cur.execute(f"ALTER TABLE customers ADD COLUMN {col_name} {col_def}")

    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('commission_presets','0.250,0.500,0.750,1.000')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('amount_presets','5,10,20,50,100')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_operation','حوالة صادرة')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('duplicate_warning','1')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('after_transaction_action','نفس العملية')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('font_size','10')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('ui_density','compact')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('operation_columns','4')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('account_columns','4')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('operation_order','حوالة صادرة,حوالة واردة,دفع فاتورة,نقل أموال,بيع بطاقة خلوية,سحب مالي,دين للعميل,سداد دين')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('backup_retention_count','30')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('business_name','نظام الإدارة المالية')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_cash_account','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_commission_account','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_bill_account','إي فواتيركم')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('confirm_transactions','1')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('start_maximized','1')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('low_balance_alerts','1')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('statement_default_view','جدول')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('backup_folder','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('auto_backup_shift','0')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('operation_view_mode','بطاقات سريعة')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_withdraw_account','البنك العربي')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('remembered_username','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('email_enabled','0')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('whatsapp_enabled','0')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('report_email','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('report_whatsapp','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('support_email','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('support_whatsapp','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('email_provider','تلقائي')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('recovery_email_provider','تلقائي')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_outgoing_source','البنك الإسلامي')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_incoming_destination','محفظة أورنج موني')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_transfer_source','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_transfer_destination','البنك الإسلامي')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_card_source','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_card_destination','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_debt_account','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_repayment_account','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_outgoing_destination','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_incoming_source','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_bill_source','إي فواتيركم')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_bill_destination','النقد كاش')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_withdraw_destination','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_debt_destination','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('default_repayment_source','')")
    cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('appearance_mode','light')")

    cur.execute("""
        INSERT OR IGNORE INTO users(username,password,role)
        VALUES('admin',?,'admin')
    """, (hash_password('admin123'),))
    cur.execute("""
        INSERT OR IGNORE INTO users(username,password,role)
        VALUES('emp',?,'employee')
    """, (hash_password('1234'),))

    # الحفاظ على سلوك الموظفين الحاليين قدر الإمكان، ثم يستطيع المدير تخصيصه.
    employee_rows = cur.execute("SELECT id FROM users WHERE role='employee'").fetchall()
    basic_permissions = [
        "operations","statements","accounts","customers",
        "reports","reconcile","end_shift","share"
    ]
    for (uid,) in employee_rows:
        exists = cur.execute(
            "SELECT 1 FROM user_permissions WHERE user_id=? LIMIT 1",(uid,)
        ).fetchone()
        if not exists:
            for perm in basic_permissions:
                cur.execute("""
                    INSERT OR IGNORE INTO user_permissions(user_id,permission,allowed)
                    VALUES(?,?,1)
                """,(uid,perm))

    for name, account_type in DEFAULT_ACCOUNTS:
        cur.execute("""
            INSERT OR IGNORE INTO accounts(name,account_type)
            VALUES(?,?)
        """, (name, account_type))

    cur.execute("SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1")
    if not cur.fetchone():
        cur.execute("""
            INSERT INTO shifts(started_at,status,business_date)
            VALUES(?, 'open', ?)
        """, (
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            datetime.now().strftime("%Y-%m-%d")
        ))

    conn.commit()
    conn.close()

class LoginWindow:
    def __init__(self, root, on_success):
        self.root = root
        self.on_success = on_success
        root.title("تسجيل الدخول")
        root.geometry("470x430")
        root.resizable(False, False)

        frame = ttk.Frame(root, padding=28)
        frame.pack(fill="both", expand=True)

        conn = get_db()
        settings = dict(conn.execute("SELECT key,value FROM settings").fetchall())
        conn.close()
        business_name = settings.get("business_name", "نظام الإدارة المالية")

        ttk.Label(
            frame, text=business_name,
            font=("Segoe UI", 19, "bold")
        ).pack(pady=(8, 4))
        ttk.Label(
            frame, text="تسجيل الدخول إلى النظام",
            font=("Segoe UI", 10)
        ).pack(pady=(0, 18))

        ttk.Label(frame, text="اسم المستخدم").pack(anchor="e")
        self.ent_user = ttk.Entry(frame, justify="right")
        self.ent_user.pack(fill="x", pady=5)

        remembered = settings.get("remembered_username", "").strip()
        if remembered:
            self.ent_user.insert(0, remembered)

        ttk.Label(frame, text="كلمة المرور").pack(anchor="e")
        self.ent_pass = ttk.Entry(frame, show="*", justify="right")
        self.ent_pass.pack(fill="x", pady=5)

        self.remember_var = tk.BooleanVar(value=bool(remembered))
        ttk.Checkbutton(
            frame,
            text="تذكر اسم المستخدم على هذا الجهاز",
            variable=self.remember_var
        ).pack(anchor="e", pady=(6, 2))

        ttk.Button(
            frame, text="دخول", command=self.login
        ).pack(pady=(12, 7), ipadx=40, ipady=4)

        ttk.Button(
            frame, text="نسيت كلمة المرور؟",
            command=self.forgot_password
        ).pack(pady=3)

        ttk.Label(
            frame,
            text="لأمان الحساب لا يتم حفظ أو عرض كلمة المرور.",
            font=("Segoe UI", 8)
        ).pack(pady=(10, 0))

        self.ent_pass.bind("<Return>", lambda e: self.login())
        if remembered:
            self.ent_pass.focus_set()
        else:
            self.ent_user.focus_set()

    def login(self):
        user = self.ent_user.get().strip()
        pwd = self.ent_pass.get()

        conn = get_db()
        row = conn.execute("""
            SELECT id,password,role FROM users
            WHERE username=? AND active=1
        """, (user,)).fetchone()

        ok = bool(row and verify_password(pwd, row[1]))
        if ok:
            # V7.9.0: authenticate the same user against the local API.
            global SERVER_TOKEN
            try:
                payload = json.dumps({"username": user, "password": pwd}, ensure_ascii=False).encode("utf-8")
                req = Request(
                    SERVER_URL + "/api/v1/auth/login", data=payload, method="POST",
                    headers={"Content-Type": "application/json", "Accept": "application/json"}
                )
                with urlopen(req, timeout=1.2) as resp:
                    api_login = json.loads(resp.read().decode("utf-8"))
                SERVER_TOKEN = api_login.get("access_token")
            except Exception:
                SERVER_TOKEN = None
            # Migrate old plaintext password after a successful login.
            if not row[1].startswith("pbkdf2_sha256$"):
                conn.execute(
                    "UPDATE users SET password=? WHERE id=?",
                    (hash_password(pwd), row[0])
                )
            conn.execute(
                "INSERT OR REPLACE INTO settings(key,value) VALUES('remembered_username',?)",
                (user if self.remember_var.get() else "",)
            )
            conn.commit()
            conn.close()
            self.on_success(user, row[2])
        else:
            conn.close()
            messagebox.showerror("خطأ", "اسم المستخدم أو كلمة المرور غير صحيحة")

    def forgot_password(self):
        username = self.ent_user.get().strip()
        if not username:
            username = tk.simpledialog.askstring(
                "استعادة كلمة المرور",
                "اكتب اسم المستخدم:",
                parent=self.root
            ) if hasattr(tk, "simpledialog") else None
        if not username:
            # fallback dialog without simpledialog import
            dialog = tk.Toplevel(self.root)
            dialog.title("استعادة كلمة المرور")
            dialog.geometry("420x190")
            f = ttk.Frame(dialog, padding=18); f.pack(fill="both", expand=True)
            ttk.Label(f, text="اكتب اسم المستخدم").pack(anchor="e")
            ent = ttk.Entry(f, justify="right"); ent.pack(fill="x", pady=8)
            def cont():
                value = ent.get().strip()
                dialog.destroy()
                if value:
                    self._open_recovery_request(value)
            ttk.Button(f, text="متابعة", command=cont).pack(pady=8)
            ent.bind("<Return>", lambda e: cont())
            ent.focus_set()
            return
        self._open_recovery_request(username)

    def _open_recovery_request(self, username):
        conn=get_db()
        user=conn.execute(
            "SELECT username,active FROM users WHERE username=?",(username,)
        ).fetchone()
        settings=dict(conn.execute("SELECT key,value FROM settings").fetchall())
        conn.close()

        if not user or not user[1]:
            messagebox.showerror("خطأ","المستخدم غير موجود أو معطل")
            return

        email_enabled=settings.get("email_enabled","0")=="1"
        wa_enabled=settings.get("whatsapp_enabled","0")=="1"
        support_email=settings.get("support_email","").strip()
        support_wa=settings.get("support_whatsapp","").strip()
        provider=settings.get("recovery_email_provider","تلقائي")

        if not ((email_enabled and support_email) or (wa_enabled and support_wa)):
            messagebox.showinfo(
                "استعادة كلمة المرور",
                "لم يفعّل المدير وسيلة استعادة حتى الآن."
            )
            return

        win=tk.Toplevel(self.root)
        win.title("طلب استعادة كلمة المرور")
        win.geometry("560x440")
        f=ttk.Frame(win,padding=20)
        f.pack(fill="both",expand=True)

        ttk.Label(
            f,text=f"المستخدم: {username}",
            font=("Segoe UI",11,"bold")
        ).pack(anchor="e",pady=4)

        msg=(
            f"طلب إعادة تعيين كلمة مرور\n"
            f"المستخدم: {username}\n"
            f"الوقت: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"يرجى من المدير تعيين كلمة مرور جديدة."
        )

        def copy_request():
            self.root.clipboard_clear()
            self.root.clipboard_append(msg)
            self.root.update()
            messagebox.showinfo("تم","تم نسخ نص الطلب.",parent=win)

        if wa_enabled and support_wa:
            number=re.sub(r"\D","",support_wa)

            ttk.Button(
                f,text="💬 فتح تطبيق واتساب المثبت",
                command=lambda:webbrowser.open(
                    f"whatsapp://send?phone={number}&text={quote(msg)}"
                )
            ).pack(fill="x",pady=5)

            ttk.Button(
                f,text="🌐 فتح واتساب من المتصفح",
                command=lambda:webbrowser.open(
                    f"https://wa.me/{number}?text={quote(msg)}"
                )
            ).pack(fill="x",pady=5)

        if email_enabled and support_email:
            detected=self.detect_email_provider(support_email,provider)
            ttk.Button(
                f,text=f"📧 فتح {detected} برسالة جاهزة",
                command=lambda:self.open_email_compose(
                    support_email,"طلب إعادة تعيين كلمة مرور",msg,provider
                )
            ).pack(fill="x",pady=5)

        ttk.Button(
            f,text="📋 نسخ نص الطلب",
            command=copy_request
        ).pack(fill="x",pady=5)

        ttk.Label(
            f,
            text="إذا ظهر واتساب بشاشة سوداء، افتح تطبيق واتساب المثبت أو انسخ الرسالة والصقها يدويًا.",
            font=("Segoe UI",8),
            wraplength=500,
            justify="right"
        ).pack(anchor="e",pady=12)

        ttk.Button(f,text="إغلاق",command=win.destroy).pack(pady=5)

class FinancialApp:
    def __init__(self, root, username, role):
        self.root = root
        self.username = username
        self.role = role
        self._pending_server_link = None
        self.is_dark_mode = False
        self._theme_apply_scheduled = False

        self.root.withdraw()
        self.root.overrideredirect(False)
        self.root.resizable(True, True)
        self.root.minsize(1100, 680)
        self.root.geometry("1360x840")

        conn = get_db()
        settings = dict(conn.execute("SELECT key,value FROM settings").fetchall())
        conn.close()
        self._startup_settings = settings

        business_name = settings.get("business_name", "نظام الإدارة المالية")
        self.root.title(f"{business_name} - {username}")

        # Prefer a modern Arabic UI font when it is already installed; never bundle external font files.
        try:
            import tkinter.font as tkfont
            families=set(tkfont.families(self.root))
            self.ui_font = "Tajawal" if "Tajawal" in families else ("Cairo" if "Cairo" in families else "Segoe UI")
        except Exception:
            self.ui_font = "Segoe UI"
        self.ui_font_size = max(9, min(16, int(settings.get("font_size", "10") or 10)))
        self.root.option_add("*Font", (self.ui_font, self.ui_font_size))

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("TFrame", background="#F5F7FB")
        style.configure("TLabel", background="#F5F7FB", foreground="#172033")
        style.configure("TLabelframe", background="#F5F7FB")
        style.configure("TLabelframe.Label", background="#F5F7FB", foreground="#24324A",
                        font=(self.ui_font, self.ui_font_size, "bold"))
        style.configure("TButton", font=(self.ui_font, self.ui_font_size), padding=(10,7))
        style.configure("Accent.TButton", font=(self.ui_font, self.ui_font_size, "bold"), padding=(12,8))
        style.configure("Treeview", rowheight=30 if settings.get("ui_density","compact")=="compact" else 36, font=(self.ui_font, self.ui_font_size),
                        background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=(self.ui_font, self.ui_font_size, "bold"),
                        background="#E9EEF7", foreground="#172033")
        style.map("Treeview", background=[("selected","#DCE8FF")],
                  foreground=[("selected","#0B2A66")])

        self.is_dark_mode = settings.get('appearance_mode','light') == 'dark'
        self.configure_theme_styles()
        self.build_sidebar()
        self.build_content()
        self.root.bind_all('<Map>', self._on_widget_mapped, add='+')

        self.root.update_idletasks()
        self.root.deiconify()
        if settings.get("start_maximized", "1") == "1":
            try:
                self.root.state("zoomed")
            except Exception:
                pass

        self.show_dashboard()
        self.root.after_idle(self.refresh_english_digits)
        self.root.after_idle(self.apply_theme)

    def configure_theme_styles(self):
        """V7.10: central light/dark palette for all ttk widgets."""
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        if self.is_dark_mode:
            bg, surface, fg, muted = "#0B1220", "#111827", "#F8FAFC", "#CBD5E1"
            field, heading, selected = "#0F172A", "#1E293B", "#1D4ED8"
        else:
            bg, surface, fg, muted = "#F5F7FB", "#FFFFFF", "#172033", "#475467"
            field, heading, selected = "#FFFFFF", "#E9EEF7", "#DCE8FF"
        self.theme_palette = {"bg":bg,"surface":surface,"fg":fg,"muted":muted,"field":field,"heading":heading,"selected":selected}
        style.configure("TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg)
        style.configure("TLabelframe", background=bg, foreground=fg)
        style.configure("TLabelframe.Label", background=bg, foreground=fg, font=(self.ui_font,10,"bold"))
        style.configure("TButton", font=("Segoe UI",10), padding=(10,7), background=surface, foreground=fg)
        style.map("TButton", background=[("active", heading)])
        style.configure("Accent.TButton", font=("Segoe UI",10,"bold"), padding=(12,8))
        style.configure("TEntry", fieldbackground=field, foreground=fg, insertcolor=fg)
        style.configure("TCombobox", fieldbackground=field, background=surface, foreground=fg, arrowcolor=fg)
        style.map("TCombobox", fieldbackground=[("readonly",field)], foreground=[("readonly",fg)])
        style.configure("TCheckbutton", background=bg, foreground=fg)
        style.map("TCheckbutton", background=[("active",bg)])
        style.configure("TRadiobutton", background=bg, foreground=fg)
        style.configure("Treeview", rowheight=32, font=("Segoe UI",10), background=field, fieldbackground=field, foreground=fg)
        style.configure("Treeview.Heading", font=("Segoe UI",10,"bold"), background=heading, foreground=fg)
        style.map("Treeview", background=[("selected",selected)], foreground=[("selected","#FFFFFF" if self.is_dark_mode else "#0B2A66")])
        style.configure("TScrollbar", background=surface, troughcolor=bg, arrowcolor=fg, bordercolor=heading)
        style.configure("TNotebook", background=bg)
        style.configure("TNotebook.Tab", background=surface, foreground=fg)
        style.map("TNotebook.Tab", background=[("selected",heading)])

    def _inside_sidebar(self, widget):
        try:
            w=widget
            while w is not None:
                if hasattr(self,"sidebar") and w is self.sidebar:
                    return True
                parent=w.winfo_parent()
                if not parent: break
                w=w._nametowidget(parent)
        except Exception:
            pass
        return False

    def _theme_tk_widget(self, widget):
        """Theme classic Tk widgets while preserving their original light appearance for switching back."""
        try:
            if not hasattr(widget,"_mt_theme_original"):
                original={}
                for opt in ("background","foreground","insertbackground","selectbackground","selectforeground","highlightbackground","highlightcolor"):
                    try: original[opt]=widget.cget(opt)
                    except Exception: pass
                widget._mt_theme_original=original
            if self._inside_sidebar(widget):
                return
            if not self.is_dark_mode:
                for opt,val in getattr(widget,"_mt_theme_original",{}).items():
                    try: widget.configure(**{opt:val})
                    except Exception: pass
                return
            bg="#0B1220"; surface="#111827"; fg="#F8FAFC"; muted="#CBD5E1"
            cls=widget.winfo_class()
            if cls in ("Entry","Text","Listbox","Spinbox"):
                opts={"background":"#0F172A","foreground":fg,"insertbackground":fg,"selectbackground":"#1D4ED8","selectforeground":"#FFFFFF"}
            elif cls in ("Button",):
                old=str(getattr(widget,"_mt_theme_original",{}).get("background","")).lower()
                # Preserve strong action colors; darken ordinary light buttons.
                strong=("#b42318","#027a48","#1d4ed8","#6941c6","#c4320a")
                opts={"foreground":fg}
                if old not in strong: opts["background"]="#1E293B"
            elif cls in ("Canvas",):
                opts={"background":bg,"highlightbackground":bg}
            elif cls in ("Frame","Labelframe"):
                opts={"background":bg}
            elif cls in ("Label",):
                opts={"background":bg,"foreground":fg}
            else:
                opts={}
            for k,v in opts.items():
                try: widget.configure(**{k:v})
                except Exception: pass
        except Exception:
            pass

    def _theme_treeview(self, tree):
        """Keep zebra rows readable in both light and dark modes."""
        try:
            if self.is_dark_mode:
                tree.tag_configure("row_light", background="#111827", foreground="#F8FAFC")
                tree.tag_configure("row_alt", background="#172033", foreground="#F8FAFC")
            else:
                tree.tag_configure("row_light", background="#FFFFFF", foreground="#172033")
                tree.tag_configure("row_alt", background="#EEF3F8", foreground="#172033")
        except Exception:
            pass

    def apply_theme_to_widget(self, widget):
        try:
            if isinstance(widget, (tk.Tk, tk.Toplevel)):
                widget.configure(bg=self.theme_palette["bg"])
            if isinstance(widget, ttk.Treeview):
                self._theme_treeview(widget)
            if isinstance(widget, tk.Widget) and not isinstance(widget, ttk.Widget):
                self._theme_tk_widget(widget)
            for child in widget.winfo_children():
                self.apply_theme_to_widget(child)
        except Exception:
            pass

    def apply_theme(self):
        self.configure_theme_styles()
        try:
            if hasattr(self,"content_outer"): self.content_outer.configure(bg=self.theme_palette["bg"])
            if hasattr(self,"page_canvas"): self.page_canvas.configure(bg=self.theme_palette["bg"])
            self.root.configure(bg=self.theme_palette["bg"])
            self.apply_theme_to_widget(self.root)
        finally:
            self._theme_apply_scheduled=False

    def _on_widget_mapped(self, event):
        if self._theme_apply_scheduled:
            return
        self._theme_apply_scheduled=True
        try: self.root.after_idle(self.apply_theme)
        except Exception: self._theme_apply_scheduled=False

    def set_appearance_mode(self, mode, persist=True):
        self.is_dark_mode = str(mode).lower() == "dark"
        if persist:
            self.set_setting("appearance_mode", "dark" if self.is_dark_mode else "light")
        self.apply_theme()
        try:
            self.dark_mode_button.configure(text="☀ الوضع الفاتح" if self.is_dark_mode else "🌙 الوضع الداكن")
        except Exception:
            pass

    def toggle_dark_mode(self):
        self.set_appearance_mode("light" if self.is_dark_mode else "dark")

    def has_permission(self, permission):
        if self.role == "admin":
            return True
        conn = get_db()
        row = conn.execute("""
            SELECT up.allowed
            FROM user_permissions up
            JOIN users u ON u.id=up.user_id
            WHERE u.username=? AND up.permission=?
        """,(self.username,permission)).fetchone()
        conn.close()
        return bool(row and row[0])

    def require_permission(self, permission, title="هذه الصلاحية"):
        if self.has_permission(permission):
            return True
        messagebox.showwarning(
            "غير مسموح",
            f"ليس لديك صلاحية لاستخدام: {title}"
        )
        return False

    def bind_mousewheel_recursive(self, widget, canvas):
        def wheel(event):
            try:
                step = int(-event.delta / 120)
                if step == 0:
                    step = -1 if event.delta > 0 else 1
                canvas.yview_scroll(step * 3, "units")
                return "break"
            except Exception:
                return None
        try:
            widget.bind("<MouseWheel>", wheel, add="+")
        except Exception:
            pass
        for child in widget.winfo_children():
            self.bind_mousewheel_recursive(child, canvas)

    def log(self, action, details=""):
        conn = get_db()
        conn.execute("""
            INSERT INTO audit_log(created_at,username,action,details)
            VALUES(?,?,?,?)
        """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              self.username, action, details))
        conn.commit()
        conn.close()

    def check_server_health(self):
        """فحص خفيف لسيرفر V7 المحلي بدون تعطيل واجهة المستخدم."""
        try:
            req = Request(f"{SERVER_URL}/api/v1/health", headers={"Accept": "application/json"})
            with urlopen(req, timeout=1.2) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            api_version = str(data.get("api_version", ""))
            runtime_version = str(data.get("runtime_version", ""))
            return bool(data.get("ok")), api_version, runtime_version
        except Exception:
            return False, "", ""

    def refresh_server_status(self):
        # urllib قد ينتظر لحظة قصيرة؛ لذلك ننفذ الفحص في خيط منفصل.
        import threading
        def worker():
            ok, version, runtime_version = self.check_server_health()
            def apply():
                try:
                    if not hasattr(self, "server_status_label") or not self.server_status_label.winfo_exists():
                        return
                    if ok:
                        suffix = f"  API {version}" if version else ""
                        if runtime_version and runtime_version != version:
                            suffix += f"  |  Runtime {runtime_version}"
                        self.server_status_label.configure(
                            text=f"● السيرفر متصل{suffix}", fg="#027A48", bg="#ECFDF3"
                        )
                    else:
                        self.server_status_label.configure(
                            text="● السيرفر غير متصل", fg="#B42318", bg="#FFF0F0"
                        )
                finally:
                    try:
                        self.root.after(SERVER_POLL_MS, self.refresh_server_status)
                    except Exception:
                        pass
            try:
                self.root.after(0, apply)
            except Exception:
                pass
        threading.Thread(target=worker, daemon=True).start()

    def show_mobile_access(self):
        """عرض رابط الهاتف محلياً، وإظهار رابط VPN آمن إذا كان Tailscale متاحاً."""
        import socket, subprocess
        try:
            sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            sock.connect(("8.8.8.8",80)); ip=sock.getsockname()[0]; sock.close()
        except Exception:
            try: ip=socket.gethostbyname(socket.gethostname())
            except Exception: ip="127.0.0.1"
        lan_url=f"http://{ip}:8765/mobile/"
        remote_url=""
        try:
            flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
            out=subprocess.check_output(["tailscale","ip","-4"],text=True,timeout=2,creationflags=flags).strip().splitlines()
            if out and out[0].strip(): remote_url=f"http://{out[0].strip()}:8765/mobile/"
        except Exception:
            pass
        win=tk.Toplevel(self.root); win.title("تطبيق الهاتف"); win.geometry("680x470"); win.resizable(False,False)
        f=ttk.Frame(win,padding=20); f.pack(fill="both",expand=True)
        ttk.Label(f,text=f"📱 تطبيق الهاتف — V{APP_VERSION}",font=("Segoe UI",16,"bold")).pack(anchor="e",pady=(0,10))
        ttk.Label(f,text="داخل شبكة المحل:",font=("Segoe UI",10,"bold")).pack(anchor="e")
        ent=ttk.Entry(f,justify="center",font=("Consolas",12)); ent.insert(0,lan_url); ent.configure(state="readonly"); ent.pack(fill="x",pady=7)
        def copy_value(v):
            self.root.clipboard_clear(); self.root.clipboard_append(v); self.root.update(); messagebox.showinfo("تم","تم نسخ الرابط.",parent=win)
        ttk.Button(f,text="📋 نسخ رابط الشبكة المحلية",command=lambda:copy_value(lan_url)).pack(fill="x",pady=3)
        ttk.Separator(f,orient="horizontal").pack(fill="x",pady=12)
        if remote_url:
            ttk.Label(f,text="من شبكة أخرى — اتصال VPN آمن متاح:",font=("Segoe UI",10,"bold")).pack(anchor="e")
            ent2=ttk.Entry(f,justify="center",font=("Consolas",12)); ent2.insert(0,remote_url); ent2.configure(state="readonly"); ent2.pack(fill="x",pady=7)
            ttk.Button(f,text="📋 نسخ رابط الوصول الخارجي الآمن",command=lambda:copy_value(remote_url)).pack(fill="x",pady=3)
            ttk.Label(f,text="يجب أن يكون الهاتف مسجلاً في نفس شبكة Tailscale الخاصة بك.",wraplength=620,justify="right").pack(anchor="e",pady=6)
        else:
            ttk.Label(f,text="🌐 الوصول من شبكة أخرى",font=("Segoe UI",10,"bold")).pack(anchor="e")
            ttk.Label(f,text="غير مفعّل بعد. للأمان لن يفتح البرنامج المنفذ 8765 مباشرة على الإنترنت. يمكن تفعيل VPN آمن مثل Tailscale لاحقاً، وبعد تثبيته سيظهر الرابط هنا تلقائياً.",wraplength=620,justify="right").pack(anchor="e",pady=7)
        ttk.Label(f,text="مهم: قاعدة البيانات لا تُعرض للهاتف مباشرة؛ الهاتف يتعامل فقط مع API وصلاحيات المستخدم.",wraplength=620,justify="right").pack(anchor="e",pady=10)
        if self.role == "admin":
            ttk.Button(f,text="📱 إدارة الأجهزة المسجلة",command=lambda:self.show_mobile_devices(win)).pack(fill="x",pady=4)
        ttk.Button(f,text="إغلاق",command=win.destroy).pack(pady=5)


    def show_mobile_devices(self, parent=None):
        if self.role != "admin":
            messagebox.showerror("الصلاحيات","هذه الشاشة للمدير فقط.",parent=parent or self.root); return
        win=tk.Toplevel(parent or self.root); win.title("إدارة أجهزة الهاتف"); win.geometry("920x500")
        box=ttk.Frame(win,padding=14); box.pack(fill="both",expand=True)
        ttk.Label(box,text="📱 الأجهزة والجلسات المسجلة",font=(self.ui_font if hasattr(self,'ui_font') else 'Segoe UI',14,'bold')).pack(anchor="e",pady=(0,8))
        cols=("device","name","platform","version","cursor","last_seen","active")
        tree=ttk.Treeview(box,columns=cols,show="headings",height=14)
        titles={"device":"معرّف الجهاز","name":"اسم الجهاز","platform":"النظام","version":"الإصدار","cursor":"المؤشر","last_seen":"آخر اتصال","active":"الحالة"}
        widths={"device":220,"name":130,"platform":85,"version":80,"cursor":70,"last_seen":170,"active":80}
        for c in cols: tree.heading(c,text=titles[c]); tree.column(c,width=widths[c],anchor="center")
        tree.pack(fill="both",expand=True)
        status=ttk.Label(box,text=""); status.pack(anchor="e",pady=5)
        def refresh():
            for x in tree.get_children(): tree.delete(x)
            try:
                rows=self.server_request("GET","/api/v2/mobile/devices",timeout=1.5)
                for r in rows:
                    tree.insert("", "end", values=(r.get('device_id',''),r.get('device_name',''),r.get('platform',''),r.get('app_version',''),r.get('last_tx_cursor',0),str(r.get('last_seen_at','') or ''),"فعال" if r.get('active') else "موقوف"))
                status.config(text=f"عدد الأجهزة: {len(rows)}")
            except Exception as exc: status.config(text=f"تعذر تحميل الأجهزة: {exc}")
        def set_active(active):
            sel=tree.selection()
            if not sel: messagebox.showwarning("اختيار","اختر جهازاً أولاً.",parent=win); return
            device=tree.item(sel[0],"values")[0]
            action="state"
            if not active and not messagebox.askyesno("تأكيد","إيقاف هذا الجهاز سيمنعه من المزامنة حتى إعادة تفعيله. متابعة؟",parent=win): return
            try:
                self.server_request("POST",f"/api/v2/mobile/devices/{device}/state",{"active":bool(active)},timeout=1.5); refresh()
            except Exception as exc: messagebox.showerror("الأجهزة",str(exc),parent=win)
        bar=ttk.Frame(box); bar.pack(fill="x",pady=6)
        ttk.Button(bar,text="🔄 تحديث",command=refresh).pack(side="right",padx=4)
        ttk.Button(bar,text="✅ تفعيل",command=lambda:set_active(True)).pack(side="right",padx=4)
        ttk.Button(bar,text="⛔ إيقاف",command=lambda:set_active(False)).pack(side="right",padx=4)
        ttk.Button(bar,text="إغلاق",command=win.destroy).pack(side="left",padx=4)
        refresh()


    def manage_mobile_devices(self):
        """إدارة الأجهزة المسجلة في API بدون حذف بياناتها."""
        try:
            rows=self.server_request("GET","/api/v2/mobile/devices",timeout=1.5)
        except Exception as e:
            messagebox.showerror("الأجهزة",f"تعذر قراءة الأجهزة:\n{e}",parent=self.root)
            return
        if not isinstance(rows,list):
            rows=[]
        win=tk.Toplevel(self.root); win.title("إدارة أجهزة الهاتف"); win.geometry("850x470")
        f=ttk.Frame(win,padding=14); f.pack(fill="both",expand=True)
        ttk.Label(f,text="📱 الأجهزة المسجلة",font=(getattr(self,"ui_font","Segoe UI"),15,"bold")).pack(anchor="e",pady=(0,8))
        ttk.Label(f,text="تعطيل الجهاز يوقف مزامنته فوراً دون حذف أي بيانات أو عمليات سابقة.",wraplength=800,justify="right").pack(anchor="e",pady=(0,10))
        cols=("name","platform","version","last_seen","state","id")
        tree=ttk.Treeview(f,columns=cols,show="headings",height=13)
        heads={"name":"اسم الجهاز","platform":"النظام","version":"الإصدار","last_seen":"آخر ظهور","state":"الحالة","id":"معرّف الجهاز"}
        widths={"name":150,"platform":80,"version":80,"last_seen":150,"state":80,"id":250}
        for c in cols:
            tree.heading(c,text=heads[c]); tree.column(c,width=widths[c],anchor="center")
        tree.pack(fill="both",expand=True)
        def fill(data):
            for i in tree.get_children(): tree.delete(i)
            for d in data:
                tree.insert("", "end", values=(
                    d.get("device_name",""),d.get("platform",""),d.get("app_version",""),
                    str(d.get("last_seen_at","") or "")[:19],
                    "فعال" if d.get("active") else "معطل", d.get("device_id","")
                ))
        fill(rows)
        btns=ttk.Frame(f); btns.pack(fill="x",pady=(10,0))
        def change(active):
            sel=tree.selection()
            if not sel:
                messagebox.showwarning("الأجهزة","اختر جهازاً أولاً.",parent=win); return
            vals=tree.item(sel[0],"values"); device_id=vals[5]
            action="تفعيل" if active else "تعطيل"
            if not messagebox.askyesno("تأكيد",f"هل تريد {action} هذا الجهاز؟",parent=win): return
            try:
                self.server_request("POST",f"/api/v2/mobile/devices/{device_id}/state",{"active":bool(active)},timeout=1.5)
                data=self.server_request("GET","/api/v2/mobile/devices",timeout=1.5); fill(data if isinstance(data,list) else [])
            except Exception as e:
                messagebox.showerror("الأجهزة",f"تعذر تنفيذ الأمر:\n{e}",parent=win)
        ttk.Button(btns,text="✅ تفعيل الجهاز",command=lambda:change(True)).pack(side="right",padx=4)
        ttk.Button(btns,text="⛔ تعطيل الجهاز",command=lambda:change(False)).pack(side="right",padx=4)
        ttk.Button(btns,text="إغلاق",command=win.destroy).pack(side="left",padx=4)

    def server_request(self, method, path, payload=None, timeout=5.0):
        """Authenticated request to the V7.10.0 desktop / V7.9 API server."""
        global SERVER_TOKEN
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if SERVER_TOKEN:
            headers["Authorization"] = f"Bearer {SERVER_TOKEN}"
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = Request(SERVER_URL + path, data=data, method=method, headers=headers)
        try:
            with urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8")
            return json.loads(body) if body else {}
        except Exception as exc:
            # Preserve server error text when available.
            try:
                body = exc.read().decode("utf-8", errors="replace")
                raise RuntimeError(body or str(exc))
            except AttributeError:
                raise RuntimeError(str(exc))

    def server_submit_core_transfer(self, op, src, dst, amount, commission, commission_account, details="", parent=None):
        """V7.10.0: server-authoritative write for transfers, bills, internal transfers, card sales, and withdrawals."""
        if op not in ("حوالة صادرة", "حوالة واردة", "دفع فاتورة", "نقل أموال", "بيع بطاقة خلوية", "سحب مالي"):
            return True
        global SERVER_TOKEN
        if not SERVER_TOKEN:
            messagebox.showerror(
                "السيرفر",
                "لم يتم توثيق جلسة السيرفر. سجل الخروج ثم ادخل من جديد.",
                parent=parent or self.root,
            )
            return False
        try:
            rows = self.server_request("GET", "/api/v1/accounts")
            ids = {row["name"]: int(row["id"]) for row in rows}
            if src not in ids:
                raise RuntimeError("حساب المصدر غير موجود على السيرفر")
            if dst and dst not in ids:
                raise RuntimeError("حساب الوجهة غير موجود على السيرفر")
            ca_id = ids.get(commission_account) if commission > 0 and commission_account else None
            if commission > 0 and ca_id is None:
                raise RuntimeError("حساب العمولة غير موجود على السيرفر")
            client_tx_id = str(uuid.uuid4())
            payload = {
                "client_tx_id": client_tx_id,
                "op_type": op,
                "source_account_id": ids[src],
                "destination_account_id": ids.get(dst) if dst else None,
                "amount_fils": int(round(float(amount) * 1000)),
                "commission_fils": int(round(float(commission) * 1000)),
                "commission_account_id": ca_id,
                "details": details or "",
            }
            response = self.server_request("POST", "/api/v1/transactions", payload)
            self._remember_server_link(response, client_tx_id)
            return True
        except Exception as exc:
            self._clear_pending_server_link()
            messagebox.showerror(
                "رفض السيرفر العملية",
                "لم يتم تغيير الأرصدة المحلية.\n\n" + str(exc),
                parent=parent or self.root,
            )
            return False

    def server_submit_debt_operation(self, op, account, amount, customer_name, details="", parent=None):
        """V7.10.0: server-authoritative customer debt and repayment."""
        if op not in ("دين للعميل", "سداد دين"):
            return True
        global SERVER_TOKEN
        if not SERVER_TOKEN:
            messagebox.showerror(
                "السيرفر",
                "لم يتم توثيق جلسة السيرفر. سجل الخروج ثم ادخل من جديد.",
                parent=parent or self.root,
            )
            return False
        try:
            account_rows = self.server_request("GET", "/api/v1/accounts")
            account_ids = {row["name"]: int(row["id"]) for row in account_rows}
            if account not in account_ids:
                raise RuntimeError("الحساب غير موجود على السيرفر")
            customer_rows = self.server_request("GET", "/api/v1/customers")
            customer_ids = {row["name"]: int(row["id"]) for row in customer_rows}
            if customer_name not in customer_ids:
                raise RuntimeError("العميل غير موجود على السيرفر")
            client_tx_id = str(uuid.uuid4())
            payload = {
                "client_tx_id": client_tx_id,
                "op_type": op,
                "source_account_id": account_ids[account] if op == "دين للعميل" else None,
                "destination_account_id": account_ids[account] if op == "سداد دين" else None,
                "amount_fils": int(round(float(amount) * 1000)),
                "commission_fils": 0,
                "commission_account_id": None,
                "customer_id": customer_ids[customer_name],
                "details": details or "",
            }
            response = self.server_request("POST", "/api/v1/transactions", payload)
            self._remember_server_link(response, client_tx_id)
            return True
        except Exception as exc:
            self._clear_pending_server_link()
            messagebox.showerror(
                "رفض السيرفر العملية",
                "لم يتم تغيير الدين أو الأرصدة المحلية.\n\n" + str(exc),
                parent=parent or self.root,
            )
            return False

    def _remember_server_link(self, response, client_tx_id):
        """Keep the server transaction identity until its local mirror row is inserted."""
        if not isinstance(response, dict) or not response.get("id"):
            raise RuntimeError("لم يرجع السيرفر رقم العملية")
        self._pending_server_link = {
            "server_tx_id": int(response["id"]),
            "client_tx_id": str(response.get("client_tx_id") or client_tx_id),
        }

    def _link_pending_server_transaction(self, cur, local_tx_id):
        link = self._pending_server_link
        if not link:
            raise RuntimeError("تعذر ربط العملية المحلية برقم السيرفر")
        cur.execute(
            "UPDATE transactions SET server_tx_id=?, client_tx_id=? WHERE id=?",
            (link["server_tx_id"], link["client_tx_id"], int(local_tx_id)),
        )
        self._pending_server_link = None

    def _clear_pending_server_link(self):
        self._pending_server_link = None

    def _server_account_ids(self):
        rows = self.server_request("GET", "/api/v1/accounts")
        return {row["name"]: int(row["id"]) for row in rows}

    def _server_customer_ids(self):
        rows = self.server_request("GET", "/api/v1/customers")
        return {row["name"]: int(row["id"]) for row in rows}

    def build_topbar(self):
        self.topbar = tk.Frame(
            self.root, bg="#FFFFFF", height=68,
            highlightbackground="#E4E9F2", highlightthickness=1
        )
        self.topbar.pack(fill="x")
        self.topbar.pack_propagate(False)

        self.server_status_label = tk.Label(
            self.topbar, text="● فحص السيرفر...",
            bg="#FFF7E8", fg="#B54708",
            font=("Segoe UI", 9, "bold"), padx=10, pady=6
        )
        self.server_status_label.pack(side="left", padx=(8,4), pady=16)
        self.server_status_label.bind("<Button-1>", lambda e: self.refresh_server_status())
        self.root.after(250, self.refresh_server_status)

        business_name = self.get_setting("business_name", "نظام الإدارة المالية")
        tk.Label(
            self.topbar, text=business_name,
            bg="#FFFFFF", fg="#14213D",
            font=("Segoe UI", 18, "bold")
        ).pack(side="right", padx=22)

        tk.Label(
            self.topbar,
            text=f"👤 {self.username}   |   {self.role}",
            bg="#FFFFFF", fg="#667085",
            font=("Segoe UI", 9)
        ).pack(side="right", padx=8)

        if self.has_permission("reports"):
            tk.Button(
                self.topbar, text="📋 كشف الوردية",
                command=self.show_today_report,
                bg="#EEF4FF", fg="#1D4ED8", relief="flat",
                activebackground="#DCE8FF", cursor="hand2",
                font=("Segoe UI", 10, "bold"), padx=14, pady=8
            ).pack(side="left", padx=(14,5), pady=12)

        if self.has_permission("end_shift"):
            tk.Button(
                self.topbar, text="🔴 نهاية الوردية",
                command=self.show_end_shift,
                bg="#FFF0F0", fg="#B42318", relief="flat",
                activebackground="#FFDADA", cursor="hand2",
                font=("Segoe UI", 10, "bold"), padx=14, pady=8
            ).pack(side="left", padx=5, pady=12)

    def build_sidebar(self):
        # V7.10: no top bar. Server/user/shift controls live in the sidebar.
        self.sidebar = tk.Frame(self.root, bg="#12233F", width=238)
        self.sidebar.pack(side="right", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(self.sidebar, text="نظام الإدارة المالية", bg="#12233F", fg="white",
                 font=("Segoe UI",14,"bold"), pady=10).pack(fill="x")
        tk.Label(self.sidebar, text=f"V{APP_VERSION}", bg="#12233F", fg="#8DB7FF",
                 font=("Consolas",9,"bold")).pack(fill="x", pady=(0,4))
        tk.Label(self.sidebar, text=f"👤 {self.username}  |  {self.role}", bg="#12233F", fg="#B9C7DA",
                 font=("Segoe UI",8)).pack(fill="x", pady=(0,6))

        self.server_status_label=tk.Label(self.sidebar,text="● فحص السيرفر...",bg="#1E293B",fg="#F59E0B",
                                          font=("Segoe UI",8,"bold"),padx=7,pady=5,cursor="hand2")
        self.server_status_label.pack(fill="x",padx=10,pady=(0,6))
        self.server_status_label.bind("<Button-1>",lambda e:self.refresh_server_status())
        self.root.after(250,self.refresh_server_status)

        self.dark_mode_button=tk.Button(self.sidebar,
            text="☀ الوضع الفاتح" if self.is_dark_mode else "🌙 الوضع الداكن",
            command=self.toggle_dark_mode,bg="#1E3A5F",fg="white",activebackground="#294B75",
            activeforeground="white",relief="flat",bd=0,font=("Segoe UI",9,"bold"),pady=7,cursor="hand2")
        self.dark_mode_button.pack(fill="x",padx=10,pady=(0,7))

        quick=tk.Frame(self.sidebar,bg="#12233F")
        quick.pack(fill="x",padx=8,pady=(0,6))
        if self.has_permission("reports"):
            tk.Button(quick,text="📋 كشف الوردية",command=self.show_today_report,bg="#183250",fg="#DCE8FF",
                      activebackground="#24496F",activeforeground="white",relief="flat",bd=0,font=("Segoe UI",8,"bold"),pady=6).pack(fill="x",pady=2)
        if self.has_permission("end_shift"):
            tk.Button(quick,text="🔴 نهاية الوردية",command=self.show_end_shift,bg="#4A2530",fg="#FFD7D7",
                      activebackground="#65313F",activeforeground="white",relief="flat",bd=0,font=("Segoe UI",8,"bold"),pady=6).pack(fill="x",pady=2)

        items=[("🏠  الرئيسية",self.show_dashboard,None)]
        candidates=[
            ("💸  العمليات",self.show_operations,"operations"),("🧾  سجل العمليات",self.show_operation_log,"operations"),
            ("📖  كشف الحساب",self.show_account_statement,"statements"),("🏦  الحسابات",self.show_accounts,"accounts"),
            ("👥  العملاء والديون",self.show_debts,"customers"),("📊  التقارير",self.show_reports,"reports"),
            ("⚖️  مطابقة الأرصدة",self.show_balance_compare,"reconcile"),("🔍  سجل التدقيق",self.show_audit_log,"audit"),
            ("📱  الهاتف",self.show_mobile_access,None),("⚙️  الإعدادات",self.show_settings,"settings")]
        items.extend([x for x in candidates if self.has_permission(x[2])])
        if self.role=="admin": items.insert(-2,("👤  المستخدمون والصلاحيات",self.show_users,None))
        items.append(("🚪  تسجيل الخروج",self.logout,None))
        for label,cmd,_perm in items:
            b=tk.Button(self.sidebar,text=label,command=cmd,bg="#12233F",fg="#E6ECF5",
                        activebackground="#1E3A5F",activeforeground="white",relief="flat",bd=0,anchor="e",
                        font=("Segoe UI",9,"bold"),padx=16,pady=8,cursor="hand2")
            b.pack(fill="x",padx=8,pady=1)
        tk.Label(self.sidebar,text="Developed by\nAnas alomran",bg="#12233F",fg="#8EA3BF",
                 font=("Segoe UI",8),pady=10).pack(side="bottom",fill="x")

    def build_content(self):
        self.content_outer = tk.Frame(self.root, bg="#F5F7FB")
        self.content_outer.pack(side="left", fill="both", expand=True)

        self.page_canvas = tk.Canvas(
            self.content_outer, bg="#F5F7FB",
            highlightthickness=0, bd=0
        )
        self.page_vscroll = ttk.Scrollbar(
            self.content_outer, orient="vertical",
            command=self.page_canvas.yview
        )
        self.page_canvas.configure(yscrollcommand=self.page_vscroll.set)

        self.page_vscroll.pack(side="right", fill="y")
        self.page_canvas.pack(side="left", fill="both", expand=True)

        self.content = ttk.Frame(self.page_canvas, padding=18)
        self._content_window = self.page_canvas.create_window(
            (0,0), window=self.content, anchor="nw"
        )

        self.content.bind(
            "<Configure>",
            lambda e: self.page_canvas.configure(
                scrollregion=self.page_canvas.bbox("all")
            )
        )
        self.page_canvas.bind(
            "<Configure>",
            lambda e: self.page_canvas.itemconfigure(
                self._content_window, width=e.width
            )
        )

        def page_wheel(event):
            try:
                step = int(-event.delta/120)
                if step == 0:
                    step = -1 if event.delta > 0 else 1
                self.page_canvas.yview_scroll(step*3, "units")
                return "break"
            except Exception:
                return None

        self.page_canvas.bind("<MouseWheel>", page_wheel, add="+")
        self.content.bind("<MouseWheel>", page_wheel, add="+")
        self.root.bind_all("<MouseWheel>", self._on_global_mousewheel, add="+")
        self.root.bind_all("<Shift-MouseWheel>", self._on_global_shift_mousewheel, add="+")

    def _scrollable_parent(self, widget):
        w = widget
        while w is not None:
            if isinstance(w, (ttk.Treeview, tk.Canvas, tk.Text)):
                return w
            try:
                parent_name = w.winfo_parent()
                if not parent_name:
                    break
                w = w._nametowidget(parent_name)
            except Exception:
                break
        return None

    def _on_global_mousewheel(self, event):
        try:
            target = self.root.winfo_containing(event.x_root, event.y_root)
            if target is None:
                return None
            if target.winfo_toplevel() is not self.root:
                return None

            scrollable = self._scrollable_parent(target)
            amount = -1 if event.delta > 0 else 1

            if isinstance(scrollable, ttk.Treeview):
                scrollable.yview_scroll(amount * 3, "units")
                return "break"
            if isinstance(scrollable, tk.Text):
                scrollable.yview_scroll(amount * 3, "units")
                return "break"

            self.page_canvas.yview_scroll(amount * 3, "units")
            return "break"
        except Exception:
            return None

    def _on_global_shift_mousewheel(self, event):
        try:
            target = self.root.winfo_containing(event.x_root, event.y_root)
            scrollable = self._scrollable_parent(target)
            amount = -1 if event.delta > 0 else 1
            if isinstance(scrollable, ttk.Treeview):
                scrollable.xview_scroll(amount * 3, "units")
                return "break"
            if isinstance(scrollable, tk.Canvas) and scrollable is not self.page_canvas:
                try:
                    scrollable.xview_scroll(amount * 3, "units")
                    return "break"
                except Exception:
                    pass
        except Exception:
            pass
        return None

    def scroll_page_top(self):
        try:
            self.page_canvas.yview_moveto(0)
        except Exception:
            pass

    def clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()
        self.root.after_idle(self.refresh_english_digits)
        self.root.after_idle(self.scroll_page_top)
        self.root.after_idle(self.apply_theme)

    def account_names(self):
        conn = get_db()
        rows = conn.execute("""
            SELECT name FROM accounts
            WHERE active=1
            ORDER BY id
        """).fetchall()
        conn.close()
        return [r[0] for r in rows]

    def get_balance(self, account):
        conn = get_db()
        row = conn.execute("SELECT balance FROM accounts WHERE name=?", (account,)).fetchone()
        conn.close()
        return row[0] if row else 0

    def change_balance(self, cur, account, amount):
        if not account:
            return
        row = cur.execute(
            "SELECT balance FROM accounts WHERE name=?",
            (account,)
        ).fetchone()
        if not row:
            raise ValueError(f"الحساب غير موجود: {account}")

        current = float(row[0])
        new_balance = current + float(amount)

        if float(amount) < 0 and new_balance < -0.0005:
            raise ValueError(
                f"الرصيد غير كافٍ في الحساب: {account} | "
                f"الرصيد الحالي {current:,.3f} JD | "
                f"المطلوب {abs(float(amount)):,.3f} JD"
            )

        cur.execute(
            "UPDATE accounts SET balance=? WHERE name=?",
            (new_balance, account)
        )

    def enable_clipboard_shortcuts(self, widget):
        """Ctrl+A/C/V/X + قائمة زر يمين للنسخ واللصق."""
        def select_all(event):
            w = event.widget
            try:
                if isinstance(w, tk.Text):
                    w.tag_add("sel", "1.0", "end-1c")
                else:
                    w.select_range(0, "end")
                    w.icursor("end")
            except Exception:
                pass
            return "break"

        def do_copy(event):
            try: event.widget.event_generate("<<Copy>>")
            except Exception: pass
            return "break"

        def do_paste(event):
            try: event.widget.event_generate("<<Paste>>")
            except Exception: pass
            return "break"

        def do_cut(event):
            try: event.widget.event_generate("<<Cut>>")
            except Exception: pass
            return "break"

        def popup(event):
            w = event.widget
            menu = tk.Menu(w, tearoff=0)
            menu.add_command(label="نسخ", command=lambda: w.event_generate("<<Copy>>"))
            menu.add_command(label="لصق", command=lambda: w.event_generate("<<Paste>>"))
            menu.add_command(label="قص", command=lambda: w.event_generate("<<Cut>>"))
            menu.add_separator()
            menu.add_command(label="تحديد الكل", command=lambda: (
                w.select_range(0, "end") if hasattr(w, "select_range") else None
            ))
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()
            return "break"

        for seq, fn in [
            ("<Control-a>", select_all), ("<Control-A>", select_all),
            ("<Control-c>", do_copy), ("<Control-C>", do_copy),
            ("<Control-v>", do_paste), ("<Control-V>", do_paste),
            ("<Control-x>", do_cut), ("<Control-X>", do_cut),
            ("<Button-3>", popup),
        ]:
            try:
                widget.bind(seq, fn, add="+")
            except Exception:
                pass

    def enable_edit_shortcuts_recursive(self, parent):
        try:
            children = parent.winfo_children()
        except Exception:
            return
        for w in children:
            if isinstance(w, (tk.Entry, ttk.Entry, ttk.Combobox, tk.Text)):
                self.enable_clipboard_shortcuts(w)
            self.enable_edit_shortcuts_recursive(w)

    def show_insufficient_balance(self, account, current, required=None, parent=None):
        win = tk.Toplevel(parent or self.root)
        win.title("رصيد غير كافٍ")
        win.geometry("540x300")
        win.resizable(False, False)
        try:
            win.transient(parent or self.root)
            win.grab_set()
        except Exception:
            pass

        box = tk.Frame(win, bg="#FFF4F2", padx=24, pady=20)
        box.pack(fill="both", expand=True)

        tk.Label(
            box, text="⚠ الرصيد غير كافٍ",
            bg="#FFF4F2", fg="#B42318",
            font=("Segoe UI", 19, "bold")
        ).pack(pady=(8,12))

        tk.Label(
            box, text=f"الحساب: {account}",
            bg="#FFF4F2", fg="#344054",
            font=("Segoe UI", 13, "bold")
        ).pack(pady=4)

        tk.Label(
            box, text=f"الرصيد الحالي: {float(current):,.3f} JD",
            bg="#FFF4F2", fg="#101828",
            font=("Consolas", 14, "bold")
        ).pack(pady=4)

        if required is not None:
            tk.Label(
                box, text=f"المبلغ المطلوب من الحساب: {float(required):,.3f} JD",
                bg="#FFF4F2", fg="#101828",
                font=("Consolas", 12, "bold")
            ).pack(pady=4)

        tk.Label(
            box, text="تم رفض العملية ولم يتم تغيير أي رصيد.",
            bg="#FFF4F2", fg="#B42318",
            font=("Segoe UI", 11, "bold")
        ).pack(pady=(10,8))

        tk.Button(
            box, text="موافق", command=win.destroy,
            bg="#B42318", fg="white", relief="flat",
            font=("Segoe UI", 10, "bold"),
            padx=28, pady=8
        ).pack(pady=5)

    def validate_effect_balances(self, effects, parent=None):
        for account, delta in effects.items():
            if float(delta) < 0:
                current = float(self.get_balance(account))
                if current + float(delta) < -0.0005:
                    self.show_insufficient_balance(
                        account, current, abs(float(delta)), parent
                    )
                    return False
        return True

    def check_recent_duplicate(self, op, src, dst, amount, commission, customer_name="", parent=None):
        """Warn before saving a transaction that closely matches a recent server transaction."""
        if self.get_setting("duplicate_warning","1") != "1":
            return True
        try:
            data=self.server_request("GET","/api/v2/mobile/transactions?limit=40",timeout=0.8)
            now=datetime.now()
            for t in data.get("items",[]) if isinstance(data,dict) else []:
                if str(t.get("status") or "") not in ("active","modified"): continue
                if str(t.get("op_type") or "") != str(op): continue
                if abs(int(t.get("amount_fils") or 0)-int(round(float(amount)*1000)))>0: continue
                if abs(int(t.get("commission_fils") or 0)-int(round(float(commission)*1000)))>0: continue
                if customer_name and str(t.get("customer_name") or "") != customer_name: continue
                created=str(t.get("created_at") or "").replace("Z","")
                try: dt=datetime.fromisoformat(created)
                except Exception: continue
                if abs((now-dt).total_seconds())>180: continue
                moves=t.get("movements") or []
                neg=[m.get("account_name","") for m in moves if int(m.get("amount_fils") or 0)<0 and m.get("entry_type")!="commission"]
                pos=[m.get("account_name","") for m in moves if int(m.get("amount_fils") or 0)>0 and m.get("entry_type")!="commission"]
                if src and neg and src not in neg: continue
                if dst and pos and dst not in pos: continue
                return messagebox.askyesno("عملية مشابهة حديثاً",f"⚠ توجد عملية مشابهة خلال آخر 3 دقائق.\n\n{op} — {float(amount):,.3f} JD\nServer TX: {t.get('id')}\n\nهل تريد المتابعة رغم ذلك؟",parent=parent or self.root)
        except Exception:
            pass
        return True

    def setup_entry(self, entry, select_all_on_focus=True):
        self.enable_clipboard_shortcuts(entry)
        if select_all_on_focus:
            entry.bind("<FocusIn>", lambda e: entry.select_range(0, "end"), add="+")
        return entry

    def quick_account_buttons(self, parent, combo, accounts):
        f = ttk.Frame(parent)
        f.pack(fill="x", pady=(0,5))
        preferred = ["النقد كاش", "البنك الإسلامي", "البنك العربي",
                     "محفظة أورنج موني", "إي فواتيركم"]
        shown = 0
        for name in preferred:
            if name in accounts:
                ttk.Button(
                    f, text=name,
                    command=lambda n=name: combo.set(n)
                ).pack(side="right", padx=2)
                shown += 1

        # إذا كانت هناك حسابات جديدة، نظهر أول حسابين منها كاختصارات أيضاً.
        extras = [a for a in accounts if a not in preferred][:2]
        for name in extras:
            ttk.Button(
                f, text=name,
                command=lambda n=name: combo.set(n)
            ).pack(side="right", padx=2)

    def get_setting(self, key, default=""):
        conn = get_db()
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        conn.close()
        return row[0] if row else default

    def set_setting(self, key, value):
        conn = get_db()
        conn.execute("""
            INSERT INTO settings(key,value) VALUES(?,?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value
        """, (key, str(value)))
        conn.commit()
        conn.close()

    def to_english_digits(self, value):
        """تحويل أي أرقام عربية أو فارسية إلى ASCII 0-9."""
        s = str(value)
        out = []
        for ch in s:
            code = ord(ch)
            if 0x0660 <= code <= 0x0669:
                out.append(chr(ord("0") + code - 0x0660))
            elif 0x06F0 <= code <= 0x06F9:
                out.append(chr(ord("0") + code - 0x06F0))
            elif code == 0x066B:
                out.append(".")
            elif code == 0x066C:
                out.append(",")
            else:
                out.append(ch)
        return "".join(out)

    def ltr_number(self, value, decimals=3, signed=False):
        """تنسيق مبلغ بدون أي رموز اتجاه مخفية."""
        n = float(value)
        body = f"{n:,.{decimals}f}"
        if signed and n > 0:
            body = "+" + body
        return body + " JD"

    def ltr_text_numbers(self, value):
        """تحويل الأرقام إلى الإنجليزية فقط، بدون LRI/PDI أو أي رموز مخفية."""
        return self.to_english_digits(value).replace("\u2066","").replace("\u2069","")

    def fmt_money(self, value):
        return f"{float(value):,.3f} JD"

    def parse_number(self, value):
        # يقبل 1,115.000 و 1,115.000 JD ويزيل أي رموز قديمة من النسخ السابقة.
        s = self.to_english_digits(value)
        s = s.replace("\u2066","").replace("\u2069","")
        s = s.replace("JD","").replace("jd","").strip()
        s = s.replace(",", "")
        return float(s)

    def normalize_widget_digits(self, widget=None):
        """فرض الأرقام الإنجليزية على النصوص والحقول والجداول الظاهرة."""
        if widget is None:
            widget = self.root

        # Labels / Buttons / Labelframes and similar widgets with a text option.
        try:
            current = widget.cget("text")
            if isinstance(current, str):
                fixed = self.to_english_digits(current).replace("\u2066","").replace("\u2069","")
                if fixed != current:
                    widget.configure(text=fixed)
        except Exception:
            pass

        # Entry and Combobox content.
        try:
            if isinstance(widget, (tk.Entry, ttk.Entry, ttk.Combobox)):
                current = widget.get()
                fixed = self.to_english_digits(current).replace("\u2066","").replace("\u2069","")
                if fixed != current:
                    old_state = None
                    try:
                        old_state = widget.cget("state")
                        if old_state == "readonly":
                            widget.configure(state="normal")
                    except Exception:
                        pass
                    widget.delete(0, "end")
                    widget.insert(0, fixed)
                    if old_state == "readonly":
                        widget.configure(state="readonly")
        except Exception:
            pass

        # tk.Text report areas.
        try:
            if isinstance(widget, tk.Text):
                current = widget.get("1.0", "end-1c")
                fixed = self.to_english_digits(current).replace("\u2066","").replace("\u2069","")
                if fixed != current:
                    old_state = str(widget.cget("state"))
                    if old_state == "disabled":
                        widget.configure(state="normal")
                    widget.delete("1.0", "end")
                    widget.insert("1.0", fixed)
                    if old_state == "disabled":
                        widget.configure(state="disabled")
        except Exception:
            pass

        # Treeview headings and cell values.
        try:
            if isinstance(widget, ttk.Treeview):
                for col in widget["columns"]:
                    try:
                        heading = widget.heading(col).get("text", "")
                        fixed_heading = self.to_english_digits(heading)
                        if fixed_heading != heading:
                            widget.heading(col, text=fixed_heading)
                    except Exception:
                        pass

                for item in widget.get_children(""):
                    values = list(widget.item(item, "values"))
                    fixed_values = [self.to_english_digits(v) for v in values]
                    if fixed_values != values:
                        widget.item(item, values=fixed_values)
        except Exception:
            pass

        for child in widget.winfo_children():
            self.normalize_widget_digits(child)

    def refresh_english_digits(self):
        self.normalize_widget_digits(self.root)
        # Repeat shortly after screen creation because some reports populate widgets after drawing.
        self.root.after(120, lambda: self.normalize_widget_digits(self.root))

    def show_dashboard(self):
        self.clear_content()
        ttk.Label(self.content,text="لوحة التحكم",font=("Segoe UI",22,"bold")).pack(anchor="e",pady=(2,4))
        ttk.Label(self.content,text="ملخص تشغيلي مباشر لليوم والوردية الحالية — السيرفر هو المرجع عند الاتصال",font=("Segoe UI",10)).pack(anchor="e",pady=(0,10))

        accounts=[]; shift_id=None; today_comm=0.0; today_count=0; today_amount=0.0
        source_label="محلي"; recent=[]; server_ok=False
        today_str=datetime.now().strftime("%Y-%m-%d")

        try:
            remote_accounts=self.server_request("GET","/api/v1/accounts",timeout=0.9)
            accounts=[(r.get("name", ""), int(r.get("balance_fils") or 0)/1000.0) for r in remote_accounts]
            try:
                sh=self.server_request("GET","/api/v2/mobile/shift",timeout=0.8)
                shift_id=sh.get("id") if isinstance(sh,dict) else None
            except Exception:
                shift_id=None
            try:
                rep=self.server_request("GET",f"/api/v2/mobile/report-summary?date_from={today_str}&date_to={today_str}",timeout=0.9)
                today_comm=int(rep.get("net_commission_fils") or 0)/1000.0
                today_count=int(rep.get("commercial_count") or 0)
                today_amount=int(rep.get("commercial_amount_fils") or 0)/1000.0
            except Exception:
                pass
            try:
                tx=self.server_request("GET",f"/api/v2/mobile/transactions?limit=8&date_from={today_str}&date_to={today_str}",timeout=0.9)
                for t in tx.get("items",[]) if isinstance(tx,dict) else []:
                    moves=t.get("movements") or []
                    neg=[m for m in moves if int(m.get("amount_fils") or 0)<0 and m.get("entry_type")!="commission"]
                    pos=[m for m in moves if int(m.get("amount_fils") or 0)>0 and m.get("entry_type")!="commission"]
                    recent.append({
                        "time":str(t.get("created_at") or ""),"type":t.get("op_type") or "",
                        "from":neg[0].get("account_name","") if neg else "",
                        "to":pos[0].get("account_name","") if pos else "",
                        "amount":int(t.get("amount_fils") or 0)/1000.0,
                        "comm":int(t.get("commission_fils") or 0)/1000.0,
                    })
            except Exception:
                recent=[]
            source_label="السيرفر"; server_ok=True
        except Exception:
            conn=get_db()
            accounts=conn.execute("SELECT name,balance FROM accounts WHERE active=1 ORDER BY id").fetchall()
            shift=conn.execute("SELECT id,started_at,business_date FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()
            shift_id=shift[0] if shift else None
            day_rows=conn.execute("""SELECT op_type,amount,commission,created_at,source_account,destination_account,status
                                     FROM transactions WHERE substr(created_at,1,10)=?
                                     ORDER BY datetime(created_at) DESC,id DESC""",(today_str,)).fetchall()
            accounting_only={"تسوية رصيد","رصيد افتتاحي","مطابقة وردية"}
            for r in day_rows:
                op=str(r[0] or ""); status=str(r[6] or "active")
                if status not in ("active","modified"): continue
                today_comm += float(r[2] or 0)
                if op not in accounting_only and not op.startswith("عكس:"):
                    today_count += 1; today_amount += float(r[1] or 0)
            for r in day_rows[:8]:
                recent.append({"time":r[3] or "","type":r[0] or "","from":r[4] or "","to":r[5] or "","amount":float(r[1] or 0),"comm":float(r[2] or 0)})
            conn.close()

        total=sum(float(b) for _,b in accounts)
        negative_accounts=[(n,float(b)) for n,b in accounts if float(b)<-0.0005]

        sync_line=ttk.Frame(self.content); sync_line.pack(fill="x",pady=(0,7))
        ttk.Label(sync_line,text=f"مصدر البيانات: {source_label}   |   تاريخ اليوم: {today_str}",font=("Segoe UI",9,"bold")).pack(side="right")
        ttk.Button(sync_line,text="🔄 تحديث اللوحة",command=self.show_dashboard).pack(side="left")

        if not server_ok:
            warn=tk.Frame(self.content,bg="#FFF4E5",highlightbackground="#F7B955",highlightthickness=1); warn.pack(fill="x",pady=(0,8))
            tk.Label(warn,text="⚠ السيرفر غير متاح حالياً — يتم عرض البيانات المحلية المتوفرة.",bg="#FFF4E5",fg="#8A4B08",font=("Segoe UI",9,"bold")).pack(anchor="e",padx=10,pady=7)
        if negative_accounts:
            names="، ".join(f"{n} ({b:,.3f} JD)" for n,b in negative_accounts[:4])
            warn=tk.Frame(self.content,bg="#FEF3F2",highlightbackground="#FDA29B",highlightthickness=1); warn.pack(fill="x",pady=(0,8))
            tk.Label(warn,text=f"⚠ تنبيه أرصدة سالبة: {names}",bg="#FEF3F2",fg="#B42318",font=("Segoe UI",9,"bold")).pack(anchor="e",padx=10,pady=7)

        cards=tk.Frame(self.content,bg="#F5F7FB"); cards.pack(fill="x",pady=(0,10))
        data=[
            ("إجمالي الأرصدة",f"{total:,.3f} JD","#EAF2FF","#1D4ED8"),
            ("عمليات اليوم",str(today_count),"#F4F3FF","#6941C6"),
            ("حركة اليوم",f"{today_amount:,.3f} JD","#FFF7E8","#B54708"),
            ("عمولات اليوم",f"{today_comm:,.3f} JD","#ECFDF3","#027A48"),
            ("رقم الوردية",str(shift_id) if shift_id else "-","#F9F5FF","#7F56D9"),
        ]
        for i,(title,value,bg,fg) in enumerate(data):
            card=tk.Frame(cards,bg=bg,highlightbackground="#E0E6EF",highlightthickness=1); card.grid(row=0,column=i,padx=4,sticky="nsew"); cards.columnconfigure(i,weight=1)
            tk.Label(card,text=title,bg=bg,fg="#475467",font=("Segoe UI",9,"bold")).pack(anchor="e",padx=10,pady=(10,3))
            tk.Label(card,text=value,bg=bg,fg=fg,font=("Consolas",14,"bold")).pack(anchor="e",padx=10,pady=(0,10))

        body=ttk.Frame(self.content); body.pack(fill="both",expand=True)
        body.columnconfigure(0,weight=1); body.columnconfigure(1,weight=1); body.rowconfigure(0,weight=1)

        accounts_box=ttk.LabelFrame(body,text=" الحسابات "); accounts_box.grid(row=0,column=1,sticky="nsew",padx=(5,0)); accounts_box.rowconfigure(0,weight=1); accounts_box.columnconfigure(0,weight=1)
        atree=ttk.Treeview(accounts_box,columns=("name","balance"),show="headings",height=12); atree.heading("name",text="الحساب"); atree.heading("balance",text="الرصيد")
        atree.column("name",width=260,anchor="center",stretch=True); atree.column("balance",width=140,anchor="center")
        avs=ttk.Scrollbar(accounts_box,orient="vertical",command=atree.yview); atree.configure(yscrollcommand=avs.set); atree.grid(row=0,column=0,sticky="nsew",padx=(5,0),pady=5); avs.grid(row=0,column=1,sticky="ns",pady=5)
        for name,balance in accounts: atree.insert("","end",values=(name,f"{float(balance):,.3f} JD"))

        recent_box=ttk.LabelFrame(body,text=" آخر عمليات اليوم "); recent_box.grid(row=0,column=0,sticky="nsew",padx=(0,5)); recent_box.rowconfigure(0,weight=1); recent_box.columnconfigure(0,weight=1)
        rtree=ttk.Treeview(recent_box,columns=("time","type","amount","comm"),show="headings",height=12)
        for c,h,w in [("time","الوقت",125),("type","العملية",150),("amount","المبلغ",110),("comm","العمولة",95)]:
            rtree.heading(c,text=h); rtree.column(c,width=w,anchor="center",stretch=(c=="type"))
        rvs=ttk.Scrollbar(recent_box,orient="vertical",command=rtree.yview); rtree.configure(yscrollcommand=rvs.set); rtree.grid(row=0,column=0,sticky="nsew",padx=(5,0),pady=5); rvs.grid(row=0,column=1,sticky="ns",pady=5)
        for r in recent:
            tm=str(r.get("time") or "").replace("T"," "); tm=tm[:19] if len(tm)>19 else tm
            rtree.insert("","end",values=(self.to_english_digits(tm),r.get("type") or "",f"{float(r.get('amount') or 0):,.3f} JD",f"{float(r.get('comm') or 0):,.3f} JD"))
        if not recent: rtree.insert("","end",values=("-","لا توجد عمليات اليوم","0.000 JD","0.000 JD"))

        actions=ttk.Frame(self.content); actions.pack(fill="x",pady=(8,0))
        ttk.Button(actions,text="💸 عملية جديدة",command=self.show_operations).pack(side="right",padx=4)
        ttk.Button(actions,text="🧾 سجل العمليات",command=self.show_operation_log).pack(side="right",padx=4)
        ttk.Button(actions,text="📊 التقارير",command=self.show_reports).pack(side="right",padx=4)
        ttk.Button(actions,text="🚨 التنبيهات المالية",command=self.show_financial_alerts).pack(side="right",padx=4)
        if self.has_permission("share"):
            ttk.Button(actions,text="📤 مشاركة الأرصدة",command=lambda:self.share_text_choice("كشف الأرصدة",self.build_balances_share_text())).pack(side="left",padx=4)

    def show_financial_alerts(self):
        self.clear_content()
        ttk.Label(self.content,text="🚨 مركز التنبيهات المالية",font=("Segoe UI",20,"bold")).pack(anchor="e",pady=(2,5))
        ttk.Label(self.content,text="تنبيهات تشغيلية للمتابعة — لا تقوم هذه الشاشة بتغيير أي رصيد.",font=("Segoe UI",10)).pack(anchor="e",pady=(0,10))
        alerts=[]
        try:
            accounts=self.server_request("GET","/api/v1/accounts",timeout=0.9)
            for a in accounts:
                bal=int(a.get("balance_fils") or 0)/1000.0
                if bal < -0.0005: alerts.append(("حرج","رصيد سالب",a.get("name") or "",f"{bal:,.3f} JD"))
            try:
                customers=self.server_request("GET","/api/v1/customers",timeout=0.9)
                for c in customers:
                    debt=int(c.get("debt_fils") or c.get("balance_fils") or 0)/1000.0
                    limit=int(c.get("debt_limit_fils") or 0)/1000.0
                    if debt>0 and limit>0 and debt>=limit*0.8:
                        alerts.append(("مرتفع","دين عميل",c.get("name") or "",f"{debt:,.3f} / {limit:,.3f} JD"))
            except Exception: pass
            try:
                tx=self.server_request("GET","/api/v2/mobile/transactions?limit=100",timeout=0.9)
                corrections=0
                for t in tx.get("items",[]) if isinstance(tx,dict) else []:
                    typ=str(t.get("op_type") or ""); st=str(t.get("status") or "")
                    if typ.startswith("عكس:") or st in ("cancelled","modified"): corrections+=1
                if corrections: alerts.append(("مراجعة","عكس/تصحيح","آخر 100 عملية",f"{corrections} عملية"))
            except Exception: pass
            try:
                sh=self.server_request("GET","/api/v2/mobile/shift",timeout=0.9)
                diffs=[]
                for b in sh.get("balances",[]) if isinstance(sh,dict) else []:
                    d=int(b.get("difference_fils") or 0)/1000.0
                    if abs(d)>0.0005: diffs.append((b.get("account_name") or "",d))
                if diffs:
                    largest=max(diffs,key=lambda x:abs(x[1])); alerts.append(("حرج","فرق وردية",largest[0],f"{largest[1]:+,.3f} JD — {len(diffs)} حساب"))
            except Exception: pass
        except Exception as exc:
            alerts.append(("تنبيه","السيرفر غير متاح","تعذر تحديث التنبيهات",str(exc)[:90]))
        tree=ttk.Treeview(self.content,columns=("level","kind","subject","value"),show="headings",height=17)
        for c,h,w in [("level","المستوى",100),("kind","التنبيه",160),("subject","الحساب / العميل",280),("value","القيمة",220)]: tree.heading(c,text=h); tree.column(c,width=w,anchor="center",stretch=(c=="subject"))
        tree.pack(fill="both",expand=True,pady=6)
        for row in alerts: tree.insert("","end",values=row)
        if not alerts: tree.insert("","end",values=("سليم","لا توجد تنبيهات","لا توجد مؤشرات مالية حرجة حالياً","-"))
        bar=ttk.Frame(self.content); bar.pack(fill="x",pady=6)
        ttk.Button(bar,text="🔄 تحديث",command=self.show_financial_alerts).pack(side="right",padx=4)
        ttk.Button(bar,text="🧾 سجل العمليات",command=self.show_operation_log).pack(side="right",padx=4)
        ttk.Button(bar,text="🏠 لوحة التحكم",command=self.show_dashboard).pack(side="left",padx=4)

    def show_operations(self):
        if not self.require_permission("operations","العمليات"):
            return
        self.clear_content()

        ttk.Label(
            self.content, text="💸 العمليات",
            font=("Segoe UI", 20, "bold")
        ).pack(anchor="e", pady=(2,8))

        mode = self.get_setting("operation_view_mode", "بطاقات سريعة")

        mode_line = ttk.Frame(self.content)
        mode_line.pack(fill="x", pady=(0,8))
        ttk.Label(
            mode_line,
            text=f"طريقة العرض الحالية: {mode}",
            font=("Segoe UI",9,"bold")
        ).pack(side="right")
        ttk.Button(
            mode_line,text="🧾 فتح سجل العمليات",
            command=self.show_operation_log
        ).pack(side="left")

        default_operations = [
            "حوالة صادرة","حوالة واردة","دفع فاتورة","نقل أموال",
            "بيع بطاقة خلوية","سحب مالي","دين للعميل","سداد دين"
        ]
        raw_order=[x.strip() for x in self.get_setting("operation_order",",").split(",") if x.strip()]
        operations=[x for x in raw_order if x in default_operations]
        operations += [x for x in default_operations if x not in operations]
        density=self.get_setting("ui_density","compact")
        try: op_columns=max(2,min(4,int(self.get_setting("operation_columns","4"))))
        except Exception: op_columns=4
        # V7.40 Commercial workspace: configurable order and density.
        selector = tk.Frame(self.content, bg=self.theme_palette.get("bg","#F5F7FB"))
        selector.pack(fill="x", pady=(0,10))
        form_host = ttk.Frame(self.content)
        form_host.pack(fill="both", expand=True, pady=(0,20))
        active_op=tk.StringVar(value="")
        pill_buttons={}

        def paint_pills():
            palette={
                "حوالة صادرة":"#2563EB","حوالة واردة":"#0EA5E9","دفع فاتورة":"#059669","نقل أموال":"#7C3AED",
                "بيع بطاقة خلوية":"#EA580C","سحب مالي":"#DC2626","دين للعميل":"#B45309","سداد دين":"#16A34A"}
            for name,b in pill_buttons.items():
                selected=(name==active_op.get()); base=palette.get(name,"#475467")
                b.config(bg=base if selected else "#FFFFFF", fg="white" if selected else base,
                         activebackground=base, activeforeground="white",
                         highlightbackground=base, highlightthickness=3 if selected else 1)

        def open_operation(op):
            active_op.set(op); paint_pills()
            if mode == "النظام الأصلي":
                if op == "دين للعميل": self.debt_window(False)
                elif op == "سداد دين": self.debt_window(True)
                else: self.transaction_window(op)
            else:
                for w in form_host.winfo_children(): w.destroy()
                if op in ("دين للعميل","سداد دين"):
                    self.build_inline_debt_form(form_host, payment=(op=="سداد دين"))
                else:
                    self.build_card_transaction_form(form_host, op)

        icons={"حوالة صادرة":"↗","حوالة واردة":"↙","دفع فاتورة":"▣","نقل أموال":"⇄","بيع بطاقة خلوية":"▤","سحب مالي":"↓","دين للعميل":"👤","سداد دين":"✓"}
        op_pad_y=6 if density=="compact" else 12
        op_font=max(9,self.ui_font_size-1) if density=="compact" else self.ui_font_size+1
        for i,op in enumerate(operations):
            b=tk.Button(selector,text=f"{icons.get(op,'')}  {op}",command=lambda x=op:open_operation(x),
                        relief="flat",bd=0,padx=10,pady=op_pad_y,cursor="hand2",font=(self.ui_font,op_font,"bold"))
            col=(op_columns-1)-(i%op_columns)
            b.grid(row=i//op_columns,column=col,padx=4,pady=3,sticky="nsew")
            selector.columnconfigure(col,weight=1)
            pill_buttons[op]=b
        paint_pills()
        default_op=self.get_setting("default_operation","حوالة صادرة")
        if default_op not in operations: default_op="حوالة صادرة"
        if mode != "النظام الأصلي": open_operation(default_op)

        self.root.after_idle(
            lambda:self.page_canvas.configure(scrollregion=self.page_canvas.bbox("all"))
        )

    def edit_transaction(self, tree):
        if not self.require_permission("edit_transactions","تعديل العمليات"):
            return
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه","اختر عملية أولاً")
            return
        tx_id=int(tree.item(sel[0])["values"][0])

        conn=get_db()
        row=conn.execute("""
            SELECT id,op_type,source_account,destination_account,amount,
                   commission,commission_account,details,status,server_tx_id,client_tx_id
            FROM transactions WHERE id=?
        """,(tx_id,)).fetchone()
        conn.close()
        if not row:
            return
        if row[8]!="active":
            messagebox.showwarning("تنبيه","يمكن تعديل العمليات الفعالة فقط")
            return
        if row[1] in ("تسوية رصيد","رصيد افتتاحي","مطابقة وردية","دين للعميل","سداد دين"):
            messagebox.showwarning("تنبيه","هذا النوع لا يُعدل من سجل العمليات حالياً")
            return
        if not row[9]:
            messagebox.showwarning(
                "عملية قديمة غير مرتبطة",
                "هذه العملية أُنشئت قبل V7.10.0 ولا تحمل رقم السيرفر.\n"
                "للاختبار أنشئ عملية جديدة في V7.10.0 ثم عدّلها."
            )
            return

        win=tk.Toplevel(self.root)
        win.title(f"تعديل العملية #{tx_id}")
        win.geometry("560x590")
        win.minsize(500,500)
        f=ttk.Frame(win,padding=18); f.pack(fill="both",expand=True)
        ttk.Label(f,text=f"تعديل العملية #{tx_id}",font=(self.ui_font,15,"bold")).pack(anchor="e",pady=6)
        ttk.Label(f,text=f"Server #{row[9]}",font=("Consolas",9)).pack(anchor="e",pady=(0,5))

        accounts=self.account_names()
        ttk.Label(f,text="من الحساب").pack(anchor="e")
        src=ttk.Combobox(f,state="readonly",values=accounts); src.set(row[2] or ""); src.pack(fill="x",pady=4)
        ttk.Label(f,text="إلى الحساب").pack(anchor="e")
        dst=ttk.Combobox(f,state="readonly",values=[""]+accounts); dst.set(row[3] or ""); dst.pack(fill="x",pady=4)
        ttk.Label(f,text="المبلغ (JD)").pack(anchor="e")
        amount=ttk.Entry(f,justify="center"); amount.insert(0,f"{float(row[4]):.3f}"); amount.pack(fill="x",pady=4)
        ttk.Label(f,text="العمولة (JD)").pack(anchor="e")
        comm=ttk.Entry(f,justify="center"); comm.insert(0,f"{float(row[5]):.3f}"); comm.pack(fill="x",pady=4)
        ttk.Label(f,text="حساب العمولة").pack(anchor="e")
        ca=ttk.Combobox(f,state="readonly",values=[""]+accounts); ca.set(row[6] or ""); ca.pack(fill="x",pady=4)
        ttk.Label(f,text="البيان").pack(anchor="e")
        details=ttk.Entry(f,justify="right"); details.insert(0,row[7] or ""); details.pack(fill="x",pady=4)
        ttk.Label(f,text="سبب التعديل *").pack(anchor="e")
        reason=ttk.Entry(f,justify="right"); reason.pack(fill="x",pady=4)

        if row[1] == "سحب مالي":
            dst.set(""); dst.configure(state="disabled")
            comm.delete(0,"end"); comm.insert(0,"0.000"); comm.configure(state="disabled")
            ca.set(""); ca.configure(state="disabled")

        def save():
            why=reason.get().strip()
            if not why:
                messagebox.showwarning("تنبيه","سبب التعديل مطلوب",parent=win); return
            try:
                new_amt=self.parse_number(amount.get()); new_comm=self.parse_number(comm.get() or 0)
            except ValueError:
                messagebox.showerror("خطأ","القيم غير صحيحة",parent=win); return
            if new_amt<=0 or new_comm<0:
                messagebox.showerror("خطأ","تحقق من المبلغ والعمولة",parent=win); return
            if row[1] == "سحب مالي": new_comm=0.0

            old_src,old_dst=row[2],row[3]
            old_amt=float(row[4]); old_comm=float(row[5]); old_ca=row[6]
            new_src,new_dst,new_ca=src.get(),dst.get(),ca.get()
            if row[1] != "سحب مالي" and (not new_src or not new_dst):
                messagebox.showerror("خطأ","اختر حساب المصدر والوجهة",parent=win); return
            if row[1] != "بيع بطاقة خلوية" and new_src and new_dst and new_src==new_dst:
                messagebox.showwarning("تنبيه","اختر حسابين مختلفين",parent=win); return
            if new_comm>0 and not new_ca:
                messagebox.showerror("خطأ","اختر حساب العمولة",parent=win); return

            effects={}
            def add(acc,d):
                if acc: effects[acc]=effects.get(acc,0.0)+d
            add(old_src,+old_amt); add(old_dst,-old_amt)
            if old_ca: add(old_ca,-old_comm)
            add(new_src,-new_amt); add(new_dst,+new_amt)
            if new_ca: add(new_ca,+new_comm)
            for acc,delta in effects.items():
                if self.get_balance(acc)+delta < -0.0000001:
                    messagebox.showerror("تعذر التعديل",f"بعد التعديل سيصبح رصيد {acc} سالباً.",parent=win); return

            if not messagebox.askyesno("تأكيد التعديل","سيعكس السيرفر العملية القديمة وينشئ عملية بديلة جديدة.\nهل تريد المتابعة؟",parent=win):
                return

            try:
                ids=self._server_account_ids()
                client_tx_id=str(uuid.uuid4())
                replacement_payload={
                    "client_tx_id":client_tx_id,
                    "op_type":row[1],
                    "source_account_id":ids.get(new_src) if new_src else None,
                    "destination_account_id":ids.get(new_dst) if new_dst else None,
                    "amount_fils":int(round(new_amt*1000)),
                    "commission_fils":int(round(new_comm*1000)),
                    "commission_account_id":ids.get(new_ca) if new_comm>0 and new_ca else None,
                    "customer_id":None,
                    "details":details.get().strip(),
                }
                server_new=self.server_request("POST",f"/api/v1/transactions/{int(row[9])}/edit",{
                    "reason":why,"replacement":replacement_payload
                },timeout=10.0)
            except Exception as exc:
                messagebox.showerror("رفض السيرفر التعديل",str(exc),parent=win); return

            conn=get_db(); cur=conn.cursor()
            try:
                for acc,delta in effects.items():
                    cur.execute("UPDATE accounts SET balance=balance+? WHERE name=?",(delta,acc))
                now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                shift=cur.execute("SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()
                sid=shift[0] if shift else None
                cur.execute("""
                    INSERT INTO transactions(
                        created_at,op_type,source_account,destination_account,
                        amount,commission,commission_account,details,
                        performed_by,status,reversed_transaction_id,shift_id,
                        server_tx_id,client_tx_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,(
                    now,row[1],new_src,new_dst,new_amt,new_comm,new_ca,
                    (details.get().strip()+f" | تعديل للعملية #{tx_id} | السبب: {why}").strip(),
                    self.username,"active",tx_id,sid,int(server_new["id"]),
                    str(server_new.get("client_tx_id") or client_tx_id)
                ))
                replacement=cur.lastrowid
                cur.execute("UPDATE transactions SET status='modified',reversed_transaction_id=? WHERE id=?",(replacement,tx_id))
                conn.commit(); conn.close()
                self.log("تعديل عملية",f"#{tx_id} -> #{replacement} | Server {row[9]} -> {server_new['id']} | {why}")
                messagebox.showinfo("تم","تم تعديل العملية على السيرفر وتحديث النسخة المحلية.",parent=win)
                win.destroy(); self.show_operations()
            except Exception as e:
                conn.rollback(); conn.close()
                messagebox.showerror(
                    "تنبيه مزامنة مهم",
                    "السيرفر حفظ التعديل لكن تعذر تحديث النسخة المحلية.\n"
                    "لا تعِد تنفيذ التعديل. أرسل هذه الرسالة للمطور:\n"+str(e),parent=win
                )
        reason.bind("<Return>",lambda e:save())
        ttk.Button(f,text="✓ حفظ التعديل",command=save).pack(pady=14,ipadx=22,ipady=6)

    def cancel_transaction(self, tree):
        if not self.require_permission("cancel_transactions","إلغاء وعكس العمليات"):
            return
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه","اختر العملية المراد إلغاؤها"); return
        tx_id=int(tree.item(sel[0])["values"][0])
        conn=get_db(); cur=conn.cursor()
        row=cur.execute("""
            SELECT id,op_type,source_account,destination_account,amount,
                   commission,commission_account,details,status,reversed_transaction_id,
                   customer_name,server_tx_id,client_tx_id
            FROM transactions WHERE id=?
        """,(tx_id,)).fetchone()
        if not row:
            conn.close(); return
        if row[8] != "active":
            conn.close(); messagebox.showwarning("تنبيه","هذه العملية ليست فعالة ولا يمكن إلغاؤها مرة أخرى"); return
        if row[1] in ("تسوية رصيد","رصيد افتتاحي","مطابقة وردية"):
            conn.close(); messagebox.showwarning("تنبيه","هذا النوع لا يُلغى من سجل العمليات"); return
        if not row[11]:
            conn.close(); messagebox.showwarning(
                "عملية قديمة غير مرتبطة",
                "هذه العملية أُنشئت قبل V7.10.0 ولا تحمل رقم السيرفر.\n"
                "أنشئ عملية جديدة في V7.10.0 ثم اختبر الإلغاء عليها."
            ); return

        reason=self.simple_reason_dialog("سبب الإلغاء","اكتب سبب إلغاء العملية")
        if reason is None:
            conn.close(); return
        if not messagebox.askyesno("تأكيد الإلغاء",f"سيتم عكس العملية رقم {tx_id} بالكامل على السيرفر.\nهل أنت متأكد؟"):
            conn.close(); return

        _,op,src,dst,amount,commission,comm_acc,details,status,rev,customer_name,server_tx_id,client_tx_id=row
        effects={}
        def add(a,d):
            if a: effects[a]=effects.get(a,0.0)+d
        add(src,+float(amount)); add(dst,-float(amount))
        if comm_acc: add(comm_acc,-float(commission))
        for acc,delta in effects.items():
            balrow=cur.execute("SELECT balance FROM accounts WHERE name=?",(acc,)).fetchone()
            if balrow and float(balrow[0])+delta < -0.0000001:
                conn.close(); messagebox.showerror("تعذر الإلغاء",f"لا يمكن عكس العملية لأن رصيد {acc} سيصبح سالباً."); return

        debt_delta=0.0
        if op=="دين للعميل": debt_delta=-float(amount)
        elif op=="سداد دين": debt_delta=+float(amount)
        if customer_name and debt_delta<0:
            drow=cur.execute("SELECT debt_balance FROM customers WHERE name=?",(customer_name,)).fetchone()
            if not drow or float(drow[0])+debt_delta < -0.0000001:
                conn.close(); messagebox.showerror("تعذر الإلغاء","لا يمكن عكس العملية لأن دين العميل سيصبح سالباً."); return

        try:
            server_rev=self.server_request("POST",f"/api/v1/transactions/{int(server_tx_id)}/reverse",{"reason":reason},timeout=10.0)
        except Exception as exc:
            conn.close(); messagebox.showerror("رفض السيرفر الإلغاء",str(exc)); return

        try:
            for acc,delta in effects.items():
                cur.execute("UPDATE accounts SET balance=balance+? WHERE name=?",(delta,acc))
            if customer_name and abs(debt_delta)>0:
                cur.execute("UPDATE customers SET debt_balance=debt_balance+? WHERE name=?",(debt_delta,customer_name))
            now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            shift=cur.execute("SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()
            shift_id=shift[0] if shift else None
            cur.execute("""
                INSERT INTO transactions(
                    created_at,op_type,source_account,destination_account,
                    amount,commission,commission_account,customer_name,details,performed_by,
                    status,reversed_transaction_id,shift_id,server_tx_id,client_tx_id
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,(
                now,"عكس: "+op,dst,src,float(amount),-float(commission),comm_acc,customer_name or "",
                f"عكس العملية #{tx_id} | السبب: {reason}",self.username,
                "active",tx_id,shift_id,int(server_rev["id"]),str(server_rev.get("client_tx_id") or "")
            ))
            reversal_id=cur.lastrowid
            cur.execute("UPDATE transactions SET status='cancelled',reversed_transaction_id=? WHERE id=?",(reversal_id,tx_id))
            conn.commit(); conn.close()
            self.log("إلغاء وعكس عملية",f"#{tx_id} -> #{reversal_id} | Server {server_tx_id} -> {server_rev['id']} | {reason}")
            messagebox.showinfo("تم","تم إلغاء العملية وعكس آثارها على السيرفر والنسخة المحلية.")
            self.show_operations()
        except Exception as e:
            conn.rollback(); conn.close()
            messagebox.showerror(
                "تنبيه مزامنة مهم",
                "السيرفر نفذ الإلغاء لكن تعذر تحديث النسخة المحلية.\n"
                "لا تعِد الإلغاء. أرسل هذه الرسالة للمطور:\n"+str(e)
            )

    def simple_reason_dialog(self, title, prompt):
        result={"value":None}
        win=tk.Toplevel(self.root)
        win.title(title); win.geometry("460x220"); win.transient(self.root); win.grab_set()
        f=ttk.Frame(win,padding=20); f.pack(fill="both",expand=True)
        ttk.Label(f,text=prompt).pack(anchor="e",pady=6)
        e=ttk.Entry(f,justify="right"); e.pack(fill="x",pady=8); e.focus_set()
        def ok():
            v=e.get().strip()
            if not v:
                messagebox.showwarning("تنبيه","السبب مطلوب",parent=win); return
            result["value"]=v; win.destroy()
        e.bind("<Return>",lambda _e:ok())
        ttk.Button(f,text="حفظ",command=ok).pack(pady=10)
        self.root.wait_window(win)
        return result["value"]

    def show_audit_log(self):
        if not self.require_permission("audit","سجل التدقيق"):
            return
        self.clear_content()
        title=ttk.Frame(self.content); title.pack(fill="x",pady=10)
        ttk.Label(title,text="سجل التدقيق - السيرفر",font=("Segoe UI",20,"bold")).pack(side="right")
        source_label=ttk.Label(title,text="تحميل...",font=("Segoe UI",9,"bold")); source_label.pack(side="left")

        frame=ttk.Frame(self.content); frame.pack(fill="both",expand=True)
        cols=("id","time","user","action","tx","details")
        tree=ttk.Treeview(frame,columns=cols,show="headings")
        defs=[("id","#",60),("time","التاريخ والوقت",165),("user","المستخدم",120),
              ("action","الإجراء",150),("tx","Server TX",90),("details","التفاصيل",500)]
        for c,h,w in defs:
            tree.heading(c,text=h); tree.column(c,width=w,minwidth=60,anchor="center",stretch=(c=="details"))
        vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); hs=ttk.Scrollbar(frame,orient="horizontal",command=tree.xview)
        tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tree.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns"); hs.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

        def load():
            for item in tree.get_children(): tree.delete(item)
            try:
                rows=self.server_request("GET","/api/v1/audit?limit=1000",timeout=8.0)
                for r in rows:
                    when=str(r.get("created_at","")).replace("T"," ")[:19]
                    tree.insert("","end",values=(r.get("id",""),self.ltr_text_numbers(when),r.get("username","") or "",
                        r.get("action","") or "",r.get("transaction_id","") or "",self.ltr_text_numbers(r.get("details","") or "")))
                source_label.configure(text=f"● Server Audit | {len(rows)} سجل")
            except Exception as exc:
                conn=get_db(); rows=conn.execute("SELECT id,created_at,username,action,details FROM audit_log ORDER BY id DESC LIMIT 1000").fetchall(); conn.close()
                for r in rows:
                    tree.insert("","end",values=(r[0],self.ltr_text_numbers(r[1]),r[2] or "",r[3],"LOCAL",self.ltr_text_numbers(r[4] or "")))
                source_label.configure(text="⚠ سجل محلي - تعذر قراءة السيرفر")
                messagebox.showwarning("سجل التدقيق","تعذر قراءة سجل السيرفر، لذلك تم عرض السجل المحلي فقط.\n\n"+str(exc))
        ttk.Button(title,text="🔄 تحديث",command=load).pack(side="left",padx=8)
        load()

    def commission_buttons(self, parent, entry):
        f = ttk.Frame(parent)
        f.pack(pady=5)
        raw = self.get_setting("commission_presets", "0.250,0.500,0.750,1.000")
        try:
            values = [float(x.strip()) for x in raw.split(",") if x.strip()][:4]
        except Exception:
            values = [0.250, 0.500, 0.750, 1.000]

        for value in values:
            ttk.Button(
                f,
                text=f"{value:.3f}",
                command=lambda v=value: self.set_entry(entry, f"{v:.3f}")
            ).pack(side="left", padx=3)

    def set_entry(self, entry, value):
        entry.delete(0, "end")
        entry.insert(0, str(value))

    def _account_brand(self, name):
        n=name.lower()
        if "فواتير" in name:
            return ("#E9F8EF","#069B54","eFawateercom")
        if "الإسلامي" in name or "اسلامي" in name:
            return ("#FFF3E8","#C85A12","JIB")
        if "العربي" in name:
            return ("#EEF2FF","#174EA6","ARAB BANK")
        if "أورنج" in name or "اورنج" in name:
            if "rmej" in n:
                return ("#FFF0E6","#B54708","Orange RMEJ")
            if "وكيل" in name:
                return ("#FFF7E8","#D65A00","Orange Agent")
            return ("#FFF3E7","#F16E00","Orange Wallet")
        if "كاش" in name or "نقد" in name:
            return ("#ECFDF3","#027A48","CASH")
        return ("#F2F4F7","#475467","ACCOUNT")

    def _account_tiles(self, parent, accounts, variable, on_change=None):
        holder=tk.Frame(parent,bg="#FFFFFF")
        buttons={}

        def choose(name):
            variable.set(name)
            for acc,b in buttons.items():
                selected=(acc==name)
                bg="#E8F7EC" if selected else self._account_brand(acc)[0]
                border="#16A34A" if selected else "#D8DEE8"
                b.config(bg=bg,highlightbackground=border,highlightthickness=2 if selected else 1)
                for child in b.winfo_children():
                    try: child.config(bg=bg)
                    except Exception: pass
            if on_change:
                try: on_change(name)
                except TypeError: on_change()

        density=self.get_setting("ui_density","compact")
        try: cols=max(2,min(5,int(self.get_setting("account_columns","4"))))
        except Exception: cols=4
        tile_h=68 if density=="compact" else 92
        vpad=(6,1) if density=="compact" else (10,2)
        for i,name in enumerate(accounts):
            base_bg,fg,brand=self._account_brand(name)
            tile=tk.Frame(
                holder,bg=base_bg,
                highlightbackground="#D8DEE8",highlightthickness=1,
                cursor="hand2",height=tile_h
            )
            tile.grid(row=i//cols,column=i%cols,padx=4,pady=3 if density=="compact" else 5,sticky="nsew")
            holder.columnconfigure(i%cols,weight=1)

            # Brand badge: fast visual recognition without depending on external image files.
            badge={"Orange Wallet":"🟧  ORANGE WALLET","Orange Agent":"🟠  ORANGE AGENT","Orange RMEJ":"🔶  ORANGE RMEJ","eFawateercom":"🟩  eFAWATEERCOM","JIB":"🟧  JIB","ARAB BANK":"🟦  ARAB BANK","CASH":"💵  CASH"}.get(brand,"🏦  "+brand)
            tk.Label(tile,text=badge,bg=base_bg,fg=fg,font=(self.ui_font,10 if density=="compact" else 11,"bold")).pack(fill="x",pady=vpad,padx=6)
            tk.Label(
                tile,text=name,bg=base_bg,fg="#172033",
                font=(self.ui_font,9 if density=="compact" else 10,"bold"),wraplength=170
            ).pack(fill="x",pady=(1,5 if density=="compact" else 8),padx=6)

            tile.bind("<Button-1>",lambda e,n=name:choose(n))
            for child in tile.winfo_children():
                child.bind("<Button-1>",lambda e,n=name:choose(n))
            buttons[name]=tile

        if accounts:
            initial=variable.get() if variable.get() in accounts else accounts[0]
            choose(initial)
        return holder

    def build_card_transaction_form(self, parent, op):
        card=tk.Frame(
            parent,bg="#FFFFFF",
            highlightbackground="#E0E6EF",highlightthickness=1
        )
        card.pack(fill="x")

        tk.Label(
            card,text=op,bg="#FFFFFF",fg="#14213D",
            font=("Segoe UI",15,"bold")
        ).pack(anchor="e",padx=16,pady=(14,8))

        body=tk.Frame(card,bg="#FFFFFF")
        body.pack(fill="x",padx=16,pady=(0,14))

        accounts=self.account_names()
        cash=self.get_setting("default_cash_account","النقد كاش")
        if cash not in accounts:
            cash=accounts[0] if accounts else ""
        bill=self.get_setting("default_bill_account","إي فواتيركم")
        if bill not in accounts:
            bill=accounts[0] if accounts else ""
        non_cash=[a for a in accounts if a!=cash]

        source_var=tk.StringVar()
        dest_var=tk.StringVar()
        amount_var=tk.StringVar()
        comm_var=tk.StringVar(value="0.000")
        comm_acc_var=tk.StringVar(value=self.get_setting("default_commission_account",cash))
        details_var=tk.StringVar()
        commission_mode=tk.StringVar(value="ربح منفصل")

        def section_title(text_):
            tk.Label(
                body,text=text_,bg="#FFFFFF",fg="#344054",
                font=("Segoe UI",10,"bold")
            ).pack(anchor="e",pady=(6,3))

        if op=="حوالة واردة":
            src_pref=self.get_setting("default_incoming_source",cash)
            source_var.set(src_pref if src_pref in accounts else cash)
            pref=self.get_setting("default_incoming_destination","محفظة أورنج موني")
            if pref in non_cash: dest_var.set(pref)
            section_title("إلى الحساب")
            self._account_tiles(body,non_cash,dest_var).pack(fill="x")
            tk.Label(
                body,text=f"سيتم الخصم من: {cash}",
                bg="#EFF6FF",fg="#1D4ED8",
                font=("Segoe UI",9,"bold"),padx=10,pady=6
            ).pack(anchor="e",pady=4)
        elif op=="حوالة صادرة":
            dst_pref=self.get_setting("default_outgoing_destination",cash)
            dest_var.set(dst_pref if dst_pref in accounts else cash)
            pref=self.get_setting("default_outgoing_source","البنك الإسلامي")
            if pref in non_cash: source_var.set(pref)
            section_title("من الحساب")
            self._account_tiles(body,non_cash,source_var).pack(fill="x")
            tk.Label(
                body,text=f"سيتم الإيداع في: {cash}",
                bg="#EFF6FF",fg="#1D4ED8",
                font=("Segoe UI",9,"bold"),padx=10,pady=6
            ).pack(anchor="e",pady=4)
        elif op=="دفع فاتورة":
            src_pref=self.get_setting("default_bill_source",bill)
            dst_pref=self.get_setting("default_bill_destination",cash)
            source_var.set(src_pref if src_pref in accounts else bill)
            dest_var.set(dst_pref if dst_pref in accounts else cash)
            section_title("من الحساب")
            self._account_tiles(body,accounts,source_var).pack(fill="x")
            section_title("إلى الحساب")
            self._account_tiles(body,accounts,dest_var).pack(fill="x")
        else:
            section_title("من الحساب")
            if op=="سحب مالي":
                preferred_withdraw=self.get_setting("default_withdraw_account","البنك العربي")
                if preferred_withdraw in accounts:
                    source_var.set(preferred_withdraw)
            elif op=="نقل أموال":
                pref=self.get_setting("default_transfer_source","النقد كاش")
                if pref in accounts: source_var.set(pref)
            elif op=="بيع بطاقة خلوية":
                pref=self.get_setting("default_card_source","النقد كاش")
                if pref in accounts: source_var.set(pref)
            self._account_tiles(body,accounts,source_var).pack(fill="x")
            if op!="سحب مالي":
                section_title("إلى الحساب")
                if op=="نقل أموال":
                    pref=self.get_setting("default_transfer_destination","البنك الإسلامي")
                    if pref in accounts: dest_var.set(pref)
                elif op=="بيع بطاقة خلوية":
                    pref=self.get_setting("default_card_destination","النقد كاش")
                    if pref in accounts: dest_var.set(pref)
                self._account_tiles(body,accounts,dest_var).pack(fill="x")

        # V7.36: amount and commission each have their own input with shortcuts directly underneath.
        values=tk.Frame(body,bg="#FFFFFF")
        values.pack(fill="x",pady=(10,5))
        values.columnconfigure(0,weight=1); values.columnconfigure(1,weight=1)

        amount_box=tk.Frame(values,bg="#F8FAFC",highlightbackground="#D7E0EA",highlightthickness=1)
        amount_box.grid(row=0,column=1,sticky="nsew",padx=(5,3),pady=2)
        tk.Label(amount_box,text="المبلغ (JD)",bg="#F8FAFC",fg="#344054",font=(self.ui_font,self.ui_font_size,"bold")).pack(anchor="e",padx=10,pady=(8,2))
        amount_e=ttk.Entry(amount_box,textvariable=amount_var,justify="center",font=("Consolas",14))
        amount_e.pack(fill="x",padx=10,pady=(2,6),ipady=3)
        amount_quick=tk.Frame(amount_box,bg="#F8FAFC"); amount_quick.pack(fill="x",padx=8,pady=(0,8))
        try:
            amount_vals=[self.parse_number(v.strip()) for v in self.get_setting("amount_presets","5,10,20,50,100").split(",") if v.strip()][:8]
        except Exception:
            amount_vals=[5,10,20,50,100]
        for qv in amount_vals:
            label=f"{qv:g} JD"
            tk.Button(amount_quick,text=label,command=lambda v=qv:amount_var.set(f"{v:.3f}"),
                      bg="#E8F0FF",fg="#1D4ED8",activebackground="#CFE0FF",relief="flat",bd=0,
                      padx=9,pady=5,cursor="hand2",font=(self.ui_font,max(9,self.ui_font_size-1),"bold")).pack(side="right",padx=2)

        comm_btns={}
        if op != "سحب مالي":
            comm_box=tk.Frame(values,bg="#F8FAFC",highlightbackground="#D7E0EA",highlightthickness=1)
            comm_box.grid(row=0,column=0,sticky="nsew",padx=(3,5),pady=2)
            tk.Label(comm_box,text="العمولة (JD)",bg="#F8FAFC",fg="#344054",font=(self.ui_font,self.ui_font_size,"bold")).pack(anchor="e",padx=10,pady=(8,2))
            comm_e=ttk.Entry(comm_box,textvariable=comm_var,justify="center",font=("Consolas",14))
            comm_e.pack(fill="x",padx=10,pady=(2,6),ipady=3)
            comm_quick=tk.Frame(comm_box,bg="#F8FAFC"); comm_quick.pack(fill="x",padx=8,pady=(0,8))
            raw=self.get_setting("commission_presets","0.250,0.500,0.750,1.000")
            vals=[v.strip() for v in raw.split(",") if v.strip()][:8]
            def choose_comm(v):
                comm_var.set(v)
                for cv,cb in comm_btns.items():
                    sel=(cv==v)
                    cb.config(bg="#1D4ED8" if sel else "#EEF2F6",fg="white" if sel else "#344054")
            for val in vals+["0.000"]:
                cb=tk.Button(comm_quick,text=val,command=lambda v=val:choose_comm(v),bg="#EEF2F6",fg="#344054",
                    activebackground="#DCE8FF",relief="flat",bd=0,padx=9,pady=5,cursor="hand2",font=(self.ui_font,max(9,self.ui_font_size-1),"bold"))
                cb.pack(side="right",padx=2); comm_btns[val]=cb

        if op=="حوالة واردة":
            mode_row=tk.Frame(body,bg="#FFFFFF")
            mode_row.pack(fill="x",pady=4)
            tk.Label(mode_row,text="طريقة العمولة",bg="#FFFFFF",fg="#475467",
                     font=("Segoe UI",9,"bold")).pack(side="right")
            ttk.Combobox(
                mode_row,state="readonly",
                values=["بدون عمولة","ربح منفصل"],
                textvariable=commission_mode,width=18
            ).pack(side="right",padx=6)

        # commission account (withdrawal is an expense and never has commission)
        if op != "سحب مالي":
            ca_row=tk.Frame(body,bg="#FFFFFF")
            ca_row.pack(fill="x",pady=4)
            tk.Label(ca_row,text="حساب إضافة العمولة",bg="#FFFFFF",fg="#475467",
                     font=("Segoe UI",9,"bold")).pack(side="right")
            ttk.Combobox(
                ca_row,state="readonly",values=accounts,
                textvariable=comm_acc_var,width=28
            ).pack(side="right",padx=6)

        section_title("العميل / البيان")
        details=ttk.Entry(body,textvariable=details_var,justify="right")
        details.pack(fill="x",pady=(0,6))

        tk.Label(body,text="الملخص الحي للعملية",bg="#FFFFFF",fg="#14213D",font=(self.ui_font,11,"bold")).pack(anchor="e",pady=(5,2))
        preview=tk.Label(body,text="",bg="#F0F7FF",fg="#102A56",font=("Consolas",11,"bold"),justify="right",anchor="e",padx=14,pady=12,
                         highlightbackground="#B9D3FF",highlightthickness=1)
        preview.pack(fill="x",pady=(3,8))

        def get_effects():
            amt=self.parse_number(amount_var.get())
            comm=self.parse_number(comm_var.get() or 0)
            if op=="حوالة واردة" and commission_mode.get()=="بدون عمولة":
                comm=0.0
            if op in ("نقل أموال","سحب مالي"):
                comm=0.0
            src=source_var.get()
            dst="" if op=="سحب مالي" else dest_var.get()
            ca=comm_acc_var.get() if comm>0 else ""
            effects={}
            def add(a,d):
                if a: effects[a]=effects.get(a,0.0)+d
            add(src,-amt); add(dst,+amt)
            if ca: add(ca,+comm)
            return amt,comm,src,dst,ca,effects

        def preview_now():
            try:
                amt,comm,src,dst,ca,effects=get_effects()
                if amt<=0: raise ValueError
            except Exception:
                preview.config(text="أدخل مبلغاً صحيحاً")
                return
            lines=[]
            for acc,delta in effects.items():
                before=self.get_balance(acc)
                after=before+delta
                lines.append(
                    f"{acc}: {before:,.3f} JD → {after:,.3f} JD  ({delta:+,.3f} JD)"
                )
            total=amt+comm
            header=f"{op}   |   المبلغ {amt:,.3f} JD   +   العمولة {comm:,.3f} JD   =   {total:,.3f} JD"
            preview.config(text=header+"\n"+"\n".join(lines))

        def save():
            try:
                amt,comm,src,dst,ca,effects=get_effects()
            except Exception:
                messagebox.showerror("خطأ","المبلغ أو العمولة غير صحيحة")
                return
            if amt<=0 or comm<0:
                messagebox.showerror("خطأ","تحقق من القيم")
                return
            if op=="نقل أموال" and src==dst:
                messagebox.showwarning("تنبيه","اختر حسابين مختلفين")
                return
            if op=="حوالة واردة" and dst==cash:
                messagebox.showwarning("تنبيه","اختر حساباً غير الكاش")
                return
            if op=="سحب مالي" and not details_var.get().strip():
                messagebox.showwarning("تنبيه","اكتب سبب السحب")
                return

            if not self.validate_effect_balances(effects):
                return
            if not self.check_recent_duplicate(op,src,dst,amt,comm,parent=self.root):
                return

            if self.get_setting("confirm_transactions","1")=="1":
                effect_lines=[]
                for acc,delta in effects.items():
                    before=float(self.get_balance(acc)); after=before+float(delta)
                    effect_lines.append(f"{acc}: {before:,.3f} → {after:,.3f} JD ({float(delta):+,.3f})")
                confirm_text=f"{op}\nالمبلغ: {amt:,.3f} JD\nالعمولة: {comm:,.3f} JD\n\nالتأثير المتوقع:\n"+"\n".join(effect_lines)+"\n\nتأكيد الحفظ؟"
                if not messagebox.askyesno("مراجعة العملية قبل الحفظ",confirm_text):
                    return

            if not self.server_submit_core_transfer(
                op, src, dst, amt, comm, ca, details_var.get().strip()
            ):
                return

            conn=get_db(); cur=conn.cursor()
            try:
                for acc,delta in effects.items():
                    self.change_balance(cur,acc,delta)
                now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                shift=cur.execute(
                    "SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1"
                ).fetchone()
                sid=shift[0] if shift else None
                cur.execute("""
                    INSERT INTO transactions(
                        created_at,op_type,source_account,destination_account,
                        amount,commission,commission_account,details,
                        performed_by,status,shift_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,(now,op,src,dst,amt,comm,ca,details_var.get().strip(),
                     self.username,"active",sid))
                self._link_pending_server_transaction(cur, cur.lastrowid)
                conn.commit(); conn.close()
                self.log("تسجيل عملية",f"{op} | {amt:.3f} JD")
                messagebox.showinfo("تم","تم حفظ العملية")
                action=self.get_setting("after_transaction_action","نفس العملية")
                if action=="الرئيسية": self.show_dashboard()
                else: self.show_operations()
            except Exception as ex:
                conn.rollback(); conn.close()
                messagebox.showerror("خطأ",str(ex))

        buttons=tk.Frame(body,bg="#FFFFFF")
        buttons.pack(fill="x",pady=(0,4))
        tk.Button(
            buttons,text="معاينة",command=preview_now,
            bg="#EEF2F6",fg="#344054",relief="flat",
            padx=16,pady=7,cursor="hand2"
        ).pack(side="right",padx=4)
        tk.Button(
            buttons,text="✓ حفظ العملية",command=save,
            bg="#16A34A",fg="white",
            activebackground="#15803D",activeforeground="white",
            relief="flat",font=(self.ui_font,12,"bold"),
            padx=28,pady=11,cursor="hand2"
        ).pack(side="right",padx=4)

        # Cashier keyboard workflow: account -> amount -> Enter preview; F5/Ctrl+Enter commits.
        def focus_amount(*_):
            amount_e.focus_set(); amount_e.selection_range(0,"end")
        self.root.after_idle(focus_amount)
        amount_var.trace_add("write",lambda *_: self.root.after_idle(preview_now))
        comm_var.trace_add("write",lambda *_: self.root.after_idle(preview_now))
        amount_e.bind("<Return>",lambda e:preview_now())
        details.bind("<Return>",lambda e:save())
        self.root.bind("<F5>",lambda e:save())
        self.root.bind("<Control-Return>",lambda e:save())

    def build_inline_transaction_form(self, parent, op):
        card=tk.Frame(parent,bg="#FFFFFF",highlightbackground="#E0E6EF",highlightthickness=1)
        card.pack(fill="x")

        head=tk.Frame(card,bg="#FFFFFF")
        head.pack(fill="x",padx=16,pady=(14,4))
        tk.Label(
            head,text=op,bg="#FFFFFF",fg="#14213D",
            font=("Segoe UI",14,"bold")
        ).pack(side="right")

        form=tk.Frame(card,bg="#FFFFFF")
        form.pack(fill="x",padx=16,pady=(4,14))

        accounts=self.account_names()
        cash=self.get_setting("default_cash_account","النقد كاش")
        if cash not in accounts:
            cash="النقد كاش" if "النقد كاش" in accounts else (accounts[0] if accounts else "")
        bill=self.get_setting("default_bill_account","إي فواتيركم")
        if bill not in accounts:
            bill="إي فواتيركم" if "إي فواتيركم" in accounts else (accounts[0] if accounts else "")
        non_cash=[a for a in accounts if a!=cash]

        source_var=tk.StringVar()
        dest_var=tk.StringVar()
        amount_var=tk.StringVar()
        comm_var=tk.StringVar(value="0.000")
        comm_acc_var=tk.StringVar()
        details_var=tk.StringVar()

        def add_field(label,row,col,widget):
            tk.Label(
                form,text=label,bg="#FFFFFF",fg="#475467",
                font=("Segoe UI",9,"bold")
            ).grid(row=row*2,column=col,sticky="e",padx=6,pady=(4,1))
            widget.grid(row=row*2+1,column=col,sticky="ew",padx=6,pady=(0,6))

        # operation-specific account fields
        source_cb=None; dest_cb=None
        if op=="حوالة واردة":
            source_var.set(cash)
            dest_cb=ttk.Combobox(form,state="readonly",values=non_cash,textvariable=dest_var)
            if non_cash: dest_var.set(non_cash[0])
            add_field("إلى الحساب",0,3,dest_cb)
            fixed=tk.Label(form,text=f"من الكاش: {cash}",bg="#EFF6FF",fg="#1D4ED8",
                           font=("Segoe UI",9,"bold"),padx=10,pady=7)
            fixed.grid(row=1,column=2,sticky="ew",padx=6)
        elif op=="حوالة صادرة":
            source_cb=ttk.Combobox(form,state="readonly",values=non_cash,textvariable=source_var)
            if non_cash: source_var.set(non_cash[0])
            add_field("من الحساب",0,3,source_cb)
            dest_var.set(cash)
            fixed=tk.Label(form,text=f"إلى الكاش: {cash}",bg="#EFF6FF",fg="#1D4ED8",
                           font=("Segoe UI",9,"bold"),padx=10,pady=7)
            fixed.grid(row=1,column=2,sticky="ew",padx=6)
        elif op=="دفع فاتورة":
            source_var.set(bill); dest_var.set(cash)
            tk.Label(form,text=f"من: {bill}",bg="#FFF8E8",fg="#8A5A00",
                     font=("Segoe UI",9,"bold"),padx=10,pady=7).grid(row=1,column=3,sticky="ew",padx=6)
            tk.Label(form,text=f"إلى: {cash}",bg="#EFF6FF",fg="#1D4ED8",
                     font=("Segoe UI",9,"bold"),padx=10,pady=7).grid(row=1,column=2,sticky="ew",padx=6)
        else:
            source_cb=ttk.Combobox(form,state="readonly",values=accounts,textvariable=source_var)
            preferred_withdraw=self.get_setting("default_withdraw_account","البنك العربي")
            if op=="سحب مالي" and preferred_withdraw in accounts:
                source_var.set(preferred_withdraw)
            elif accounts:
                source_var.set(accounts[0])
            add_field("من الحساب",0,3,source_cb)
            if op!="سحب مالي":
                dest_cb=ttk.Combobox(form,state="readonly",values=accounts,textvariable=dest_var)
                if len(accounts)>1: dest_var.set(accounts[1])
                elif accounts: dest_var.set(accounts[0])
                add_field("إلى الحساب",0,2,dest_cb)

        amount_e=ttk.Entry(form,textvariable=amount_var,justify="center")
        comm_e=ttk.Entry(form,textvariable=comm_var,justify="center")
        comm_acc=ttk.Combobox(form,state="readonly",values=accounts,textvariable=comm_acc_var)
        default_comm=self.get_setting("default_commission_account",cash)
        if default_comm in accounts: comm_acc_var.set(default_comm)
        elif accounts: comm_acc_var.set(accounts[0])

        add_field("المبلغ (JD)",1,3,amount_e)
        add_field("العمولة (JD)",1,2,comm_e)
        add_field("حساب العمولة",1,1,comm_acc)

        # Explicit commission mode for incoming, including eFawateercom.
        commission_mode=tk.StringVar(value="ربح منفصل")
        if op=="حوالة واردة":
            mode=ttk.Combobox(
                form,state="readonly",
                values=["بدون عمولة","ربح منفصل"],textvariable=commission_mode
            )
            add_field("طريقة العمولة",1,0,mode)

        details_e=ttk.Entry(form,textvariable=details_var,justify="right")
        add_field("العميل / البيان",2,3,details_e)

        # commission shortcuts
        quick=tk.Frame(form,bg="#FFFFFF")
        quick.grid(row=5,column=2,columnspan=2,sticky="w",padx=6)
        for val in ("0.250","0.500","0.750","1.000"):
            tk.Button(
                quick,text=val,
                command=lambda v=val:comm_var.set(v),
                bg="#F2F4F7",fg="#344054",relief="flat",
                padx=8,pady=4,cursor="hand2"
            ).pack(side="left",padx=2)

        preview=tk.Label(
            form,text="",
            bg="#F8FAFC",fg="#344054",
            font=("Consolas",10),justify="right",
            anchor="e",padx=10,pady=9
        )
        preview.grid(row=6,column=0,columnspan=4,sticky="ew",padx=6,pady=(5,8))

        for c in range(4):
            form.columnconfigure(c,weight=1)

        def effects():
            amt=self.parse_number(amount_var.get())
            comm=self.parse_number(comm_var.get() or 0)
            if op=="حوالة واردة" and commission_mode.get()=="بدون عمولة":
                comm=0.0
            if op in ("نقل أموال","سحب مالي"):
                comm=0.0

            src=source_var.get()
            dst=dest_var.get()
            if op=="سحب مالي":
                dst=""
            ca=comm_acc_var.get() if comm>0 else ""

            e={}
            def add(a,d):
                if a: e[a]=e.get(a,0.0)+d
            add(src,-amt)
            add(dst,+amt)
            if ca: add(ca,+comm)
            return amt,comm,src,dst,ca,e

        def preview_now():
            try:
                amt,comm,src,dst,ca,effects_map=effects()
                if amt<=0: raise ValueError
            except Exception:
                preview.config(text="أدخل مبلغاً صحيحاً للمعاينة")
                return
            lines=[]
            for acc,delta in effects_map.items():
                before=self.get_balance(acc)
                after=before+delta
                lines.append(
                    f"{acc}: {before:,.3f} JD  →  {after:,.3f} JD   "
                    f"({delta:+,.3f} JD)"
                )
            preview.config(text="\n".join(lines))

        def save():
            try:
                amt,comm,src,dst,ca,effects_map=effects()
            except Exception:
                messagebox.showerror("خطأ","المبلغ أو العمولة غير صحيحة")
                return
            if amt<=0 or comm<0:
                messagebox.showerror("خطأ","تحقق من القيم")
                return
            if op=="نقل أموال" and src==dst:
                messagebox.showwarning("تنبيه","اختر حسابين مختلفين")
                return
            if op=="سحب مالي" and not details_var.get().strip():
                messagebox.showwarning("تنبيه","اكتب سبب السحب")
                return

            # incoming may go to eFawateercom or any other non-cash account; cash is always deducted
            if op=="حوالة واردة" and dst==cash:
                messagebox.showwarning("تنبيه","اختر حساباً غير الكاش كوجهة للحوالة الواردة")
                return

            if not self.validate_effect_balances(effects_map):
                return

            if self.get_setting("confirm_transactions","1")=="1":
                if not messagebox.askyesno(
                    "تأكيد العملية",
                    f"{op}\nالمبلغ: {amt:,.3f} JD\nالعمولة: {comm:,.3f} JD\n\nحفظ العملية؟"
                ):
                    return

            if not self.server_submit_core_transfer(
                op, src, dst, amt, comm, ca, details_var.get().strip()
            ):
                return

            conn=get_db(); cur=conn.cursor()
            try:
                for acc,delta in effects_map.items():
                    self.change_balance(cur,acc,delta)

                now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                shift=cur.execute(
                    "SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1"
                ).fetchone()
                shift_id=shift[0] if shift else None

                cur.execute("""
                    INSERT INTO transactions(
                        created_at,op_type,source_account,destination_account,
                        amount,commission,commission_account,details,
                        performed_by,status,shift_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,(
                    now,op,src,dst,amt,comm,ca,details_var.get().strip(),
                    self.username,"active",shift_id
                ))
                self._link_pending_server_transaction(cur, cur.lastrowid)
                conn.commit(); conn.close()
                self.log("تسجيل عملية",f"{op} | {amt:.3f} JD")
                messagebox.showinfo("تم","تم حفظ العملية بنجاح")
                self.show_operations()
            except Exception as ex:
                conn.rollback(); conn.close()
                messagebox.showerror("خطأ",str(ex))

        actions=tk.Frame(form,bg="#FFFFFF")
        actions.grid(row=7,column=0,columnspan=4,sticky="e",padx=6,pady=(0,4))
        tk.Button(
            actions,text="معاينة",command=preview_now,
            bg="#EEF2F6",fg="#344054",relief="flat",
            padx=16,pady=7,cursor="hand2"
        ).pack(side="right",padx=4)
        tk.Button(
            actions,text="✓ حفظ العملية",command=save,
            bg="#2563EB",fg="white",activebackground="#1D4ED8",
            activeforeground="white",relief="flat",
            font=("Segoe UI",10,"bold"),
            padx=18,pady=7,cursor="hand2"
        ).pack(side="right",padx=4)

        amount_e.bind("<Return>",lambda e:preview_now())
        details_e.bind("<Return>",lambda e:save())

    def build_inline_debt_form(self, parent, payment=False):
        card=tk.Frame(parent,bg="#FFFFFF",highlightbackground="#E0E6EF",highlightthickness=1)
        card.pack(fill="x")
        tk.Label(
            card,text="سداد دين" if payment else "إضافة دين للعميل",
            bg="#FFFFFF",fg="#14213D",
            font=("Segoe UI",14,"bold")
        ).pack(anchor="e",padx=16,pady=(14,6))

        body=tk.Frame(card,bg="#FFFFFF")
        body.pack(fill="x",padx=16,pady=(0,14))

        conn=get_db()
        customers=[r[0] for r in conn.execute(
            "SELECT name FROM customers WHERE active=1 ORDER BY name"
        ).fetchall()]
        conn.close()

        customer_var=tk.StringVar()
        amount_var=tk.StringVar()
        note_var=tk.StringVar()

        customer=ttk.Combobox(body,state="readonly",values=customers,textvariable=customer_var)
        if customers: customer_var.set(customers[0])
        amount=ttk.Entry(body,textvariable=amount_var,justify="center")
        note=ttk.Entry(body,textvariable=note_var,justify="right")

        accounts=self.account_names()
        acc_var=tk.StringVar()
        cash=self.get_setting("default_cash_account","النقد كاش")
        pref=self.get_setting(
            "default_repayment_account" if payment else "default_debt_account",
            cash
        )
        acc_var.set(
            pref if pref in accounts
            else (cash if cash in accounts else (accounts[0] if accounts else ""))
        )
        acc=ttk.Combobox(body,state="readonly",values=accounts,textvariable=acc_var)

        labels=[("العميل",customer),("المبلغ (JD)",amount),("الحساب",acc),("الملاحظات",note)]
        for i,(lbl,w) in enumerate(labels):
            tk.Label(body,text=lbl,bg="#FFFFFF",fg="#475467",
                     font=("Segoe UI",9,"bold")).grid(row=0,column=3-i,sticky="e",padx=6)
            w.grid(row=1,column=3-i,sticky="ew",padx=6,pady=(2,8))
            body.columnconfigure(3-i,weight=1)

        def save():
            # reuse existing tested debt window logic by setting up directly
            name=customer_var.get()
            if not name:
                messagebox.showwarning("تنبيه","اختر العميل"); return
            try: amt=self.parse_number(amount_var.get())
            except Exception:
                messagebox.showerror("خطأ","المبلغ غير صحيح"); return
            if amt<=0:
                messagebox.showerror("خطأ","المبلغ يجب أن يكون أكبر من صفر"); return

            account=acc_var.get()
            conn=get_db(); cur=conn.cursor()
            row=cur.execute(
                "SELECT debt_balance,debt_limit FROM customers WHERE name=? AND active=1",
                (name,)
            ).fetchone()
            if not row:
                conn.close(); messagebox.showerror("خطأ","العميل غير موجود"); return

            current=float(row[0]); limit=float(row[1])
            if payment:
                if amt>current+0.0000001:
                    conn.close(); messagebox.showerror("خطأ","السداد أكبر من الدين الحالي"); return
                if not self.server_submit_debt_operation(
                    "سداد دين", account, amt, name, note_var.get().strip()
                ):
                    conn.close(); return
                cur.execute("UPDATE customers SET debt_balance=debt_balance-? WHERE name=?",(amt,name))
                self.change_balance(cur,account,amt)
                op,src,dst="سداد دين","",account
            else:
                if limit>0 and current+amt>limit+0.0000001:
                    conn.close(); messagebox.showerror("خطأ",f"سيتم تجاوز حد الدين {limit:,.3f} JD"); return
                if self.get_balance(account)<amt:
                    conn.close(); messagebox.showerror("خطأ","رصيد الحساب لا يكفي"); return
                if not self.server_submit_debt_operation(
                    "دين للعميل", account, amt, name, note_var.get().strip()
                ):
                    conn.close(); return
                cur.execute("UPDATE customers SET debt_balance=debt_balance+? WHERE name=?",(amt,name))
                self.change_balance(cur,account,-amt)
                op,src,dst="دين للعميل",account,""

            now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            shift=cur.execute("SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()
            shift_id=shift[0] if shift else None
            cur.execute("""
                INSERT INTO transactions(
                    created_at,op_type,source_account,destination_account,
                    amount,commission,commission_account,customer_name,
                    details,performed_by,status,shift_id
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """,(now,op,src,dst,amt,0,"",name,note_var.get().strip(),
                 self.username,"active",shift_id))
            self._link_pending_server_transaction(cur, cur.lastrowid)
            conn.commit(); conn.close()
            messagebox.showinfo("تم","تم حفظ العملية")
            self.show_operations()

        tk.Button(
            body,text="✓ حفظ",command=save,
            bg="#2563EB",fg="white",relief="flat",
            padx=18,pady=7,font=("Segoe UI",10,"bold"),
            cursor="hand2"
        ).grid(row=2,column=0,columnspan=4,sticky="e",padx=6,pady=3)

    def transaction_window(self, op):
        win = tk.Toplevel(self.root)
        win.title(op)
        win.geometry("740x780")
        win.minsize(620, 650)
        win.resizable(True, True)

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=op, font=("Segoe UI", 16, "bold")).pack(pady=10)

        accounts = self.account_names()
        cash_account = self.get_setting("default_cash_account", "النقد كاش")
        if cash_account not in accounts:
            cash_account = "النقد كاش" if "النقد كاش" in accounts else (accounts[0] if accounts else "")
        bill_account = self.get_setting("default_bill_account", "إي فواتيركم")
        if bill_account not in accounts:
            bill_account = "إي فواتيركم" if "إي فواتيركم" in accounts else (accounts[0] if accounts else "")
        non_cash = [a for a in accounts if a != cash_account]

        from_cb = None
        to_cb = None

        if op == "حوالة واردة":
            ttk.Label(frame, text="الحساب الذي سيدخل إليه مبلغ الحوالة").pack(anchor="e")
            to_cb = ttk.Combobox(frame, state="readonly", values=non_cash)
            to_cb.pack(fill="x", pady=5)
            if non_cash: to_cb.set(non_cash[0])
            self.quick_account_buttons(frame, to_cb, non_cash)
            ttk.Label(
                frame, text=f"المبلغ المدفوع للعميل يخرج من: {cash_account}",
                font=("Segoe UI", 10, "bold")
            ).pack(anchor="e", pady=5)

        elif op == "حوالة صادرة":
            ttk.Label(frame, text="الحساب الذي سيخرج منه مبلغ الحوالة").pack(anchor="e")
            from_cb = ttk.Combobox(frame, state="readonly", values=non_cash)
            from_cb.pack(fill="x", pady=5)
            if non_cash: from_cb.set(non_cash[0])
            self.quick_account_buttons(frame, from_cb, non_cash)
            ttk.Label(
                frame, text=f"المبلغ المستلم من العميل يدخل إلى: {cash_account}",
                font=("Segoe UI", 10, "bold")
            ).pack(anchor="e", pady=5)

        elif op == "دفع فاتورة":
            ttk.Label(frame, text=f"مصدر دفع الفاتورة: {bill_account}").pack(anchor="e")
            ttk.Label(frame, text=f"المبلغ المستلم من العميل يدخل إلى: {cash_account}").pack(anchor="e", pady=5)

        else:
            ttk.Label(frame, text="من حساب").pack(anchor="e")
            from_cb = ttk.Combobox(frame, state="readonly", values=accounts)
            from_cb.pack(fill="x", pady=5)
            if accounts: from_cb.set(accounts[0])
            self.quick_account_buttons(frame, from_cb, accounts)

            if op != "سحب مالي":
                ttk.Label(frame, text="إلى حساب").pack(anchor="e")
                to_cb = ttk.Combobox(frame, state="readonly", values=accounts)
                to_cb.pack(fill="x", pady=5)
                if accounts: to_cb.set(accounts[0])
                self.quick_account_buttons(frame, to_cb, accounts)

        ttk.Label(frame, text="المبلغ (JD)").pack(anchor="e")
        amount = ttk.Entry(frame, justify="right")
        self.setup_entry(amount)
        amount.pack(fill="x", pady=5)

        commission = ttk.Entry(frame, justify="right")
        self.setup_entry(commission)
        commission.insert(0, "0.000")
        comm_cb = ttk.Combobox(frame, state="readonly", values=accounts)
        default_comm = self.get_setting("default_commission_account", cash_account)
        if default_comm in accounts:
            comm_cb.set(default_comm)
        elif cash_account in accounts:
            comm_cb.set(cash_account)
        elif accounts:
            comm_cb.set(accounts[0])

        # سحب مالي = مصروف محل فقط؛ لا نظهر أو نقبل عمولة.
        if op != "سحب مالي":
            ttk.Label(frame, text="العمولة / الربح (JD)").pack(anchor="e")
            commission.pack(fill="x", pady=5)
            self.commission_buttons(frame, commission)
            ttk.Label(frame, text="حساب إضافة العمولة").pack(anchor="e")
            comm_cb.pack(fill="x", pady=5)

        ttk.Label(frame, text="العميل / الشركة / الفئة / سبب السحب").pack(anchor="e")
        details = ttk.Entry(frame, justify="right")
        self.setup_entry(details, select_all_on_focus=False)
        details.pack(fill="x", pady=5)

        preview_box = ttk.LabelFrame(frame, text="معاينة الأرصدة بعد العملية", padding=10)
        preview_box.pack(fill="x", pady=10)
        preview = ttk.Label(
            preview_box, text="أدخل المبلغ ثم اضغط معاينة",
            font=("Consolas", 11, "bold"), justify="right"
        )
        preview.pack(fill="x")

        def resolved_accounts():
            if op == "حوالة واردة": return cash_account, to_cb.get()
            if op == "حوالة صادرة": return from_cb.get(), cash_account
            if op == "دفع فاتورة": return bill_account, cash_account
            if op == "سحب مالي": return from_cb.get(), ""
            return (from_cb.get() if from_cb else ""), (to_cb.get() if to_cb else "")

        def get_effects():
            amt = self.parse_number(amount.get())
            comm = self.parse_number(commission.get() or 0)
            src, dst = resolved_accounts()
            ca = comm_cb.get()
            if op in ("سحب مالي", "نقل أموال"):
                comm = 0.0
                ca = ""
            effects = {}
            def add(a, d):
                if a:
                    effects[a] = effects.get(a, 0.0) + d
            add(src, -amt)
            add(dst, amt)
            if comm > 0 and ca:
                add(ca, comm)
            return amt, comm, src, dst, ca, effects

        def calculate_preview():
            try:
                amt, comm, src, dst, ca, effects = get_effects()
                if amt <= 0 or comm < 0:
                    raise ValueError
            except ValueError:
                preview.config(text="أدخل المبلغ والعمولة بشكل صحيح")
                return

            lines = []
            for account_name, delta in effects.items():
                before = self.get_balance(account_name)
                after = before + delta
                sign = "+" if delta >= 0 else ""
                lines.append(
                    f"{account_name}:  {before:,.3f} JD  →  {after:,.3f} JD   "
                    f"(التغيير {sign}{delta:,.3f} JD)"
                )
            preview.config(text="\n".join(lines))

        def save():
            try:
                amt, comm, src, dst, comm_acc, effects = get_effects()
            except ValueError:
                messagebox.showerror("خطأ", "المبلغ أو العمولة غير صحيحة", parent=win)
                return

            if amt <= 0 or comm < 0:
                messagebox.showerror("خطأ", "تحقق من القيم", parent=win)
                return

            note = details.get().strip()
            if op == "بيع بطاقة خلوية" and not note:
                messagebox.showwarning("تنبيه", "اكتب الشركة والفئة", parent=win)
                return
            if op == "سحب مالي" and not note:
                messagebox.showwarning("تنبيه", "يجب كتابة سبب السحب واسم الشخص", parent=win)
                return
            if op == "نقل أموال" and src == dst:
                messagebox.showwarning("تنبيه", "اختر حسابين مختلفين", parent=win)
                return
            if op == "حوالة واردة" and dst == cash_account:
                messagebox.showerror("خطأ", f"لا يمكن أن يكون {cash_account} وجهة الحوالة الواردة", parent=win)
                return

            if not self.validate_effect_balances(effects, parent=win):
                return

            if self.get_setting("confirm_transactions", "1") == "1":
                if not messagebox.askyesno(
                    "تأكيد العملية",
                    f"هل تريد تسجيل {op} بمبلغ {amt:,.3f} JD؟",
                    parent=win
                ):
                    return

            if not self.server_submit_core_transfer(
                op, src, dst, amt, comm, comm_acc, note, parent=win
            ):
                return

            conn = get_db()
            cur = conn.cursor()
            try:
                for account_name, delta in effects.items():
                    self.change_balance(cur, account_name, delta)

                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                shift = cur.execute(
                    "SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1"
                ).fetchone()
                shift_id = shift[0] if shift else None

                cur.execute("""
                    INSERT INTO transactions(
                        created_at,op_type,source_account,destination_account,
                        amount,commission,commission_account,details,performed_by,status,shift_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    now, op, src, dst, amt, comm, comm_acc, note,
                    self.username, "active", shift_id
                ))
                self._link_pending_server_transaction(cur, cur.lastrowid)
                conn.commit()
                conn.close()

                self.log("تسجيل عملية", f"{op} - {amt:.3f} JD")

                low_messages = self.get_low_balance_messages(effects.keys())
                messagebox.showinfo("تم", "تم تسجيل العملية بنجاح", parent=win)
                if low_messages:
                    messagebox.showwarning("تنبيه أرصدة", "\n".join(low_messages), parent=win)

                win.destroy()
                self.show_dashboard()

            except Exception as e:
                conn.rollback()
                conn.close()
                messagebox.showerror("خطأ", str(e), parent=win)

        details.bind("<Return>", lambda e: save())
        ttk.Button(frame, text="معاينة تأثير العملية", command=calculate_preview).pack(pady=5)
        ttk.Button(frame, text="تأكيد العملية", style="Accent.TButton",
                   command=save).pack(pady=12, ipadx=30, ipady=8)

    def get_low_balance_messages(self, account_names):
        if self.get_setting("low_balance_alerts", "1") != "1":
            return []
        conn = get_db()
        messages = []
        for name in account_names:
            row = conn.execute(
                "SELECT balance,warning_limit FROM accounts WHERE name=? AND active=1",
                (name,)
            ).fetchone()
            if row and float(row[1]) > 0 and float(row[0]) <= float(row[1]):
                messages.append(
                    f"{name}: الرصيد {float(row[0]):,.3f} JD "
                    f"وصل إلى حد التنبيه {float(row[1]):,.3f} JD"
                )
        conn.close()
        return messages

    def show_accounts(self):
        if not self.require_permission("accounts","الحسابات"):
            return
        self.clear_content()

        ttk.Label(
            self.content, text="الحسابات والأرصدة",
            font=("Segoe UI", 20, "bold")
        ).pack(anchor="e", pady=10)

        tree_frame = ttk.Frame(self.content)
        tree_frame.pack(fill="both", expand=True, pady=10)

        tree = ttk.Treeview(
            tree_frame,
            columns=("name","type","balance","limit","status"),
            show="headings"
        )
        for c,h,w in [
            ("name","الحساب",300),
            ("type","النوع",150),
            ("balance","الرصيد",170),
            ("limit","حد التنبيه",170),
            ("status","الحالة",120)
        ]:
            tree.heading(c,text=h)
            tree.column(c,width=w,anchor="center",stretch=True)

        vs = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vs.set)
        tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")

        conn = get_db()
        rows = conn.execute("""
            SELECT name,account_type,balance,warning_limit,active
            FROM accounts ORDER BY id
        """).fetchall()
        conn.close()

        for r in rows:
            tree.insert("", "end", values=(
                r[0], r[1], self.fmt_money(r[2]),
                self.fmt_money(r[3]),
                "فعال" if r[4] else "معطل"
            ))

        bar = ttk.Frame(self.content)
        bar.pack(fill="x", pady=5)

        ttk.Button(
            bar, text="➕ إضافة حساب جديد",
            command=self.add_account_window
        ).pack(side="right", padx=5)

        if self.role == "admin":
            ttk.Button(
                bar, text="✏ تعديل بيانات الحساب",
                command=lambda: self.edit_account_window(tree)
            ).pack(side="right", padx=5)

            ttk.Button(
                bar, text="💰 تعديل الرصيد",
                command=lambda: self.admin_adjust_balance(tree)
            ).pack(side="right", padx=5)

            ttk.Button(
                bar, text="تشغيل / تعطيل الحساب",
                command=lambda: self.toggle_account_active(tree)
            ).pack(side="right", padx=5)

        ttk.Label(
            self.content,
            text="الحساب المعطل يبقى محفوظاً في السجلات القديمة لكنه لا يظهر في العمليات الجديدة.",
            font=("Segoe UI", 10)
        ).pack(anchor="e", pady=5)

    def add_account_window(self):
        win = tk.Toplevel(self.root)
        win.title("إضافة حساب جديد")
        win.geometry("470x420")
        win.resizable(True, True)

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame,text="اسم الحساب").pack(anchor="e")
        name = ttk.Entry(frame, justify="right")
        self.setup_entry(name, select_all_on_focus=False)
        name.pack(fill="x", pady=5)

        ttk.Label(frame,text="نوع الحساب").pack(anchor="e")
        typ = ttk.Combobox(
            frame, state="readonly",
            values=["نقد","بنك","محفظة","خدمات دفع","أخرى"]
        )
        typ.set("بنك")
        typ.pack(fill="x", pady=5)

        ttk.Label(frame,text="الرصيد الابتدائي").pack(anchor="e")
        bal = ttk.Entry(frame, justify="right")
        self.setup_entry(bal)
        bal.insert(0,"0.000")
        bal.pack(fill="x", pady=5)

        ttk.Label(frame,text="حد تنبيه انخفاض الرصيد").pack(anchor="e")
        limit = ttk.Entry(frame, justify="right")
        self.setup_entry(limit)
        limit.insert(0,"0.000")
        limit.pack(fill="x", pady=5)

        ttk.Label(
            frame,
            text="مثال: البنك الأردني / محفظة زين كاش / محفظة جديدة",
            font=("Segoe UI", 9)
        ).pack(anchor="e", pady=3)

        def save():
            n = name.get().strip()
            if not n:
                messagebox.showwarning("تنبيه","اكتب اسم الحساب",parent=win)
                return

            try:
                b = self.parse_number(bal.get() or 0)
                l = self.parse_number(limit.get() or 0)
            except ValueError:
                messagebox.showerror("خطأ","أدخل أرقاماً صحيحة",parent=win)
                return

            conn = get_db()
            cur = conn.cursor()
            try:
                cur.execute("""
                    INSERT INTO accounts(name,account_type,balance,warning_limit,active)
                    VALUES(?,?,?,?,1)
                """, (n,typ.get(),b,l))

                # نسجل الرصيد الافتتاحي كعملية كي يظهر كشف الحساب بشكل صحيح.
                if abs(b) > 0.0000001:
                    cur.execute("""
                        INSERT INTO transactions(
                            created_at,op_type,destination_account,amount,commission,
                            commission_account,details,performed_by,status
                        ) VALUES(?,?,?,?,?,?,?,?,?)
                    """, (
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "رصيد افتتاحي", n, abs(b), 0, "",
                        "رصيد افتتاحي عند إنشاء الحساب", self.username, "active"
                    ))

                conn.commit()
                conn.close()
                self.log("إضافة حساب", f"{n} | {typ.get()} | {b:.3f}")
                messagebox.showinfo("تم","تمت إضافة الحساب بنجاح",parent=win)
                win.destroy()
                self.show_accounts()
            except sqlite3.IntegrityError:
                conn.rollback()
                conn.close()
                messagebox.showerror("خطأ","يوجد حساب بهذا الاسم مسبقاً",parent=win)

        limit.bind("<Return>", lambda e: save())
        ttk.Button(frame,text="حفظ الحساب",command=save).pack(pady=18,ipadx=30,ipady=7)


    def edit_account_window(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("تنبيه","اختر حساباً أولاً")
            return

        values = tree.item(selected[0])["values"]
        old_name, old_type = values[0], values[1]

        conn = get_db()
        row = conn.execute(
            "SELECT warning_limit FROM accounts WHERE name=?", (old_name,)
        ).fetchone()
        conn.close()
        old_limit = row[0] if row else 0

        win = tk.Toplevel(self.root)
        win.title("تعديل بيانات الحساب")
        win.geometry("470x350")

        frame = ttk.Frame(win,padding=20)
        frame.pack(fill="both",expand=True)

        ttk.Label(frame,text="اسم الحساب").pack(anchor="e")
        name = ttk.Entry(frame,justify="right")
        self.setup_entry(name)
        name.insert(0,old_name)
        name.pack(fill="x",pady=5)

        ttk.Label(frame,text="نوع الحساب").pack(anchor="e")
        typ = ttk.Combobox(
            frame,state="readonly",
            values=["نقد","بنك","محفظة","خدمات دفع","أخرى"]
        )
        typ.set(old_type)
        typ.pack(fill="x",pady=5)

        ttk.Label(frame,text="حد تنبيه انخفاض الرصيد").pack(anchor="e")
        limit = ttk.Entry(frame,justify="right")
        self.setup_entry(limit)
        limit.insert(0,f"{float(old_limit):,.3f}")
        limit.pack(fill="x",pady=5)

        def save():
            new_name = name.get().strip()
            if not new_name:
                messagebox.showwarning("تنبيه","اكتب اسم الحساب",parent=win); return
            try:
                new_limit = self.parse_number(limit.get())
            except ValueError:
                messagebox.showerror("خطأ","حد التنبيه غير صحيح",parent=win); return

            conn = get_db()
            cur = conn.cursor()
            try:
                cur.execute("""
                    UPDATE accounts SET name=?,account_type=?,warning_limit=?
                    WHERE name=?
                """,(new_name,typ.get(),new_limit,old_name))

                # تحديث اسم الحساب في السجلات القديمة أيضاً حتى لا ينكسر كشف الحساب.
                if new_name != old_name:
                    cur.execute("UPDATE transactions SET source_account=? WHERE source_account=?",(new_name,old_name))
                    cur.execute("UPDATE transactions SET destination_account=? WHERE destination_account=?",(new_name,old_name))
                    cur.execute("UPDATE transactions SET commission_account=? WHERE commission_account=?",(new_name,old_name))
                    cur.execute("UPDATE shift_balances SET account_name=? WHERE account_name=?",(new_name,old_name))

                conn.commit(); conn.close()
                self.log("تعديل حساب", f"{old_name} -> {new_name}")
                messagebox.showinfo("تم","تم تعديل الحساب",parent=win)
                win.destroy(); self.show_accounts()
            except sqlite3.IntegrityError:
                conn.rollback(); conn.close()
                messagebox.showerror("خطأ","اسم الحساب الجديد مستخدم مسبقاً",parent=win)

        limit.bind("<Return>",lambda e:save())
        ttk.Button(frame,text="حفظ التعديل",command=save).pack(pady=18)

    def toggle_account_active(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("تنبيه","اختر حساباً أولاً")
            return

        values = tree.item(selected[0])["values"]
        account = values[0]

        if account == "النقد كاش":
            messagebox.showwarning("تنبيه","لا يمكن تعطيل حساب النقد كاش الأساسي")
            return

        conn = get_db()
        row = conn.execute("SELECT active FROM accounts WHERE name=?",(account,)).fetchone()
        if not row:
            conn.close(); return

        new_value = 0 if row[0] else 1
        conn.execute("UPDATE accounts SET active=? WHERE name=?",(new_value,account))
        conn.commit(); conn.close()

        self.log("تغيير حالة حساب", f"{account}: {'فعال' if new_value else 'معطل'}")
        self.show_accounts()

    def admin_adjust_balance(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("تنبيه","اختر حساباً")
            return

        values = tree.item(selected[0])["values"]
        account = values[0]
        current = self.parse_number(values[2])

        win = tk.Toplevel(self.root)
        win.title("تعديل رصيد Admin")
        win.geometry("450x330")
        win.resizable(True, True)

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame,text=f"الحساب: {account}",
                  font=("Segoe UI",12,"bold")).pack(pady=10)

        ttk.Label(frame,text="الرصيد الجديد").pack(anchor="e")
        newbal = ttk.Entry(frame, justify="right")
        self.setup_entry(newbal)
        newbal.insert(0, f"{float(current):,.3f}")
        newbal.pack(fill="x", pady=5)

        ttk.Label(frame,text="سبب التعديل").pack(anchor="e")
        reason = ttk.Entry(frame, justify="right")
        self.setup_entry(reason, select_all_on_focus=False)
        reason.pack(fill="x", pady=5)

        def save():
            try:
                nb = self.parse_number(newbal.get())
            except ValueError:
                messagebox.showerror("خطأ","الرصيد يجب أن يكون رقماً",parent=win)
                return

            why = reason.get().strip()
            if not why:
                messagebox.showwarning("تنبيه","يجب كتابة سبب التعديل",parent=win)
                return

            conn = get_db()
            conn.execute("UPDATE accounts SET balance=? WHERE name=?", (nb,account))
            conn.execute("""
                INSERT INTO transactions(
                    created_at,op_type,destination_account,amount,details,
                    performed_by,status
                ) VALUES(?,?,?,?,?,?,?)
            """, (
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "تسوية رصيد", account, abs(nb-current),
                f"من {current:.3f} إلى {nb:.3f} | السبب: {why}",
                self.username, "active"
            ))
            conn.commit()
            conn.close()

            self.log("تعديل رصيد", f"{account}: {current:.3f} -> {nb:.3f} | {why}")
            messagebox.showinfo("تم","تم تعديل الرصيد وتسجيل التسوية",parent=win)
            win.destroy()
            self.show_accounts()

        reason.bind("<Return>", lambda e: save())
        ttk.Button(frame,text="حفظ التعديل",command=save).pack(pady=20)

    def show_operation_log(self):
        if not self.require_permission("operations","سجل العمليات"):
            return
        self.clear_content()
        ttk.Label(self.content,text="🧾 سجل العمليات الموحد",font=("Segoe UI",20,"bold")).pack(anchor="e",pady=(2,5))
        ttk.Label(self.content,text="يعرض عمليات Windows والهاتف من السيرفر مع الاحتفاظ بالعمليات المحلية القديمة دون تكرار.",font=("Segoe UI",9)).pack(anchor="e",pady=(0,7))

        controls=ttk.Frame(self.content); controls.pack(fill="x",pady=(0,5))
        search_var=tk.StringVar(); op_var=tk.StringVar(value="الكل"); status_var=tk.StringVar(value="الكل"); source_var=tk.StringVar(value="الكل")
        date_from_var=tk.StringVar(); date_to_var=tk.StringVar()
        ttk.Label(controls,text="بحث:").pack(side="right"); search_entry=ttk.Entry(controls,textvariable=search_var,width=20); search_entry.pack(side="right",padx=4)
        ttk.Label(controls,text="العملية:").pack(side="right",padx=(8,2)); op_cb=ttk.Combobox(controls,textvariable=op_var,state="readonly",width=16); op_cb.pack(side="right",padx=4)
        ttk.Label(controls,text="الحالة:").pack(side="right",padx=(8,2)); status_cb=ttk.Combobox(controls,textvariable=status_var,state="readonly",values=["الكل","فعال","معدل","معكوس","ملغي"],width=10); status_cb.pack(side="right",padx=4)
        ttk.Label(controls,text="المصدر:").pack(side="right",padx=(8,2)); source_cb=ttk.Combobox(controls,textvariable=source_var,state="readonly",values=["الكل","السيرفر","Windows محلي"],width=12); source_cb.pack(side="right",padx=4)

        date_controls=ttk.Frame(self.content); date_controls.pack(fill="x",pady=(0,5))
        ttk.Label(date_controls,text="من تاريخ YYYY-MM-DD:").pack(side="right")
        ttk.Entry(date_controls,textvariable=date_from_var,width=12).pack(side="right",padx=4)
        ttk.Label(date_controls,text="إلى:").pack(side="right",padx=(8,2))
        ttk.Entry(date_controls,textvariable=date_to_var,width=12).pack(side="right",padx=4)
        ttk.Button(date_controls,text="اليوم",command=lambda:(date_from_var.set(datetime.now().strftime("%Y-%m-%d")),date_to_var.set(datetime.now().strftime("%Y-%m-%d")))).pack(side="right",padx=4)
        ttk.Button(date_controls,text="مسح التاريخ",command=lambda:(date_from_var.set(""),date_to_var.set(""))).pack(side="right",padx=4)

        info_var=tk.StringVar(value="جاري تحميل السجل..."); ttk.Label(self.content,textvariable=info_var,font=("Segoe UI",9,"bold")).pack(anchor="e",pady=(0,4))
        summary_var=tk.StringVar(value=""); ttk.Label(self.content,textvariable=summary_var,font=("Consolas",10,"bold")).pack(anchor="e",pady=(0,5))

        frame=ttk.Frame(self.content); frame.pack(fill="both",expand=True)
        cols=("id","time","type","from","to","amount","comm","user","source","status"); tree=ttk.Treeview(frame,columns=cols,show="headings",height=18)
        defs=[("id","#",58),("time","التاريخ والوقت ▼",150),("type","العملية",125),("from","من",130),("to","إلى",130),("amount","المبلغ",105),("comm","العمولة",95),("user","المستخدم",90),("source","المصدر",95),("status","الحالة",85)]
        for c,h,w in defs: tree.heading(c,text=h); tree.column(c,width=w,minwidth=55,anchor="center",stretch=(c in ("from","to")))
        vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); hs=ttk.Scrollbar(frame,orient="horizontal",command=tree.xview); tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tree.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns"); hs.grid(row=1,column=0,sticky="ew"); frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

        conn=get_db(); rows=conn.execute("""SELECT id,created_at,op_type,source_account,destination_account,amount,commission,performed_by,status,server_tx_id,client_tx_id,details,commission_account,customer_name,shift_id,reversed_transaction_id FROM transactions ORDER BY datetime(created_at) DESC,id DESC""").fetchall(); conn.close()
        records=[{"id":int(r[0]),"time":r[1],"type":r[2],"from":r[3] or "","to":r[4] or "","amount":float(r[5]),"comm":float(r[6]),"user":r[7] or "","status":r[8] or "active","server_tx_id":r[9],"client_tx_id":r[10] or "","details":r[11] or "","commission_account":r[12] or "","customer_name":r[13] or "","shift_id":r[14],"reversed_transaction_id":r[15],"movements":[],"source":"Windows محلي"} for r in rows]
        server_ok=False
        try:
            remote=self.server_request("GET","/api/v2/mobile/transactions?limit=1000",timeout=1.0); server_ok=True
            by_server={int(r["server_tx_id"]):r for r in records if r.get("server_tx_id") is not None}; by_client={str(r.get("client_tx_id")):r for r in records if r.get("client_tx_id")}
            for t in remote.get("items",[]):
                sid=int(t.get("id") or 0); cid=str(t.get("client_tx_id") or ""); existing=by_server.get(sid) or (by_client.get(cid) if cid else None)
                moves=t.get("movements") or []; neg=[m for m in moves if int(m.get("amount_fils") or 0)<0 and m.get("entry_type")!="commission"]; pos=[m for m in moves if int(m.get("amount_fils") or 0)>0 and m.get("entry_type")!="commission"]
                src=neg[0].get("account_name","") if neg else ""; dst=pos[0].get("account_name","") if pos else ""
                data={"time":str(t.get("created_at") or ""),"type":t.get("op_type") or "","from":src,"to":dst,"amount":int(t.get("amount_fils") or 0)/1000.0,"comm":int(t.get("commission_fils") or 0)/1000.0,"user":t.get("performed_by") or "","status":t.get("status") or "active","details":t.get("details") or "","customer_name":t.get("customer_name") or "","shift_id":t.get("shift_id"),"movements":moves,"source":"السيرفر"}
                if existing:
                    for k,v in data.items():
                        if v not in ("",None): existing[k]=v
                else:
                    records.append({"id":f"S{sid}","server_tx_id":sid,"client_tx_id":cid,**data})
        except Exception:
            server_ok=False
        records.sort(key=lambda r:(str(r["time"]),str(r["id"])),reverse=True)
        op_cb.configure(values=["الكل"]+sorted({r["type"] for r in records if r["type"]})); state={"mode":"time_desc"}
        def st(v): return "فعال" if v=="active" else ("معدل" if v=="modified" else ("معكوس" if v=="reversed" else "ملغي"))
        def _record_date(r):
            return str(r.get("time") or "")[:10]
        def visible_records():
            q=search_var.get().strip().lower(); op=op_var.get(); ss=status_var.get(); src=source_var.get(); out=[]
            df=date_from_var.get().strip(); dt=date_to_var.get().strip()
            for r in records:
                if op!="الكل" and r["type"]!=op: continue
                if ss!="الكل" and st(r["status"])!=ss: continue
                if src!="الكل" and r["source"]!=src: continue
                rd=_record_date(r)
                if df and rd and rd < df: continue
                if dt and rd and rd > dt: continue
                hay=" ".join(str(r.get(k,"")) for k in ("id","time","type","from","to","user","status","client_tx_id")).lower()
                if q and q not in hay: continue
                out.append(r)
            return out
        def render(items=None):
            items=visible_records() if items is None else items; tree.delete(*tree.get_children())
            for r in items: tree.insert("","end",values=(r["id"],self.to_english_digits(r["time"]),r["type"],r["from"],r["to"],f'{r["amount"]:,.3f} JD',f'{r["comm"]:,.3f} JD',r["user"],r["source"],st(r["status"])))
            info_var.set(f"{len(items)} عملية معروضة من أصل {len(records)}  |  السيرفر: {'متصل' if server_ok else 'غير متصل - عرض محلي'}")
            total_amount=sum(float(r.get("amount") or 0) for r in items if st(r.get("status")) in ("فعال","معدل"))
            total_comm=sum(float(r.get("comm") or 0) for r in items if st(r.get("status")) in ("فعال","معدل"))
            summary_var.set(f"إجمالي المبالغ المعروضة: {total_amount:,.3f} JD    |    إجمالي العمولات: {total_comm:,.3f} JD")
        def sort_type():
            desc=state["mode"]=="type_asc"; items=sorted(visible_records(),key=lambda r:(r["type"],r["time"],str(r["id"])),reverse=desc); state["mode"]="type_desc" if desc else "type_asc"; tree.heading("type",text="العملية ▼" if desc else "العملية ▲"); tree.heading("time",text="التاريخ والوقت"); render(items)
        def sort_time():
            desc=state["mode"]!="time_desc"; items=sorted(visible_records(),key=lambda r:(r["time"],str(r["id"])),reverse=desc); state["mode"]="time_desc" if desc else "time_asc"; tree.heading("time",text="التاريخ والوقت ▼" if desc else "التاريخ والوقت ▲"); tree.heading("type",text="العملية"); render(items)
        tree.heading("type",command=sort_type); tree.heading("time",command=sort_time)
        for v in (search_var,op_var,status_var,source_var,date_from_var,date_to_var): v.trace_add("write",lambda *_:render())
        render(); search_entry.focus_set()
        def export_visible_csv():
            items=visible_records()
            if not items:
                messagebox.showwarning("تنبيه","لا توجد عمليات معروضة للتصدير")
                return
            path=filedialog.asksaveasfilename(title="تصدير سجل العمليات",defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile=f"operations_{datetime.now().strftime('%Y%m%d_%H%M')}.csv")
            if not path: return
            with open(path,"w",newline="",encoding="utf-8-sig") as f:
                w=csv.writer(f); w.writerow(["#","التاريخ والوقت","العملية","من","إلى","المبلغ JD","العمولة JD","المستخدم","المصدر","الحالة"])
                for r in items:
                    w.writerow([r["id"],r["time"],r["type"],r["from"],r["to"],f'{r["amount"]:.3f}',f'{r["comm"]:.3f}',r["user"],r["source"],st(r["status"])])
            messagebox.showinfo("تم","تم تصدير العمليات المعروضة بنجاح")

        def selected_record():
            sel=tree.selection()
            if not sel:
                messagebox.showwarning("تنبيه","اختر عملية من السجل أولاً")
                return None
            display_id=str(tree.item(sel[0],"values")[0])
            for r in records:
                if str(r.get("id"))==display_id:
                    return r
            return None

        def operation_detail_text(r):
            status_name=st(r.get("status"))
            lines=[
                f"تفاصيل العملية {r.get('id','')}",
                "="*42,
                f"التاريخ والوقت: {r.get('time','')}",
                f"نوع العملية: {r.get('type','')}",
                f"الحالة: {status_name}",
                f"المبلغ: {float(r.get('amount') or 0):,.3f} JD",
                f"العمولة: {float(r.get('comm') or 0):,.3f} JD",
                f"من: {r.get('from') or '-'}",
                f"إلى: {r.get('to') or '-'}",
                f"المستخدم: {r.get('user') or '-'}",
                f"المصدر: {r.get('source') or '-'}",
                f"رقم الوردية: {r.get('shift_id') if r.get('shift_id') is not None else '-'}",
                f"العميل: {r.get('customer_name') or '-'}",
                f"التفاصيل: {r.get('details') or '-'}",
                f"Server TX ID: {r.get('server_tx_id') if r.get('server_tx_id') is not None else '-'}",
                f"Client TX ID: {r.get('client_tx_id') or '-'}",
            ]
            moves=r.get("movements") or []
            if moves:
                lines.extend(["", "الحركات المحاسبية:", "-"*42])
                for m in moves:
                    amt=int(m.get("amount_fils") or 0)/1000.0
                    et=m.get("entry_type") or "movement"
                    lines.append(f"{m.get('account_name') or m.get('account_id')}: {amt:+,.3f} JD  [{et}]")
            return "\n".join(lines)

        def show_operation_details(_event=None):
            r=selected_record()
            if not r: return
            if r.get("server_tx_id"):
                try:
                    fresh=self.server_request("GET",f"/api/v2/mobile/transactions/{int(r['server_tx_id'])}",timeout=1.2)
                    if isinstance(fresh,dict):
                        moves=fresh.get("movements") or []
                        neg=[m for m in moves if int(m.get("amount_fils") or 0)<0 and m.get("entry_type")!="commission"]
                        pos=[m for m in moves if int(m.get("amount_fils") or 0)>0 and m.get("entry_type")!="commission"]
                        r.update({
                            "time":str(fresh.get("created_at") or r.get("time") or ""),
                            "type":fresh.get("op_type") or r.get("type") or "",
                            "amount":int(fresh.get("amount_fils") or 0)/1000.0,
                            "comm":int(fresh.get("commission_fils") or 0)/1000.0,
                            "user":fresh.get("performed_by") or r.get("user") or "",
                            "status":fresh.get("status") or r.get("status") or "active",
                            "details":fresh.get("details") or "",
                            "customer_name":fresh.get("customer_name") or "",
                            "shift_id":fresh.get("shift_id"),
                            "movements":moves,
                            "from":neg[0].get("account_name","") if neg else r.get("from", ""),
                            "to":pos[0].get("account_name","") if pos else r.get("to", ""),
                        })
                except Exception:
                    pass
            text=operation_detail_text(r)
            win=tk.Toplevel(self.root); win.title("تفاصيل العملية"); win.geometry("720x620"); win.minsize(620,520)
            main=ttk.Frame(win,padding=12); main.pack(fill="both",expand=True)
            ttk.Label(main,text=f"🧾 تفاصيل العملية {r.get('id','')}",font=("Segoe UI",16,"bold")).pack(anchor="e",pady=(0,8))
            txt=tk.Text(main,wrap="word",font=("Consolas",10),height=24); txt.pack(fill="both",expand=True)
            txt.insert("1.0",text); txt.configure(state="disabled")
            actions=ttk.Frame(main); actions.pack(fill="x",pady=(8,0))
            ttk.Button(actions,text="📄 PDF / طباعة / مشاركة",command=lambda:self.report_actions_window(f"تفاصيل العملية {r.get('id','')}",text)).pack(side="right",padx=4)
            ttk.Button(actions,text="📋 نسخ التفاصيل",command=lambda:(self.root.clipboard_clear(),self.root.clipboard_append(text),messagebox.showinfo("تم","تم نسخ تفاصيل العملية",parent=win))).pack(side="right",padx=4)
            ttk.Button(actions,text="إغلاق",command=win.destroy).pack(side="left",padx=4)

        tree.bind("<Double-1>",show_operation_details)

        bar=ttk.Frame(self.content); bar.pack(fill="x",pady=7); ttk.Button(bar,text="🔄 مزامنة/تحديث",command=self.show_operation_log).pack(side="right",padx=4)
        ttk.Button(bar,text="🔎 تفاصيل العملية",command=show_operation_details).pack(side="right",padx=4)
        ttk.Button(bar,text="📄 تصدير المعروض CSV",command=export_visible_csv).pack(side="right",padx=4)
        if self.has_permission("edit_transactions"): ttk.Button(bar,text="✏ تعديل العملية",command=lambda:self.edit_transaction(tree)).pack(side="right",padx=4)
        if self.has_permission("cancel_transactions"): ttk.Button(bar,text="↩ إلغاء وعكس العملية",command=lambda:self.cancel_transaction(tree)).pack(side="right",padx=4)

    def show_account_statement(self):
        if not self.require_permission("statements","كشف الحساب"):
            return
        self.clear_content()

        ttk.Label(
            self.content, text="📖 كشف الحساب",
            font=("Segoe UI", 20, "bold")
        ).pack(anchor="e", pady=(5,8))

        controls = ttk.Frame(self.content)
        controls.pack(fill="x", pady=4)

        accounts = self.account_names()
        account_values = ["جميع الحسابات"] + accounts

        ttk.Label(controls, text="الحساب:").pack(side="right")
        account_cb = ttk.Combobox(
            controls, state="readonly", values=account_values, width=30
        )
        account_cb.set("جميع الحسابات")
        account_cb.pack(side="right", padx=4)

        ttk.Label(controls, text="شكل العرض:").pack(side="right", padx=(15,2))
        view_cb = ttk.Combobox(
            controls, state="readonly",
            values=["جدول", "بطاقات الحسابات"], width=18
        )
        default_view = self.get_setting("statement_default_view", "جدول")
        view_cb.set(default_view if default_view in ("جدول","بطاقات الحسابات") else "جدول")
        view_cb.pack(side="right", padx=4)

        ttk.Button(
            controls, text="🔄 عرض",
            command=lambda: render()
        ).pack(side="right", padx=5)

        if self.has_permission("share"):
            ttk.Button(
                controls,text="📤 مشاركة",
                command=lambda:self.share_text_choice(
                    "كشف الحساب",
                    self.build_account_statement_share_text(account_cb.get())
                )
            ).pack(side="left",padx=5)

        summary = ttk.Label(
            self.content, text="", font=("Segoe UI",10,"bold"),
            anchor="e", justify="right"
        )
        summary.pack(fill="x", pady=(3,6))

        body = ttk.Frame(self.content)
        body.pack(fill="both", expand=True)
        statement_sort = {"descending": True}

        def clear_body():
            for w in body.winfo_children():
                w.destroy()

        def tx_effects(row):
            # id,time,op,src,dst,amount,comm,comm_acc,details,status
            op,src,dst = row[2],row[3],row[4]
            amount=float(row[5]); comm=float(row[6]); comm_acc=row[7]
            details=row[8] or ""
            effects={}
            def add(acc, delta, comm_part=0.0):
                if not acc: return
                if acc not in effects:
                    effects[acc]={"delta":0.0,"comm":0.0,"out":0.0,"in":0.0}
                effects[acc]["delta"] += delta
                effects[acc]["comm"] += comm_part

            if op == "تسوية رصيد" and dst:
                m=re.search(r"من\s+(-?[\d,.]+)\s+إلى\s+(-?[\d,.]+)",details)
                if m:
                    old=float(m.group(1).replace(",",""))
                    new=float(m.group(2).replace(",",""))
                    add(dst,new-old)
                    if new-old<0: effects[dst]["out"] += -(new-old)
                    else: effects[dst]["in"] += new-old
                    return effects

            if src:
                add(src,-amount)
                effects[src]["out"] += amount
            if dst:
                add(dst,+amount)
                effects[dst]["in"] += amount
            if comm_acc and abs(comm)>0:
                add(comm_acc,comm,comm)
            return effects

        def get_rows():
            conn=get_db()
            rows=conn.execute("""
                SELECT id,created_at,op_type,source_account,destination_account,
                       amount,commission,commission_account,details,status
                FROM transactions
                ORDER BY datetime(created_at) ASC,id ASC
            """).fetchall()
            balances=dict(conn.execute("SELECT name,balance FROM accounts").fetchall())
            conn.close()
            return rows,balances

        def build_account_movements(selected_accounts):
            # V7.10.0: account statement comes from the authoritative server ledger.
            try:
                query = quote("|".join(selected_accounts), safe="|")
                data = self.server_request("GET", f"/api/v1/reports/account-statement?accounts={query}", timeout=10.0)
                movements={a:[] for a in selected_accounts}
                current_balances={}
                for block in data.get("accounts",[]):
                    a=block.get("account","")
                    if a not in movements:
                        continue
                    current_balances[a]=float(block.get("current_balance_fils",0))/1000.0
                    for m in block.get("movements",[]):
                        movements[a].append({
                            "id":m.get("id",0), "time":m.get("time",""), "op":m.get("op",""),
                            "details":m.get("details","") or "",
                            "before":float(m.get("before_fils",0))/1000.0,
                            "out":float(m.get("out_fils",0))/1000.0,
                            "in":float(m.get("in_fils",0))/1000.0,
                            "comm":float(m.get("commission_fils",0))/1000.0,
                            "net":float(m.get("net_fils",0))/1000.0,
                            "after":float(m.get("after_fils",0))/1000.0,
                        })
                return movements,current_balances
            except Exception:
                # Safe fallback for testing if the local API is temporarily unavailable.
                rows, current_balances = get_rows()
                movements={a:[] for a in selected_accounts}
                active_deltas={a:0.0 for a in selected_accounts}
                row_effect_cache=[]
                for row in rows:
                    effects=tx_effects(row) if row[9]=="active" else {}
                    row_effect_cache.append((row,effects))
                    for a in selected_accounts:
                        if a in effects:
                            active_deltas[a]+=effects[a]["delta"]
                running={}
                for a in selected_accounts:
                    running[a]=float(current_balances.get(a,0))-active_deltas[a]
                for row,effects in row_effect_cache:
                    if row[9]!="active":
                        continue
                    for a in selected_accounts:
                        if a not in effects:
                            continue
                        e=effects[a]; before=running[a]; after=before+e["delta"]
                        movements[a].append({
                            "id":row[0],"time":row[1],"op":row[2],"details":row[8] or "",
                            "before":before,"out":e["out"],"in":e["in"],
                            "comm":e["comm"],"net":e["delta"],"after":after
                        })
                        running[a]=after
                return movements,current_balances

        def render_table(selected_accounts):
            clear_body()
            frame=ttk.Frame(body)
            frame.pack(fill="both",expand=True)

            cols=("account","id","time","op","details","before","out","inside","commission","net","after")
            tree=ttk.Treeview(frame,columns=cols,show="headings")
            defs=[
                ("account","الحساب",170),("id","#",55),("time","التاريخ والوقت",145),
                ("op","العملية",120),("details","البيان",220),("before","الرصيد قبل",125),
                ("out","خارج",105),("inside","داخل",105),("commission","العمولة",100),
                ("net","صافي الحركة",115),("after","الرصيد بعد",125)
            ]
            for c,h,w in defs:
                tree.heading(c,text=h)
                tree.column(c,width=w,minwidth=65,anchor="center",stretch=(c=="details"))

            def toggle_statement_date():
                statement_sort["descending"] = not statement_sort["descending"]
                render()

            tree.heading(
                "time",
                text="التاريخ والوقت ▼" if statement_sort["descending"] else "التاريخ والوقت ▲",
                command=toggle_statement_date
            )

            vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview)
            hs=ttk.Scrollbar(frame,orient="horizontal",command=tree.xview)
            tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
            tree.grid(row=0,column=0,sticky="nsew")
            vs.grid(row=0,column=1,sticky="ns")
            hs.grid(row=1,column=0,sticky="ew")
            frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

            movements,current=build_account_movements(selected_accounts)

            display_rows=[]
            for a in selected_accounts:
                for mv in movements[a]:
                    display_rows.append((mv["time"], int(mv["id"]), a, mv))
            display_rows.sort(
                key=lambda x: (x[0], x[1]),
                reverse=statement_sort["descending"]
            )

            for _time,_id,a,mv in display_rows:
                tree.insert("", "end", values=(
                    a,mv["id"],self.to_english_digits(mv["time"]),
                    mv["op"] + (" (صادرة)" if mv["out"]>0 and mv["in"]==0 else
                                (" (واردة)" if mv["in"]>0 and mv["out"]==0 else "")),
                    mv["details"],
                    f'{mv["before"]:,.3f} JD',
                    f'{mv["out"]:,.3f} JD' if mv["out"] else "",
                    f'{mv["in"]:,.3f} JD' if mv["in"] else "",
                    f'{mv["comm"]:,.3f} JD' if mv["comm"] else "",
                    f'{mv["net"]:+,.3f} JD',
                    f'{mv["after"]:,.3f} JD'
                ))

            total=sum(float(current.get(a,0)) for a in selected_accounts)
            # Keep Arabic and numeric LTR segments separated to avoid Windows bidi artifacts.
            summary.config(text=f"عدد الحسابات: {len(selected_accounts)}    |    إجمالي الأرصدة الحالية: {total:,.3f} JD")

        def render_cards(selected_accounts):
            clear_body()
            canvas=tk.Canvas(body,highlightthickness=0)
            vs=ttk.Scrollbar(body,orient="vertical",command=canvas.yview)
            inner=ttk.Frame(canvas)
            wid=canvas.create_window((0,0),window=inner,anchor="nw")
            inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.bind("<Configure>",lambda e:(
                canvas.itemconfigure(wid,width=e.width),
                arrange_cards()
            ))
            canvas.configure(yscrollcommand=vs.set)
            canvas.pack(side="left",fill="both",expand=True)
            vs.pack(side="right",fill="y")

            movements,current=build_account_movements(selected_accounts)
            cards=[]

            for a in selected_accounts:
                card=ttk.LabelFrame(inner,text=f"🏦 {a}",padding=8)
                ttk.Label(
                    card,text=f"{float(current.get(a,0)):,.3f} JD",
                    font=("Consolas",14,"bold")
                ).pack(anchor="e",pady=(0,5))

                recent=movements[a][-8:]
                if not recent:
                    ttk.Label(card,text="لا توجد حركات مسجلة").pack(anchor="e",pady=5)
                else:
                    for idx,mv in enumerate(reversed(recent)):
                        bg="#FFFFFF" if idx % 2 == 0 else "#EEF3F8"
                        row=tk.Frame(card,bg=bg)
                        row.pack(fill="x",pady=0)
                        tk.Label(
                            row,text=f'{mv["net"]:+,.3f} JD',
                            font=("Consolas",9,"bold"),width=15,
                            bg=bg,fg="#172033",anchor="w"
                        ).pack(side="left",padx=5,pady=5)
                        tk.Label(
                            row,text=f'{mv["op"]}  |  #{mv["id"]}',
                            anchor="e",bg=bg,fg="#172033"
                        ).pack(side="right",fill="x",expand=True,padx=5,pady=5)
                cards.append(card)

            def arrange_cards():
                width=max(canvas.winfo_width(),700)
                columns=2 if width<1350 else 3
                for i,card in enumerate(cards):
                    card.grid_forget()
                    card.grid(row=i//columns,column=i%columns,sticky="nsew",padx=6,pady=6)
                for c in range(columns):
                    inner.columnconfigure(c,weight=1)

            arrange_cards()
            total=sum(float(current.get(a,0)) for a in selected_accounts)
            summary.config(
                text=f"عرض بطاقات الحسابات   |   عدد الحسابات: {len(selected_accounts)}   |   "
                     f"إجمالي الأرصدة: {total:,.3f} JD"
            )

        def render():
            selected=account_cb.get()
            selected_accounts=accounts if selected=="جميع الحسابات" else ([selected] if selected else [])
            if not selected_accounts:
                summary.config(text="")
                clear_body()
                return
            if view_cb.get()=="بطاقات الحسابات":
                render_cards(selected_accounts)
            else:
                render_table(selected_accounts)

        account_cb.bind("<<ComboboxSelected>>",lambda e:render())
        view_cb.bind("<<ComboboxSelected>>",lambda e:render())
        render()

    def debt_window(self, payment=False, selected_customer=None):
        win = tk.Toplevel(self.root)
        win.title("سداد دين" if payment else "دين للعميل")
        win.geometry("540x510")
        win.minsize(480, 440)

        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame, text="سداد دين" if payment else "إضافة دين للعميل",
            font=("Segoe UI", 15, "bold")
        ).pack(pady=10)

        conn = get_db()
        customer_rows = conn.execute("""
            SELECT name FROM customers WHERE active=1 ORDER BY name
        """).fetchall()
        conn.close()
        customer_names = [r[0] for r in customer_rows]

        ttk.Label(frame, text="العميل").pack(anchor="e")
        customer = ttk.Combobox(frame, state="readonly", values=customer_names)
        customer.pack(fill="x", pady=5)
        if selected_customer in customer_names:
            customer.set(selected_customer)
        elif customer_names:
            customer.set(customer_names[0])

        addbar = ttk.Frame(frame)
        addbar.pack(fill="x", pady=(0,5))
        ttk.Button(
            addbar, text="➕ إضافة عميل جديد",
            command=lambda: self.customer_window(parent_to_refresh=win)
        ).pack(side="right")

        customer_info = ttk.Label(frame, text="", justify="right")
        customer_info.pack(fill="x", pady=4)

        def update_customer_info(_e=None):
            name = customer.get()
            if not name:
                customer_info.config(text="")
                return
            conn = get_db()
            row = conn.execute("""
                SELECT debt_balance,debt_limit,phone
                FROM customers WHERE name=?
            """,(name,)).fetchone()
            conn.close()
            if row:
                limit_text = "بدون حد" if float(row[1]) <= 0 else f"{float(row[1]):,.3f} JD"
                customer_info.config(
                    text=f"الدين الحالي: {float(row[0]):,.3f} JD   |   "
                         f"حد الدين: {limit_text}   |   الهاتف: {row[2] or '-'}"
                )

        customer.bind("<<ComboboxSelected>>", update_customer_info)
        update_customer_info()

        ttk.Label(frame, text="المبلغ (JD)").pack(anchor="e")
        amount = ttk.Entry(frame, justify="right")
        self.setup_entry(amount)
        amount.pack(fill="x", pady=5)

        ttk.Label(frame, text="الحساب").pack(anchor="e")
        accounts = self.account_names()
        acc = ttk.Combobox(frame, state="readonly", values=accounts)
        acc.pack(fill="x", pady=5)
        cash_default = self.get_setting("default_cash_account", "النقد كاش")
        if cash_default in accounts:
            acc.set(cash_default)
        elif accounts:
            acc.set(accounts[0])

        ttk.Label(frame, text="ملاحظات / سبب الدين").pack(anchor="e")
        note = ttk.Entry(frame, justify="right")
        self.setup_entry(note, select_all_on_focus=False)
        note.pack(fill="x", pady=5)

        def save():
            name = customer.get().strip()
            if not name:
                messagebox.showwarning("تنبيه", "اختر العميل أولاً", parent=win)
                return
            try:
                amt = self.parse_number(amount.get())
            except ValueError:
                messagebox.showerror("خطأ", "المبلغ غير صحيح", parent=win)
                return
            if amt <= 0:
                messagebox.showerror("خطأ", "المبلغ يجب أن يكون أكبر من صفر", parent=win)
                return

            account = acc.get()
            if not account:
                messagebox.showwarning("تنبيه", "اختر الحساب", parent=win)
                return

            conn = get_db()
            cur = conn.cursor()
            row = cur.execute("""
                SELECT debt_balance,debt_limit FROM customers
                WHERE name=? AND active=1
            """,(name,)).fetchone()
            if not row:
                conn.close()
                messagebox.showerror("خطأ", "العميل غير موجود أو معطل", parent=win)
                return

            current_debt = float(row[0])
            debt_limit = float(row[1])

            if payment:
                if amt > current_debt + 0.0000001:
                    conn.close()
                    messagebox.showerror(
                        "خطأ",
                        f"السداد {amt:,.3f} JD أكبر من الدين الحالي {current_debt:,.3f} JD",
                        parent=win
                    )
                    return
                if not self.server_submit_debt_operation(
                    "سداد دين", account, amt, name, note.get().strip(), parent=win
                ):
                    conn.close()
                    return
                cur.execute(
                    "UPDATE customers SET debt_balance=debt_balance-? WHERE name=?",
                    (amt,name)
                )
                self.change_balance(cur, account, amt)
                op, src, dst = "سداد دين", "", account
            else:
                new_debt = current_debt + amt
                if debt_limit > 0 and new_debt > debt_limit + 0.0000001:
                    conn.close()
                    messagebox.showerror(
                        "تجاوز حد الدين",
                        f"حد دين العميل: {debt_limit:,.3f} JD\n"
                        f"الدين بعد العملية سيصبح: {new_debt:,.3f} JD",
                        parent=win
                    )
                    return
                if self.get_balance(account) < amt:
                    conn.close()
                    messagebox.showerror(
                        "خطأ",
                        f"رصيد الحساب لا يكفي. الرصيد الحالي: {self.get_balance(account):,.3f} JD",
                        parent=win
                    )
                    return
                if not self.server_submit_debt_operation(
                    "دين للعميل", account, amt, name, note.get().strip(), parent=win
                ):
                    conn.close()
                    return
                cur.execute(
                    "UPDATE customers SET debt_balance=debt_balance+? WHERE name=?",
                    (amt,name)
                )
                self.change_balance(cur, account, -amt)
                op, src, dst = "دين للعميل", account, ""

            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            shift = cur.execute(
                "SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1"
            ).fetchone()
            shift_id = shift[0] if shift else None

            cur.execute("""
                INSERT INTO transactions(
                    created_at,op_type,source_account,destination_account,
                    amount,commission,commission_account,customer_name,
                    details,performed_by,status,shift_id
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                now,op,src,dst,amt,0,"",name,note.get().strip(),
                self.username,"active",shift_id
            ))

            self._link_pending_server_transaction(cur, cur.lastrowid)
            conn.commit()
            conn.close()
            self.log(op, f"{name} - {amt:.3f} JD")
            messagebox.showinfo("تم", f"تم تسجيل العملية بمبلغ {amt:,.3f} JD", parent=win)
            win.destroy()
            self.show_debts()

        note.bind("<Return>", lambda e: save())
        ttk.Button(frame, text="حفظ العملية", command=save).pack(pady=20, ipadx=25, ipady=6)

    def show_debts(self):
        if not self.require_permission("customers","العملاء والديون"):
            return
        self.clear_content()

        ttk.Label(
            self.content, text="العملاء والديون",
            font=("Segoe UI",20,"bold")
        ).pack(anchor="e",pady=(5,8))

        bar = ttk.Frame(self.content)
        bar.pack(fill="x", pady=5)
        ttk.Button(bar, text="➕ إضافة عميل",
                   command=self.customer_window).pack(side="right", padx=4)
        ttk.Button(bar, text="💳 إضافة دين",
                   command=lambda:self.open_debt_for_selected(tree, False)).pack(side="right", padx=4)
        ttk.Button(bar, text="💵 سداد دين",
                   command=lambda:self.open_debt_for_selected(tree, True)).pack(side="right", padx=4)
        ttk.Button(bar, text="📖 كشف دين العميل",
                   command=lambda:self.customer_statement_window(tree)).pack(side="right", padx=4)
        ttk.Button(bar, text="✏ تعديل العميل",
                   command=lambda:self.edit_selected_customer(tree)).pack(side="right", padx=4)

        filters = ttk.LabelFrame(self.content, text="بحث وتصفية العملاء", padding=8)
        filters.pack(fill="x", pady=5)
        search_var = tk.StringVar()
        debt_filter = tk.StringVar(value="الكل")
        ttk.Label(filters, text="بحث بالاسم أو الهاتف").pack(side="right", padx=4)
        search_entry = ttk.Entry(filters, textvariable=search_var, justify="right", width=28)
        search_entry.pack(side="right", padx=4)
        ttk.Label(filters, text="حالة الدين").pack(side="right", padx=(15,4))
        debt_cb = ttk.Combobox(filters, state="readonly", textvariable=debt_filter,
                               values=["الكل","عليه دين","بدون دين","قريب من الحد"], width=16)
        debt_cb.pack(side="right", padx=4)

        frame = ttk.Frame(self.content)
        frame.pack(fill="both", expand=True, pady=8)

        cols = ("name","phone","limit","debt","available","status")
        tree = ttk.Treeview(frame, columns=cols, show="headings")
        defs = [
            ("name","العميل",240),
            ("phone","الهاتف",150),
            ("limit","حد الدين",150),
            ("debt","الدين الحالي",150),
            ("available","المتاح",150),
            ("status","الحالة",100)
        ]
        for c,h,w in defs:
            tree.heading(c,text=h)
            tree.column(c,width=w,minwidth=80,anchor="center",stretch=(c=="name"))

        vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview)
        hs=ttk.Scrollbar(frame,orient="horizontal",command=tree.xview)
        tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tree.grid(row=0,column=0,sticky="nsew")
        vs.grid(row=0,column=1,sticky="ns")
        hs.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1)
        frame.columnconfigure(0,weight=1)

        conn = get_db()
        rows = conn.execute("""
            SELECT name,phone,debt_limit,debt_balance,active
            FROM customers ORDER BY name
        """).fetchall()
        conn.close()

        summary_var = tk.StringVar()

        def refresh_customers(*_):
            for item in tree.get_children(): tree.delete(item)
            q = search_var.get().strip().lower()
            mode = debt_filter.get()
            total_debt = 0.0
            shown = 0
            for name,phone,limit,debt,active in rows:
                debt=float(debt); limit=float(limit)
                if q and q not in str(name).lower() and q not in str(phone or "").lower():
                    continue
                if mode=="عليه دين" and debt <= 0: continue
                if mode=="بدون دين" and debt > 0: continue
                if mode=="قريب من الحد" and not (limit>0 and debt>=limit*0.8): continue
                total_debt += debt; shown += 1
                available = f"{max(0,limit-debt):,.3f} JD" if limit>0 else "بدون حد"
                tree.insert("", "end", values=(
                    name, phone or "-", f"{limit:,.3f} JD" if limit>0 else "بدون حد",
                    f"{debt:,.3f} JD", available, "فعال" if active else "معطل"
                ))
            summary_var.set(f"العملاء المعروضون: {shown}   |   إجمالي الديون المعروضة: {total_debt:,.3f} JD")

        search_var.trace_add("write", refresh_customers)
        debt_cb.bind("<<ComboboxSelected>>", refresh_customers)
        refresh_customers()
        ttk.Label(self.content, textvariable=summary_var,
                  font=("Segoe UI",12,"bold")).pack(anchor="e",pady=5)

    def customer_window(self, parent_to_refresh=None):
        win=tk.Toplevel(self.root)
        win.title("إضافة عميل")
        win.geometry("500x520")
        f=ttk.Frame(win,padding=20); f.pack(fill="both",expand=True)

        ttk.Label(f,text="إضافة عميل جديد",font=("Segoe UI",15,"bold")).pack(pady=8)

        fields={}
        for key,label in [
            ("name","اسم العميل *"),
            ("phone","رقم الهاتف"),
            ("address","العنوان"),
            ("debt_limit","حد الدين (JD) - صفر يعني بدون حد"),
            ("notes","ملاحظات")
        ]:
            ttk.Label(f,text=label).pack(anchor="e")
            e=ttk.Entry(f,justify="right")
            self.setup_entry(e, select_all_on_focus=(key=="debt_limit"))
            if key=="debt_limit": e.insert(0,"0.000")
            e.pack(fill="x",pady=4)
            fields[key]=e

        def save():
            name=fields["name"].get().strip()
            if not name:
                messagebox.showwarning("تنبيه","اسم العميل مطلوب",parent=win); return
            try:
                limit=self.parse_number(fields["debt_limit"].get() or 0)
                if limit < 0: raise ValueError
            except ValueError:
                messagebox.showerror("خطأ","حد الدين غير صحيح",parent=win); return

            conn=get_db()
            try:
                conn.execute("""
                    INSERT INTO customers(name,phone,address,debt_limit,notes,debt_balance,active)
                    VALUES(?,?,?,?,?,0,1)
                """,(
                    name,fields["phone"].get().strip(),fields["address"].get().strip(),
                    limit,fields["notes"].get().strip()
                ))
                conn.commit(); conn.close()
                self.log("إضافة عميل",name)
                messagebox.showinfo("تم","تمت إضافة العميل",parent=win)
                win.destroy()
                self.show_debts()
                if parent_to_refresh is not None:
                    try: parent_to_refresh.destroy()
                    except Exception: pass
            except sqlite3.IntegrityError:
                conn.close()
                messagebox.showerror("خطأ","يوجد عميل بهذا الاسم مسبقاً",parent=win)

        fields["notes"].bind("<Return>",lambda e:save())
        ttk.Button(f,text="حفظ العميل",command=save).pack(pady=15,ipadx=25,ipady=6)

    def get_selected_customer_name(self, tree):
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه","اختر عميلاً أولاً")
            return None
        return tree.item(sel[0])["values"][0]

    def open_debt_for_selected(self, tree, payment):
        name=self.get_selected_customer_name(tree)
        if name:
            self.debt_window(payment=payment, selected_customer=name)

    def edit_selected_customer(self, tree):
        name=self.get_selected_customer_name(tree)
        if not name: return

        conn=get_db()
        row=conn.execute("""
            SELECT name,phone,address,debt_limit,notes,active
            FROM customers WHERE name=?
        """,(name,)).fetchone()
        conn.close()
        if not row: return

        win=tk.Toplevel(self.root)
        win.title("تعديل العميل")
        win.geometry("500x560")
        f=ttk.Frame(win,padding=20); f.pack(fill="both",expand=True)

        entries={}
        for key,label,value in [
            ("name","اسم العميل",row[0]),
            ("phone","رقم الهاتف",row[1] or ""),
            ("address","العنوان",row[2] or ""),
            ("limit","حد الدين (JD)",f"{float(row[3]):.3f}"),
            ("notes","ملاحظات",row[4] or "")
        ]:
            ttk.Label(f,text=label).pack(anchor="e")
            e=ttk.Entry(f,justify="right"); e.insert(0,value); e.pack(fill="x",pady=4)
            entries[key]=e

        active=tk.BooleanVar(value=bool(row[5]))
        ttk.Checkbutton(f,text="العميل فعال",variable=active).pack(anchor="e",pady=8)

        def save():
            newname=entries["name"].get().strip()
            if not newname:
                messagebox.showwarning("تنبيه","اسم العميل مطلوب",parent=win); return
            try: limit=self.parse_number(entries["limit"].get())
            except ValueError:
                messagebox.showerror("خطأ","حد الدين غير صحيح",parent=win); return

            conn=get_db(); cur=conn.cursor()
            try:
                cur.execute("""
                    UPDATE customers SET name=?,phone=?,address=?,debt_limit=?,notes=?,active=?
                    WHERE name=?
                """,(
                    newname,entries["phone"].get().strip(),entries["address"].get().strip(),
                    limit,entries["notes"].get().strip(),1 if active.get() else 0,name
                ))
                if newname != name:
                    cur.execute("UPDATE transactions SET customer_name=? WHERE customer_name=?",(newname,name))
                conn.commit(); conn.close()
                self.log("تعديل عميل",f"{name} -> {newname}")
                win.destroy(); self.show_debts()
            except sqlite3.IntegrityError:
                conn.rollback(); conn.close()
                messagebox.showerror("خطأ","اسم العميل مستخدم مسبقاً",parent=win)

        ttk.Button(f,text="حفظ التعديل",command=save).pack(pady=15)

    def customer_statement_window(self, tree):
        name=self.get_selected_customer_name(tree)
        if not name: return

        conn=get_db()
        customer=conn.execute("""
            SELECT debt_balance,debt_limit,phone,address,notes
            FROM customers WHERE name=?
        """,(name,)).fetchone()
        rows=conn.execute("""
            SELECT id,created_at,op_type,amount,details,performed_by,status
            FROM transactions
            WHERE customer_name=? AND op_type IN ('دين للعميل','سداد دين')
            ORDER BY created_at,id
        """,(name,)).fetchall()
        conn.close()

        win=tk.Toplevel(self.root)
        win.title(f"كشف دين العميل - {name}")
        win.geometry("950x650"); win.minsize(700,450)

        main=ttk.Frame(win,padding=10); main.pack(fill="both",expand=True)
        ttk.Label(main,text=name,font=("Segoe UI",17,"bold")).pack(anchor="e")

        if customer:
            info=ttk.Frame(main); info.pack(fill="x",pady=6)
            for label,value in [
                ("الدين الحالي",f"{float(customer[0]):,.3f} JD"),
                ("حد الدين","بدون حد" if float(customer[1])<=0 else f"{float(customer[1]):,.3f} JD"),
                ("الهاتف",customer[2] or "-")
            ]:
                box=ttk.LabelFrame(info,text=label,padding=6)
                box.pack(side="right",padx=4,fill="x",expand=True)
                ttk.Label(box,text=value,font=("Consolas",11,"bold")).pack()

        frame=ttk.Frame(main); frame.pack(fill="both",expand=True,pady=8)
        cols=("id","time","type","amount","change","balance","details","user","status")
        tv=ttk.Treeview(frame,columns=cols,show="headings")
        defs=[
            ("id","#",55),("time","التاريخ والوقت",155),("type","النوع",110),
            ("amount","المبلغ",115),("change","الحركة",115),("balance","الرصيد بعد",120),
            ("details","الملاحظات",200),("user","المستخدم",100),("status","الحالة",90)
        ]
        for c,h,w in defs:
            tv.heading(c,text=h); tv.column(c,width=w,minwidth=70,anchor="center",stretch=(c=="details"))
        vs=ttk.Scrollbar(frame,orient="vertical",command=tv.yview)
        hs=ttk.Scrollbar(frame,orient="horizontal",command=tv.xview)
        tv.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tv.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns"); hs.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

        running=0.0
        for r in rows:
            if r[6]!="active": continue
            delta=float(r[3]) if r[2]=="دين للعميل" else -float(r[3])
            running += delta
            tv.insert("", "end", values=(
                r[0],self.to_english_digits(r[1]),r[2],
                f"{float(r[3]):,.3f} JD",
                f"{delta:+,.3f} JD",
                f"{running:,.3f} JD",
                r[4] or "",r[5] or "","فعال"
            ))

        total_debt_added=sum(float(r[3]) for r in rows if r[2]=="دين للعميل" and r[6]=="active")
        total_paid=sum(float(r[3]) for r in rows if r[2]=="سداد دين" and r[6]=="active")
        ttk.Label(main,text=f"إجمالي الدين المسجل: {total_debt_added:,.3f} JD   |   إجمالي السداد: {total_paid:,.3f} JD   |   المتبقي: {running:,.3f} JD",
                  font=("Segoe UI",11,"bold")).pack(anchor="e",pady=4)

        def statement_text():
            lines=[f"كشف حساب العميل: {name}","="*60]
            if customer:
                lines += [f"الهاتف: {customer[2] or '-'}", f"العنوان: {customer[3] or '-'}",
                          f"الدين الحالي: {float(customer[0]):,.3f} JD",
                          f"حد الدين: {'بدون حد' if float(customer[1])<=0 else f'{float(customer[1]):,.3f} JD'}", ""]
            lines += [f"إجمالي الدين: {total_debt_added:,.3f} JD", f"إجمالي السداد: {total_paid:,.3f} JD", f"الرصيد المتبقي: {running:,.3f} JD", "", "الحركات:"]
            bal=0.0
            for r in rows:
                if r[6] != "active": continue
                d=float(r[3]) if r[2]=="دين للعميل" else -float(r[3]); bal += d
                lines.append(f"{r[1]} | {r[2]} | {float(r[3]):,.3f} JD | الرصيد {bal:,.3f} JD | {r[4] or ''}")
            return "\n".join(lines)

        actions=ttk.Frame(main); actions.pack(fill="x",pady=6)
        ttk.Button(actions,text="📄 PDF",command=lambda:self.save_report_pdf(f"كشف حساب العميل - {name}",statement_text())).pack(side="right",padx=4)
        ttk.Button(actions,text="🖨 طباعة / مشاركة",command=lambda:self.report_actions_window(f"كشف حساب العميل - {name}",statement_text())).pack(side="right",padx=4)
        ttk.Button(actions,text="💳 إضافة دين",command=lambda:self.debt_window(False,name)).pack(side="right",padx=4)
        ttk.Button(actions,text="💵 سداد",command=lambda:self.debt_window(True,name)).pack(side="right",padx=4)

    def show_reports(self):
        if not self.require_permission("reports","التقارير"):
            return
        self.clear_content()
        ttk.Label(self.content,text="التقارير والأرباح",
                  font=("Segoe UI",20,"bold")).pack(anchor="e",pady=(5,8))

        controls=ttk.LabelFrame(self.content,text="الفترة",padding=10)
        controls.pack(fill="x",pady=5)

        period=ttk.Combobox(controls,state="readonly",
                            values=["اليوم","هذا الأسبوع","هذا الشهر","هذه السنة","فترة مخصصة"],
                            width=18)
        period.set("اليوم"); period.pack(side="right",padx=4)

        ttk.Label(controls,text="من YYYY-MM-DD").pack(side="right",padx=(12,2))
        from_e=ttk.Entry(controls,width=13,justify="center"); from_e.pack(side="right",padx=2)
        ttk.Label(controls,text="إلى YYYY-MM-DD").pack(side="right",padx=(12,2))
        to_e=ttk.Entry(controls,width=13,justify="center"); to_e.pack(side="right",padx=2)

        summary=ttk.Frame(self.content); summary.pack(fill="x",pady=8)
        summary_labels={}
        for key,title in [("profit","صافي العمولات/الربح"),("count","عدد العمليات التجارية"),("amount","حجم العمليات التجارية"),("accounting","حركات محاسبية")]:
            box=ttk.LabelFrame(summary,text=title,padding=8)
            box.pack(side="right",fill="x",expand=True,padx=4)
            num=ttk.Label(box,text="0.000",font=("Consolas",16,"bold"))
            num.pack()
            summary_labels[key]=num

        frame=ttk.Frame(self.content); frame.pack(fill="both",expand=True)
        cols=("category","type","count","amount","commission")
        tree=ttk.Treeview(frame,columns=cols,show="headings")
        for c,h,w in [("category","التصنيف",130),("type","نوع العملية",230),("count","العدد",100),
                      ("amount","إجمالي المبالغ",170),("commission","العمولات/الربح",170)]:
            tree.heading(c,text=h); tree.column(c,width=w,anchor="center",stretch=True)
        vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview)
        tree.configure(yscrollcommand=vs.set)
        tree.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

        def date_range():
            now=datetime.now()
            p=period.get()
            if p=="اليوم":
                start=now.strftime("%Y-%m-%d"); end=start
            elif p=="هذا الأسبوع":
                from datetime import timedelta
                start=(now-timedelta(days=now.weekday())).strftime("%Y-%m-%d")
                end=now.strftime("%Y-%m-%d")
            elif p=="هذا الشهر":
                start=now.strftime("%Y-%m-01"); end=now.strftime("%Y-%m-%d")
            elif p=="هذه السنة":
                start=now.strftime("%Y-01-01"); end=now.strftime("%Y-%m-%d")
            else:
                start=from_e.get().strip(); end=to_e.get().strip()
                try:
                    datetime.strptime(start,"%Y-%m-%d"); datetime.strptime(end,"%Y-%m-%d")
                except ValueError:
                    raise ValueError("اكتب التاريخ بصيغة YYYY-MM-DD")
            return start+" 00:00:00", end+" 23:59:59"

        def show_account_performance():
            try:
                start,end=date_range()
            except ValueError as e:
                messagebox.showerror("خطأ",str(e)); return
            try:
                data=self.server_request(
                    "GET", f"/api/v1/reports/accounts-performance?date_from={quote(start)}&date_to={quote(end)}", timeout=1.2
                )
            except Exception as exc:
                messagebox.showerror("تعذر تحميل التقرير",f"تقرير أداء الحسابات يحتاج اتصال السيرفر.\n\n{exc}")
                return

            win=tk.Toplevel(self.root)
            win.title("أداء الحسابات والحركة المالية")
            win.geometry("1120x650"); win.minsize(850,500)
            main=ttk.Frame(win,padding=10); main.pack(fill="both",expand=True)
            ttk.Label(main,text="📈 أداء الحسابات والحركة المالية",font=("Segoe UI",16,"bold")).pack(anchor="e")
            ttk.Label(main,text=f"الفترة: {start[:10]} إلى {end[:10]}",font=("Segoe UI",9)).pack(anchor="e",pady=(0,8))

            totals=data.get("totals",{})
            cards=ttk.Frame(main); cards.pack(fill="x",pady=5)
            for title,key in [("إجمالي الداخل","incoming_fils"),("إجمالي الخارج","outgoing_fils"),("العمولات","commission_fils"),("صافي الحركة","net_movement_fils")]:
                box=ttk.LabelFrame(cards,text=title,padding=6); box.pack(side="right",fill="x",expand=True,padx=3)
                val=float(totals.get(key,0))/1000.0
                ttk.Label(box,text=f"{val:+,.3f} JD" if key=="net_movement_fils" else f"{val:,.3f} JD",font=("Consolas",12,"bold")).pack()

            frame=ttk.Frame(main); frame.pack(fill="both",expand=True,pady=6)
            cols=("account","opening","in","out","comm","net","current","count")
            tv=ttk.Treeview(frame,columns=cols,show="headings")
            defs=[("account","الحساب",220),("opening","الرصيد أول الفترة",145),("in","داخل",125),("out","خارج",125),("comm","عمولات",115),("net","صافي الحركة",130),("current","الرصيد الحالي",145),("count","عدد العمليات",95)]
            for c,h,w in defs:
                tv.heading(c,text=h); tv.column(c,width=w,minwidth=70,anchor="center",stretch=(c=="account"))
            vs=ttk.Scrollbar(frame,orient="vertical",command=tv.yview); hs=ttk.Scrollbar(frame,orient="horizontal",command=tv.xview)
            tv.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
            tv.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns"); hs.grid(row=1,column=0,sticky="ew")
            frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
            export_rows=[]
            for a in data.get("accounts",[]):
                vals=(
                    a.get("account_name",""),
                    f"{int(a.get('opening_balance_fils',0))/1000.0:,.3f} JD",
                    f"{int(a.get('incoming_fils',0))/1000.0:,.3f} JD",
                    f"{int(a.get('outgoing_fils',0))/1000.0:,.3f} JD",
                    f"{int(a.get('commission_fils',0))/1000.0:+,.3f} JD",
                    f"{int(a.get('net_movement_fils',0))/1000.0:+,.3f} JD",
                    f"{int(a.get('current_balance_fils',0))/1000.0:,.3f} JD",
                    int(a.get("transaction_count",0)),
                )
                tv.insert("","end",values=vals); export_rows.append(vals)

            def export_csv():
                path=filedialog.asksaveasfilename(parent=win,title="حفظ تقرير أداء الحسابات",defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile=f"accounts_performance_{start[:10]}_{end[:10]}.csv")
                if not path: return
                with open(path,"w",newline="",encoding="utf-8-sig") as f:
                    w=csv.writer(f); w.writerow([x[1] for x in defs]); w.writerows(export_rows)
                messagebox.showinfo("تم","تم حفظ التقرير بنجاح",parent=win)
            ttk.Button(main,text="⬇ تصدير CSV",command=export_csv).pack(anchor="e",pady=5)

        def load():
            try:
                start,end=date_range()
            except ValueError as e:
                messagebox.showerror("خطأ",str(e)); return
            tree.delete(*tree.get_children())
            try:
                qfrom=quote(start); qto=quote(end)
                data=self.server_request("GET",f"/api/v1/reports/summary?date_from={qfrom}&date_to={qto}",timeout=0.9)
                category_names={"business":"تجاري","accounting":"محاسبي فقط","correction":"تصحيح/عكس"}
                rows=[(category_names.get(g.get("category","business"),"تجاري"),g.get("op_type",""),int(g.get("count",0)),float(g.get("amount_fils",0))/1000.0,float(g.get("commission_fils",0))/1000.0) for g in data.get("groups",[])]
                totals=(int(data.get("business_count",0)),float(data.get("business_amount_fils",0))/1000.0,float(data.get("net_commission_fils",0))/1000.0,int(data.get("accounting_count",0)))
            except Exception:
                conn=get_db()
                raw=conn.execute("""
                    SELECT op_type,COUNT(*),COALESCE(SUM(amount),0),COALESCE(SUM(commission),0)
                    FROM transactions WHERE created_at BETWEEN ? AND ? AND status='active'
                    GROUP BY op_type ORDER BY op_type
                """,(start,end)).fetchall()
                accounting_only={"تسوية رصيد","رصيد افتتاحي","مطابقة وردية"}
                rows=[]; business_count=0; business_amount=0.0; net_profit=0.0; accounting_count=0
                for op,cnt,amt,commv in raw:
                    if op in accounting_only:
                        cat="محاسبي فقط"; accounting_count+=int(cnt)
                    elif str(op).startswith("عكس:"):
                        cat="تصحيح/عكس"; net_profit+=float(commv or 0)
                    else:
                        cat="تجاري"; business_count+=int(cnt); business_amount+=float(amt or 0); net_profit+=float(commv or 0)
                    rows.append((cat,op,cnt,amt,commv))
                totals=(business_count,business_amount,net_profit,accounting_count)
                conn.close()
            for r in rows:
                tree.insert("", "end", values=(r[0],r[1],str(r[2]),self.ltr_number(r[3]),self.ltr_number(r[4])))
            summary_labels["count"].config(text=str(totals[0]))
            summary_labels["amount"].config(text=f"{float(totals[1]):,.3f}")
            summary_labels["profit"].config(text=f"{float(totals[2]):,.3f}")
            summary_labels["accounting"].config(text=str(totals[3]))

        ttk.Button(controls,text="عرض",command=load).pack(side="right",padx=8)
        ttk.Button(controls,text="📈 أداء الحسابات",command=show_account_performance).pack(side="right",padx=4)
        period.bind("<<ComboboxSelected>>",lambda e:load())
        load()

    def server_current_shift(self):
        """V7.10.0: read the authoritative open shift and balances from the local server."""
        return self.server_request("GET", "/api/v1/shifts/current", timeout=8.0)

    def server_close_shift(self, parsed, parent=None):
        """V7.10.0: close the authoritative server shift before mirroring the close locally."""
        try:
            current = self.server_current_shift()
            by_name = {a["account_name"]: int(a["account_id"]) for a in current.get("accounts", [])}
            payload = {"accounts": []}
            for name, _system_bal, actual, _diff, reason in parsed:
                if name not in by_name:
                    raise RuntimeError(f"الحساب غير موجود على السيرفر: {name}")
                payload["accounts"].append({
                    "account_id": by_name[name],
                    "actual_balance_fils": int(round(float(actual) * 1000)),
                    "reason": reason or "",
                })
            result = self.server_request(
                "POST", f"/api/v1/shifts/{int(current['id'])}/close", payload, timeout=12.0
            )
            return result
        except Exception as exc:
            messagebox.showerror(
                "تعذر إنهاء الوردية",
                "لم يتم إنهاء الوردية لأن السيرفر رفض المطابقة أو انقطع الاتصال.\n\n"
                f"{exc}\n\nلم يتم تغيير الوردية المحلية.",
                parent=parent or self.root,
            )
            return None

    def show_balance_compare(self):
        if not self.require_permission("reconcile","مطابقة الأرصدة"):
            return
        self.clear_content()

        ttk.Label(
            self.content,text="⚖️ مطابقة الأرصدة",
            font=("Segoe UI",20,"bold")
        ).pack(anchor="e",pady=(5,8))

        notebook=ttk.Notebook(self.content)
        notebook.pack(fill="both",expand=True)

        current_tab=ttk.Frame(notebook,padding=8)
        history_tab=ttk.Frame(notebook,padding=8)
        notebook.add(current_tab,text="مطابقة حالية")
        notebook.add(history_tab,text="سجل مطابقة الورديات")

        # ---- current comparison ----
        ttk.Label(
            current_tab,
            text="هذه مطابقة فورية فقط. المطابقة الرسمية تُحفظ عند إنهاء الوردية.",
            font=("Segoe UI",10)
        ).pack(anchor="e",pady=4)

        wrap=ttk.Frame(current_tab)
        wrap.pack(fill="both",expand=True)

        canvas=tk.Canvas(wrap,highlightthickness=0)
        sb=ttk.Scrollbar(wrap,orient="vertical",command=canvas.yview)
        inner=ttk.Frame(canvas)
        wid=canvas.create_window((0,0),window=inner,anchor="nw")
        inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",lambda e:canvas.itemconfigure(wid,width=e.width))
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left",fill="both",expand=True)
        sb.pack(side="right",fill="y")

        try:
            server_shift=self.server_current_shift()
            accounts=[(a["account_name"], float(a["system_balance_fils"])/1000.0) for a in server_shift.get("accounts",[])]
        except Exception:
            conn=get_db()
            accounts=conn.execute("""
                SELECT name,balance FROM accounts WHERE active=1 ORDER BY id
            """).fetchall()
            conn.close()

        entries={}
        hdr=ttk.Frame(inner); hdr.pack(fill="x",pady=4)
        for txt,w in [("الحساب",30),("رصيد النظام",20),("الرصيد الفعلي",20),("الفرق",20),("الحالة",15)]:
            ttk.Label(hdr,text=txt,width=w,font=("Segoe UI",10,"bold")).pack(side="right",padx=3)

        for name,balance in accounts:
            row=ttk.Frame(inner); row.pack(fill="x",pady=3)
            ttk.Label(row,text=name,width=30,anchor="e").pack(side="right",padx=3)
            ttk.Label(
                row,text=f"{float(balance):,.3f} JD",
                width=20,font=("Consolas",10)
            ).pack(side="right",padx=3)
            actual=ttk.Entry(row,width=20,justify="center",font=("Consolas",10))
            actual.insert(0,f"{float(balance):,.3f}")
            actual.pack(side="right",padx=3)
            diff=tk.Label(row,text="0.000 JD",width=20,bg="#e8f5e9",fg="#1b5e20")
            diff.pack(side="right",padx=3)
            status=tk.Label(row,text="✓ مطابق",width=15,bg="#c8e6c9",fg="#1b5e20")
            status.pack(side="right",padx=3)
            entries[name]=(float(balance),actual,diff,status)

        total=tk.Label(
            inner,text="",font=("Consolas",11,"bold"),
            bg="#c8e6c9",fg="#1b5e20",padx=8,pady=5
        )
        total.pack(pady=8)

        def calculate(_e=None):
            sys_total=0.0; actual_total=0.0; any_diff=False
            for name,(system,e,dlabel,slabel) in entries.items():
                try:
                    actual=self.parse_number(e.get())
                except ValueError:
                    messagebox.showerror(
                        "خطأ",f"الرصيد الفعلي غير صحيح للحساب: {name}"
                    )
                    return
                d=actual-system
                if abs(d)<=0.0005:
                    dlabel.config(text="0.000 JD",bg="#e8f5e9",fg="#1b5e20")
                    slabel.config(text="✓ مطابق",bg="#c8e6c9",fg="#1b5e20")
                else:
                    any_diff=True
                    dlabel.config(text=f"{d:+,.3f} JD",bg="#ffebee",fg="#b71c1c")
                    slabel.config(text="✗ غير مطابق",bg="#ffcdd2",fg="#b71c1c")
                sys_total+=system; actual_total+=actual

            d=actual_total-sys_total
            if any_diff:
                total.config(
                    text=f"غير مطابق | النظام {sys_total:,.3f} JD | "
                         f"الفعلي {actual_total:,.3f} JD | الفرق {d:+,.3f} JD",
                    bg="#ffcdd2",fg="#b71c1c"
                )
            else:
                total.config(
                    text=f"مطابق | النظام {sys_total:,.3f} JD | "
                         f"الفعلي {actual_total:,.3f} JD | الفرق 0.000 JD",
                    bg="#c8e6c9",fg="#1b5e20"
                )

        for _name,(_s,e,_d,_st) in entries.items():
            e.bind("<KeyRelease>",calculate)
        calculate()

        # ---- shift reconciliation history ----
        hf=ttk.Frame(history_tab)
        hf.pack(fill="both",expand=True)

        cols=("shift","business_date","start","end","program","actual","difference","status")
        shifts_tree=ttk.Treeview(hf,columns=cols,show="headings")
        defs=[
            ("shift","الوردية",80),("business_date","تاريخ العمل",110),
            ("start","البداية",155),("end","النهاية",155),
            ("program","رصيد البرنامج",145),("actual","الرصيد الفعلي",145),
            ("difference","الفرق",125),("status","الحالة",110)
        ]
        for c,h,w in defs:
            shifts_tree.heading(c,text=h)
            shifts_tree.column(c,width=w,minwidth=70,anchor="center",stretch=False)
        hvs=ttk.Scrollbar(hf,orient="vertical",command=shifts_tree.yview)
        hhs=ttk.Scrollbar(hf,orient="horizontal",command=shifts_tree.xview)
        shifts_tree.configure(yscrollcommand=hvs.set,xscrollcommand=hhs.set)
        shifts_tree.grid(row=0,column=0,sticky="nsew")
        hvs.grid(row=0,column=1,sticky="ns")
        hhs.grid(row=1,column=0,sticky="ew")
        hf.rowconfigure(0,weight=1); hf.columnconfigure(0,weight=1)

        history_from_server=False
        try:
            history=self.server_request("GET","/api/v1/shifts?limit=500",timeout=8.0)
            history_from_server=True
            for r in history:
                diff=float(r.get("difference_fils",0))/1000.0
                matched=abs(diff)<=0.0005
                shifts_tree.insert("", "end", values=(
                    r.get("id"),r.get("business_date") or "",
                    self.to_english_digits(str(r.get("started_at") or "").replace("T"," ")[:19]),
                    self.to_english_digits(str(r.get("ended_at") or "").replace("T"," ")[:19]),
                    f"{float(r.get('program_total_fils',0))/1000.0:,.3f} JD",
                    f"{float(r.get('actual_total_fils',0))/1000.0:,.3f} JD",
                    f"{diff:+,.3f} JD","✓ مطابق" if matched else "✗ غير مطابق"
                ))
        except Exception:
            conn=get_db()
            history=conn.execute("""
                SELECT id,business_date,started_at,ended_at,
                       program_total,actual_total,difference
                FROM shifts
                WHERE status='closed'
                ORDER BY id DESC
            """).fetchall()
            conn.close()
            for r in history:
                matched=abs(float(r[6]))<=0.0005
                shifts_tree.insert("", "end", values=(
                    r[0],r[1] or "",self.to_english_digits(r[2]),
                    self.to_english_digits(r[3] or ""),
                    f"{float(r[4]):,.3f} JD",f"{float(r[5]):,.3f} JD",
                    f"{float(r[6]):+,.3f} JD",
                    "✓ مطابق" if matched else "✗ غير مطابق"
                ))

        ttk.Button(
            history_tab,text="🔎 عرض تفاصيل الوردية المحددة",
            command=lambda:self.show_shift_reconciliation_details(shifts_tree)
        ).pack(anchor="e",pady=6)

    def show_shift_reconciliation_details(self, tree):
        sel=tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه","اختر وردية من السجل")
            return
        shift_id=int(tree.item(sel[0])["values"][0])

        shift=None; rows=[]
        try:
            server_history=self.server_request("GET","/api/v1/shifts?limit=500",timeout=8.0)
            sr=next((x for x in server_history if int(x.get("id",-1))==shift_id),None)
            if sr:
                shift=(
                    sr.get("business_date") or "",
                    str(sr.get("started_at") or "").replace("T"," ")[:19],
                    str(sr.get("ended_at") or "").replace("T"," ")[:19],
                    float(sr.get("program_total_fils",0))/1000.0,
                    float(sr.get("actual_total_fils",0))/1000.0,
                    float(sr.get("difference_fils",0))/1000.0,
                )
                rows=[(
                    b.get("account_name") or "",
                    float(b.get("system_balance_fils",0))/1000.0,
                    float(b.get("actual_balance_fils",0))/1000.0,
                    float(b.get("difference_fils",0))/1000.0,
                    b.get("reason") or "",
                ) for b in sr.get("balances",[])]
        except Exception:
            pass
        if shift is None:
            conn=get_db()
            shift=conn.execute("""
                SELECT business_date,started_at,ended_at,program_total,actual_total,difference
                FROM shifts WHERE id=?
            """,(shift_id,)).fetchone()
            rows=conn.execute("""
                SELECT sb.account_name,sb.system_balance,sb.actual_balance,sb.difference,
                       COALESCE(r.reason,'')
                FROM shift_balances sb
                LEFT JOIN shift_difference_reasons r
                  ON r.shift_id=sb.shift_id AND r.account_name=sb.account_name
                WHERE sb.shift_id=?
                ORDER BY sb.id
            """,(shift_id,)).fetchall()
            conn.close()

        win=tk.Toplevel(self.root)
        win.title(f"تفاصيل مطابقة الوردية #{shift_id}")
        win.geometry("900x620"); win.minsize(700,450)

        main=ttk.Frame(win,padding=10); main.pack(fill="both",expand=True)
        ttk.Label(main,text=f"مطابقة الوردية #{shift_id}",font=("Segoe UI",16,"bold")).pack(anchor="e")
        if shift:
            matched=abs(float(shift[5]))<=0.0005
            status=tk.Label(
                main,
                text=("✓ مطابق" if matched else "✗ غير مطابق") +
                     f"\nتاريخ العمل: {shift[0]}\nالفرق: {float(shift[5]):+,.3f} JD",
                bg="#c8e6c9" if matched else "#ffcdd2",
                fg="#1b5e20" if matched else "#b71c1c",
                font=("Segoe UI",10,"bold"),padx=8,pady=5
            )
            status.pack(fill="x",pady=5)

        frame=ttk.Frame(main); frame.pack(fill="both",expand=True)
        cols=("account","system","actual","diff","status","reason")
        tv=ttk.Treeview(frame,columns=cols,show="headings")
        defs=[
            ("account","الحساب",220),("system","رصيد البرنامج",150),
            ("actual","الرصيد الفعلي",150),("diff","الفرق",130),
            ("status","الحالة",110),("reason","السبب",260)
        ]
        for c,h,w in defs:
            tv.heading(c,text=h)
            tv.column(c,width=w,minwidth=70,anchor="center",stretch=(c=="reason"))
        vs=ttk.Scrollbar(frame,orient="vertical",command=tv.yview)
        hs=ttk.Scrollbar(frame,orient="horizontal",command=tv.xview)
        tv.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tv.grid(row=0,column=0,sticky="nsew")
        vs.grid(row=0,column=1,sticky="ns")
        hs.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

        for r in rows:
            matched=abs(float(r[3]))<=0.0005
            tv.insert("", "end", values=(
                r[0],f"{float(r[1]):,.3f} JD",f"{float(r[2]):,.3f} JD",
                f"{float(r[3]):+,.3f} JD","✓ مطابق" if matched else "✗ غير مطابق",
                r[4] or ""
            ))

    def show_today_report(self):
        self.report_window(False)

    def show_end_shift(self):
        self.report_window(True)

    def report_window(self, end_shift=False):
        if end_shift and not self.require_permission("end_shift","إنهاء الوردية"):
            return
        if not end_shift and not self.require_permission("reports","كشف الوردية"):
            return

        conn=get_db()
        shift=conn.execute("""
            SELECT id,started_at,business_date FROM shifts
            WHERE status='open' ORDER BY id DESC LIMIT 1
        """).fetchone()
        if not shift:
            conn.close()
            messagebox.showerror("خطأ","لا توجد وردية مفتوحة")
            return

        shift_id,start,business_date=shift
        business_date=business_date or start[:10]
        now_text=datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        rows=conn.execute("""
            SELECT id,created_at,op_type,source_account,destination_account,
                   amount,commission,commission_account,customer_name,
                   details,performed_by,status
            FROM transactions
            WHERE shift_id=?
               OR (shift_id IS NULL AND created_at>=? AND created_at<=?)
            ORDER BY datetime(created_at),id
        """,(shift_id,start,now_text)).fetchall()

        accounts=conn.execute("""
            SELECT name,balance FROM accounts
            WHERE active=1 ORDER BY id
        """).fetchall()

        total_comm=conn.execute("""
            SELECT COALESCE(SUM(commission),0)
            FROM transactions
            WHERE shift_id=? AND status='active'
        """,(shift_id,)).fetchone()[0]
        conn.close()

        total_bal=sum(float(b) for _,b in accounts)
        shift_business_count=0
        shift_business_amount=0.0
        shift_correction_count=0
        try:
            _srv_shift=self.server_current_shift()
            _srv_accounts=[(a["account_name"], float(a["system_balance_fils"])/1000.0) for a in _srv_shift.get("accounts",[])]
            if _srv_accounts:
                accounts=_srv_accounts
                total_bal=float(_srv_shift.get("program_total_fils",0))/1000.0
                total_comm=float(_srv_shift.get("total_commission_fils",0))/1000.0
                try:
                    _shift_summary=self.server_request("GET",f"/api/v1/shifts/{int(_srv_shift.get('id',shift_id))}/operations-summary",timeout=1.0)
                    shift_business_count=int(_shift_summary.get("business_count",0))
                    shift_business_amount=float(_shift_summary.get("business_amount_fils",0))/1000.0
                    shift_correction_count=int(_shift_summary.get("correction_count",0))
                except Exception:
                    pass
        except Exception:
            pass

        if shift_business_count==0 and rows:
            accounting_only={"تسوية رصيد","رصيد افتتاحي","مطابقة وردية"}
            for _r in rows:
                if _r[11] != "active":
                    continue
                _op=str(_r[2] or "")
                if _op in accounting_only:
                    continue
                if _op.startswith("عكس:"):
                    shift_correction_count += 1
                    continue
                shift_business_count += 1
                shift_business_amount += float(_r[5] or 0)

        win=tk.Toplevel(self.root)
        win.title("نهاية الوردية" if end_shift else "كشف الوردية")

        sw=win.winfo_screenwidth()
        sh=win.winfo_screenheight()
        w=max(760,min(1320,sw-90))
        h=max(520,min(820,sh-140))
        x=max(10,(sw-w)//2)
        y=max(10,(sh-h)//2-10)
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.minsize(760,520)
        win.resizable(True,True)
        win.grid_rowconfigure(0,weight=1)
        win.grid_columnconfigure(0,weight=1)

        outer=tk.Frame(win,bg="#F5F7FB")
        outer.grid(row=0,column=0,sticky="nsew")
        outer.grid_rowconfigure(0,weight=1)
        outer.grid_columnconfigure(0,weight=1)

        page=tk.Canvas(outer,bg="#F5F7FB",highlightthickness=0)
        page_scroll=ttk.Scrollbar(outer,orient="vertical",command=page.yview)
        page.configure(yscrollcommand=page_scroll.set)
        page.grid(row=0,column=0,sticky="nsew")
        page_scroll.grid(row=0,column=1,sticky="ns")

        main=ttk.Frame(page,padding=10)
        page_window=page.create_window((0,0),window=main,anchor="nw")
        main.bind("<Configure>",lambda e:page.configure(scrollregion=page.bbox("all")))
        page.bind("<Configure>",lambda e:page.itemconfigure(page_window,width=e.width))

        ttk.Label(
            main,
            text="🔴 نهاية الوردية - كشف كامل" if end_shift else "📋 كشف الوردية حتى الآن",
            font=("Segoe UI",18,"bold")
        ).pack(pady=(2,8))

        stats=ttk.Frame(main)
        stats.pack(fill="x",pady=4)
        for label,value in [
            ("رقم الوردية",str(shift_id)),
            ("تاريخ عمل الوردية",business_date),
            ("بداية الوردية",self.to_english_digits(start)),
            ("مجموع الأرصدة",f"{total_bal:,.3f} JD"),
            ("العمولات",f"{float(total_comm):,.3f} JD"),
            ("عدد العمليات",str(shift_business_count)),
            ("حجم العمليات",f"{shift_business_amount:,.3f} JD")
        ]:
            box=ttk.LabelFrame(stats,text=label,padding=5)
            box.pack(side="right",padx=3,fill="x",expand=True)
            ttk.Label(box,text=value,font=("Consolas",9,"bold")).pack()

        trans_box=ttk.LabelFrame(main,text="💸 عمليات الوردية",padding=5)
        trans_box.pack(fill="x",pady=6)

        tf=ttk.Frame(trans_box)
        tf.pack(fill="x")
        cols=("n","time","op","from","to","amount","comm","customer","details","status")
        tree=ttk.Treeview(tf,columns=cols,show="headings",height=10)
        for c,hdr,width in [
            ("n","#",55),("time","التاريخ والوقت",155),("op","العملية",125),
            ("from","من",130),("to","إلى",130),("amount","المبلغ",110),
            ("comm","العمولة",100),("customer","العميل",120),
            ("details","التفاصيل",230),("status","الحالة",90)
        ]:
            tree.heading(c,text=hdr)
            tree.column(c,width=width,minwidth=65,anchor="center",stretch=(c=="details"))
        tvs=ttk.Scrollbar(tf,orient="vertical",command=tree.yview)
        ths=ttk.Scrollbar(tf,orient="horizontal",command=tree.xview)
        tree.configure(yscrollcommand=tvs.set,xscrollcommand=ths.set)
        tree.grid(row=0,column=0,sticky="nsew")
        tvs.grid(row=0,column=1,sticky="ns")
        ths.grid(row=1,column=0,sticky="ew")
        tf.grid_columnconfigure(0,weight=1)

        for i,r in enumerate(rows,1):
            tree.insert("", "end", values=(
                i,self.to_english_digits(r[1]),
                ("تعديل رصيد يدوي" if r[2]=="تسوية رصيد" else r[2]),
                r[3] or "",r[4] or "",
                f"{float(r[5]):,.3f} JD",f"{float(r[6]):,.3f} JD",
                r[8] or "",r[9] or "",
                "فعال" if r[11]=="active" else ("معدل" if r[11]=="modified" else "ملغي")
            ))

        reconcile_box=ttk.LabelFrame(
            main,
            text="⚖️ مطابقة أرصدة الوردية" if end_shift else "🏦 أرصدة الحسابات",
            padding=7
        )
        reconcile_box.pack(fill="x",pady=(6,12))

        def wheel(event):
            target=win.winfo_containing(event.x_root,event.y_root)
            wdg=target
            while wdg:
                if isinstance(wdg,ttk.Treeview):
                    wdg.yview_scroll(-3 if event.delta>0 else 3,"units")
                    return "break"
                try:
                    pn=wdg.winfo_parent()
                    if not pn: break
                    wdg=wdg._nametowidget(pn)
                except Exception:
                    break
            page.yview_scroll(-3 if event.delta>0 else 3,"units")
            return "break"

        win.bind("<MouseWheel>",wheel,add="+")

        if not end_shift:
            af=ttk.Frame(reconcile_box)
            af.pack(fill="x")
            atree=ttk.Treeview(af,columns=("account","balance"),show="headings",height=8)
            atree.heading("account",text="الحساب")
            atree.heading("balance",text="الرصيد")
            atree.column("account",width=450,anchor="center",stretch=True)
            atree.column("balance",width=190,anchor="center")
            avs=ttk.Scrollbar(af,orient="vertical",command=atree.yview)
            atree.configure(yscrollcommand=avs.set)
            atree.grid(row=0,column=0,sticky="nsew")
            avs.grid(row=0,column=1,sticky="ns")
            af.grid_columnconfigure(0,weight=1)
            for name,bal in accounts:
                atree.insert("", "end",values=(name,f"{float(bal):,.3f} JD"))

            footer=tk.Frame(win,bg="#FFFFFF",highlightbackground="#DDE4EF",highlightthickness=1)
            footer.grid(row=1,column=0,sticky="ew")
            tk.Button(
                footer,text="إغلاق",command=win.destroy,
                bg="#475467",fg="white",relief="flat",
                padx=20,pady=8
            ).pack(side="right",padx=12,pady=8)
            return

        reasons={}
        entries=[]

        header=ttk.Frame(reconcile_box)
        header.pack(fill="x",pady=3)
        for label,width in [
            ("الحساب",28),("رصيد البرنامج",18),("الرصيد الفعلي",18),
            ("الفرق",16),("الحالة",14),("السبب",12)
        ]:
            ttk.Label(
                header,text=label,width=width,
                font=("Segoe UI",9,"bold")
            ).pack(side="right",padx=2)

        def edit_reason(account):
            dialog=tk.Toplevel(win)
            dialog.title(f"سبب فرق الرصيد - {account}")
            dialog.geometry("520x250")
            f=ttk.Frame(dialog,padding=18)
            f.pack(fill="both",expand=True)
            ttk.Label(f,text=f"الحساب: {account}",font=("Segoe UI",11,"bold")).pack(anchor="e")
            ttk.Label(f,text="سبب الفرق / الملاحظة").pack(anchor="e",pady=(10,3))
            e=ttk.Entry(f,justify="right")
            self.setup_entry(e,select_all_on_focus=False)
            e.insert(0,reasons.get(account,""))
            e.pack(fill="x",pady=5)
            def save_reason():
                reasons[account]=e.get().strip()
                dialog.destroy()
            e.bind("<Return>",lambda _e:save_reason())
            ttk.Button(f,text="💾 حفظ السبب",command=save_reason).pack(pady=12)

        for name,system_bal in accounts:
            rowf=ttk.Frame(reconcile_box)
            rowf.pack(fill="x",pady=3)

            ttk.Label(rowf,text=name,width=28,anchor="e").pack(side="right",padx=2)
            ttk.Label(
                rowf,text=f"{float(system_bal):,.3f} JD",
                width=18,font=("Consolas",10)
            ).pack(side="right",padx=2)

            actual=ttk.Entry(rowf,justify="center",width=18,font=("Consolas",10))
            self.setup_entry(actual)
            actual.insert(0,f"{float(system_bal):,.3f}")
            actual.pack(side="right",padx=2)

            diff=tk.Label(
                rowf,text="0.000 JD",width=16,
                font=("Consolas",10),bg="#E8F5E9",fg="#1B5E20"
            )
            diff.pack(side="right",padx=2)

            status=tk.Label(
                rowf,text="✓ مطابق",width=14,
                font=("Segoe UI",9,"bold"),bg="#C8E6C9",fg="#1B5E20"
            )
            status.pack(side="right",padx=2)

            ttk.Button(
                rowf,text="📝 السبب",width=12,
                command=lambda acc=name:edit_reason(acc)
            ).pack(side="right",padx=2)

            entries.append((name,float(system_bal),actual,diff,status))

        totals=ttk.Frame(reconcile_box)
        totals.pack(fill="x",pady=10)
        ttk.Label(
            totals,text=f"مجموع رصيد البرنامج: {total_bal:,.3f} JD",
            font=("Consolas",11,"bold")
        ).pack(side="right",padx=10)

        actual_total_lbl=ttk.Label(
            totals,text=f"مجموع الرصيد الفعلي: {total_bal:,.3f} JD",
            font=("Consolas",11,"bold")
        )
        actual_total_lbl.pack(side="right",padx=10)

        risk_line=ttk.Frame(reconcile_box)
        risk_line.pack(fill="x",pady=(0,6))
        mismatch_count_lbl=ttk.Label(risk_line,text="الحسابات غير المطابقة: 0",font=("Segoe UI",9,"bold"))
        mismatch_count_lbl.pack(side="right",padx=8)
        max_diff_lbl=ttk.Label(risk_line,text="أكبر فرق: 0.000 JD",font=("Consolas",9,"bold"))
        max_diff_lbl.pack(side="right",padx=8)
        if shift_correction_count:
            ttk.Label(risk_line,text=f"عمليات عكس/تصحيح: {shift_correction_count}",font=("Segoe UI",9,"bold")).pack(side="right",padx=8)

        overall=tk.Label(
            reconcile_box,text="✓ الوردية مطابقة",
            font=("Segoe UI",12,"bold"),
            bg="#C8E6C9",fg="#1B5E20",padx=12,pady=7
        )
        overall.pack(fill="x",pady=(2,8))

        def calculate(_e=None):
            total_actual=0.0
            any_diff=False
            mismatch_count=0
            max_abs_diff=0.0
            for name,system_bal,entry,dlabel,slabel in entries:
                try:
                    actual=self.parse_number(entry.get())
                except ValueError:
                    return None
                d=actual-system_bal
                total_actual+=actual
                if abs(d)<=0.0005:
                    dlabel.config(text="0.000 JD",bg="#E8F5E9",fg="#1B5E20")
                    slabel.config(text="✓ مطابق",bg="#C8E6C9",fg="#1B5E20")
                else:
                    any_diff=True
                    mismatch_count+=1
                    max_abs_diff=max(max_abs_diff,abs(d))
                    dlabel.config(text=f"{d:+,.3f} JD",bg="#FFEBEE",fg="#B71C1C")
                    slabel.config(text="✗ غير مطابق",bg="#FFCDD2",fg="#B71C1C")
            difference=total_actual-total_bal
            actual_total_lbl.config(text=f"مجموع الرصيد الفعلي: {total_actual:,.3f} JD")
            mismatch_count_lbl.config(text=f"الحسابات غير المطابقة: {mismatch_count}")
            max_diff_lbl.config(text=f"أكبر فرق: {max_abs_diff:,.3f} JD")
            overall.config(
                text=(f"✗ الوردية غير مطابقة\nالفرق الكلي: {difference:+,.3f} JD"
                      if any_diff else "✓ الوردية مطابقة\nالفرق الكلي: 0.000 JD"),
                bg="#FFCDD2" if any_diff else "#C8E6C9",
                fg="#B71C1C" if any_diff else "#1B5E20"
            )
            return total_actual,difference

        for _n,_s,e,_d,_st in entries:
            e.bind("<KeyRelease>",calculate,add="+")
        calculate()

        def finish_shift():
            parsed=[]
            total_actual=0.0
            for name,system_bal,e,_d,_s in entries:
                try:
                    actual=self.parse_number(e.get())
                except ValueError:
                    messagebox.showerror("خطأ",f"الرصيد الفعلي غير صحيح للحساب: {name}",parent=win)
                    return
                diff=actual-system_bal
                reason=reasons.get(name,"").strip()
                if abs(diff)>0.0005 and not reason:
                    messagebox.showwarning(
                        "سبب مطلوب",
                        f"الحساب {name} غير مطابق.\nاضغط زر السبب واكتب سبب الفرق.",
                        parent=win
                    )
                    return
                parsed.append((name,system_bal,actual,diff,reason))
                total_actual+=actual

            total_difference=total_actual-total_bal
            status_text="مطابقة" if all(abs(p[3])<=0.0005 for p in parsed) else "غير مطابقة"

            if not messagebox.askyesno(
                "تأكيد نهاية الوردية",
                f"رقم الوردية: {shift_id}\n"
                f"تاريخ العمل: {business_date}\n"
                f"رصيد البرنامج: {total_bal:,.3f} JD\n"
                f"الرصيد الفعلي: {total_actual:,.3f} JD\n"
                f"الفرق: {total_difference:+,.3f} JD\n"
                f"الحالة: {status_text}\n\n"
                "هل تريد حفظ المطابقة وإنهاء الوردية؟",
                parent=win
            ):
                return

            # Validate the local mirror before closing the authoritative server shift.
            pre_conn=get_db()
            current_status=pre_conn.execute(
                "SELECT status FROM shifts WHERE id=?",(shift_id,)
            ).fetchone()
            pre_conn.close()
            if not current_status or current_status[0]!="open":
                messagebox.showwarning("تنبيه","تم إنهاء هذه الوردية مسبقاً.",parent=win)
                return

            server_result=self.server_close_shift(parsed,parent=win)
            if not server_result:
                return

            conn=get_db()
            cur=conn.cursor()
            close_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            for name,system_bal,actual,diff,reason in parsed:
                cur.execute("""
                    INSERT INTO shift_balances(
                        shift_id,account_name,system_balance,actual_balance,difference
                    ) VALUES(?,?,?,?,?)
                """,(shift_id,name,system_bal,actual,diff))
                if reason:
                    cur.execute("""
                        INSERT INTO shift_difference_reasons(
                            shift_id,account_name,reason
                        ) VALUES(?,?,?)
                    """,(shift_id,name,reason))

                detail=(
                    f"مطابقة نهاية الوردية #{shift_id} | تاريخ العمل {business_date} | "
                    f"رصيد البرنامج {system_bal:,.3f} JD | الرصيد الفعلي {actual:,.3f} JD | "
                    f"الفرق {diff:+,.3f} JD | "
                    f"الحالة {'مطابق' if abs(diff)<=0.0005 else 'غير مطابق'}"
                )
                if reason:
                    detail += f" | السبب: {reason}"

                cur.execute("""
                    INSERT INTO transactions(
                        created_at,op_type,source_account,destination_account,
                        amount,commission,commission_account,details,
                        performed_by,status,shift_id
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,(close_time,"مطابقة وردية","",name,0,0,"",detail,
                     self.username,"active",shift_id))

            cur.execute("""
                UPDATE shifts
                SET ended_at=?,status='closed',total_commission=?,
                    program_total=?,actual_total=?,difference=?,business_date=?
                WHERE id=?
            """,(close_time,float(total_comm),total_bal,total_actual,
                 total_difference,business_date,shift_id))

            cur.execute("""
                INSERT INTO shifts(started_at,status,business_date)
                VALUES(?,'open',?)
            """,(close_time,close_time[:10]))

            conn.commit()
            conn.close()

            self.log(
                "إنهاء وردية",
                f"#{shift_id} | {business_date} | {status_text} | الفرق {total_difference:+.3f} JD"
            )
            if self.get_setting("auto_backup_shift","0")=="1":
                self.backup_database(silent=True)

            messagebox.showinfo(
                "تم",
                f"تم إنهاء الوردية #{shift_id} بنجاح.\n"
                f"الحالة: {status_text}\nالفرق: {total_difference:+,.3f} JD",
                parent=win
            )
            win.destroy()
            self.show_dashboard()

        footer=tk.Frame(
            win,bg="#FFFFFF",
            highlightbackground="#DDE4EF",highlightthickness=1,
            height=64
        )
        footer.grid(row=1,column=0,sticky="ew")
        footer.grid_propagate(False)

        tk.Button(
            footer,text="✅ حفظ المطابقة وإنهاء الوردية",
            command=finish_shift,
            bg="#16A34A",fg="white",
            activebackground="#15803D",activeforeground="white",
            relief="flat",font=("Segoe UI",11,"bold"),
            padx=24,pady=9,cursor="hand2"
        ).pack(side="right",padx=12,pady=10)

        if self.has_permission("share"):
            report_text=self.build_shift_share_text(
                shift_id,business_date,start,rows,accounts,total_comm
            )
            tk.Button(
                footer,text="📄 PDF / طباعة / مشاركة",
                command=lambda:self.report_actions_window(
                    f"تقرير الوردية #{shift_id}", report_text
                ),
                bg="#EEF4FF",fg="#1D4ED8",relief="flat",
                padx=12,pady=8
            ).pack(side="left",padx=5,pady=10)

        self.enable_edit_shortcuts_recursive(main)

    def finish_shift_window(self, parent, shift_id, accounts, total_comm, total_bal):
        messagebox.showinfo(
            "معلومة",
            "تم نقل الرصيد الفعلي والمطابقة إلى نافذة نهاية الوردية نفسها.",
            parent=parent
        )

    def run_system_diagnostics(self):
        """Read-only final health check. It never changes balances or transactions."""
        checks=[]
        ok_all=True
        try:
            ok, api_ver, runtime_ver=self.check_server_health()
            detail=(f"API {api_ver} | Runtime {runtime_ver}" if ok else "غير متصل")
            checks.append(("اتصال السيرفر", ok, detail))
            if ok:
                version_ok = (api_ver == API_COMPAT_VERSION and runtime_ver == RUNTIME_VERSION)
                checks.append(("تطابق الإصدارات", version_ok,
                               f"Windows {APP_VERSION} | API {api_ver} | Runtime {runtime_ver}"))
                ok_all = ok_all and version_ok
            ok_all = ok_all and ok
        except Exception as exc:
            checks.append(("اتصال السيرفر", False, str(exc)))
            ok_all=False
        try:
            conn=get_db()
            integrity=conn.execute("PRAGMA integrity_check").fetchone()[0]
            checks.append(("سلامة قاعدة Windows", integrity=="ok", str(integrity)))
            open_shift=conn.execute("SELECT id FROM shifts WHERE status='open' ORDER BY id DESC LIMIT 1").fetchone()
            checks.append(("الوردية المحلية المفتوحة", bool(open_shift), f"#{open_shift[0]}" if open_shift else "لا توجد"))
            conn.close()
            ok_all = ok_all and integrity=="ok" and bool(open_shift)
        except Exception as exc:
            checks.append(("قاعدة Windows", False, str(exc))); ok_all=False
        try:
            accounts=self.server_request("GET","/api/v1/accounts",timeout=6.0)
            checks.append(("حسابات السيرفر", len(accounts)>0, f"{len(accounts)} حساب"))
            ok_all = ok_all and len(accounts)>0
        except Exception as exc:
            checks.append(("حسابات السيرفر", False, str(exc))); ok_all=False
        lines=[]
        for name,ok,details in checks:
            lines.append(("✓" if ok else "✗")+"  "+name+" — "+details)
        title="فحص سلامة النظام: ناجح" if ok_all else "فحص سلامة النظام: يحتاج مراجعة"
        (messagebox.showinfo if ok_all else messagebox.showwarning)(title, "\n".join(lines), parent=self.root)

    def show_settings(self):
        if not self.require_permission("settings","الإعدادات"):
            return
        self.clear_content()

        ttk.Label(
            self.content,text="⚙️ الإعدادات",
            font=("Segoe UI",20,"bold")
        ).pack(anchor="e",pady=10)

        # كامل صفحة الإعدادات تتحرك بواسطة Scroll الصفحة الرئيسية.
        inner=ttk.Frame(self.content,padding=5)
        inner.pack(fill="x",expand=False)

        update_box=ttk.LabelFrame(inner,text="🔄 تحديثات النظام",padding=12)
        update_box.pack(fill="x",pady=6)
        update_status=ttk.Label(update_box,text=f"الإصدار الحالي: {APP_VERSION}  |  قناة التحديث: {UPDATE_CHANNEL}",font=("Segoe UI",9,"bold"))
        update_status.pack(side="right",padx=6)
        CURRENT_APP_VERSION=APP_VERSION

        def check_update_architecture():
            try:
                info=self.server_request("GET","/api/v1/system/update-info",timeout=1.5)
                messagebox.showinfo("تحديثات النظام",
                    "نظام التحديث الآمن جاهز.\n\n"
                    f"إصدار البرنامج: {CURRENT_APP_VERSION}\n"
                    f"إصدار API المتوافق: {info.get('api_version','-')}\n"
                    f"إصدار Runtime: {info.get('runtime_version','-')}\n"
                    f"إصدار قاعدة البيانات: {info.get('schema_version','-')}\n"
                    "يدعم: SHA-256، نسخة احتياطية، تحديث خارجي للـ EXE، إعادة التشغيل، والرجوع عند الفشل.")
            except Exception as exc:
                messagebox.showwarning("تحديثات النظام",
                    "البرنامج نفسه جاهز للتحديث، لكن تعذر قراءة معلومات API الآن.\n"
                    f"{exc}", parent=self.root)

        def _import_updaters():
            import sys
            app_root=os.path.dirname(os.path.dirname(__file__))
            if app_root not in sys.path:
                sys.path.insert(0, app_root)
            from update_engine_v2 import inspect_package, launch_update
            return inspect_package, launch_update

        def select_update_package():
            package=filedialog.askopenfilename(
                title="اختر حزمة تحديث MoneyTransfer",
                filetypes=[("MoneyTransfer Update ZIP","*.zip"),("ZIP","*.zip")],
                parent=self.root)
            if not package:
                return
            try:
                inspect_package, launch_update=_import_updaters()
                meta=inspect_package(package)
                try:
                    from online_update import is_newer
                    if not is_newer(meta.get("version", "0"), CURRENT_APP_VERSION):
                        raise ValueError(f"تم رفض الحزمة: الإصدار {meta.get('version','-')} ليس أحدث من الإصدار الحالي {CURRENT_APP_VERSION}.")
                except ImportError:
                    pass
                notes="\n".join("• "+str(x) for x in meta.get("notes_ar",[])) or "لا توجد ملاحظات."
                if not messagebox.askyesno("تأكيد التحديث",
                    f"الإصدار الحالي: {CURRENT_APP_VERSION}\nالإصدار داخل الحزمة: {meta.get('version','-')}\n"
                    f"إصدار قاعدة البيانات: {meta.get('schema_version','-')}\n\n{notes}\n\n"
                    "سيأخذ البرنامج نسخة احتياطية ثم يغلق نفسه ويطبق التحديث ويعيد التشغيل تلقائياً. هل تريد المتابعة؟", parent=self.root):
                    return
                launch_update(package)
                messagebox.showinfo("جاري تثبيت التحديث",
                    "تم التحقق من الحزمة وأخذ النسخة الاحتياطية.\n\n"
                    "سيغلق البرنامج الآن، ثم يثبت التحديث ويعيد التشغيل تلقائياً.", parent=self.root)
                self.root.after(350, self.root.destroy)
            except Exception as exc:
                messagebox.showerror("حزمة تحديث غير صالحة",str(exc),parent=self.root)

        def configure_online_update_source():
            try:
                import sys
                app_root=os.path.dirname(os.path.dirname(__file__))
                if app_root not in sys.path:
                    sys.path.insert(0, app_root)
                from online_update import load_config, save_config
                cfg=load_config()
                value=simpledialog.askstring(
                    "مصدر التحديث عبر الإنترنت",
                    "أدخل رابط ملف التحديث الآمن (HTTPS).\n\nمثال: https://example.com/moneytransfer/stable.json",
                    initialvalue=cfg.get("feed_url", ""), parent=self.root)
                if value is None:
                    return
                value=value.strip()
                if value and not value.lower().startswith("https://"):
                    messagebox.showerror("رابط غير آمن","يجب أن يبدأ الرابط بـ https://",parent=self.root)
                    return
                save_config(value, "Stable")
                messagebox.showinfo("تم","تم حفظ مصدر التحديث على هذا الجهاز.",parent=self.root)
            except Exception as exc:
                messagebox.showerror("مصدر التحديث",str(exc),parent=self.root)

        def check_online_update():
            try:
                import sys
                app_root=os.path.dirname(os.path.dirname(__file__))
                if app_root not in sys.path:
                    sys.path.insert(0, app_root)
                from online_update import load_config, save_config, check_update, download_package
                inspect_package, launch_update=_import_updaters()
                cfg=load_config()
                feed_url=cfg.get("feed_url", "").strip()
                if not feed_url:
                    feed_url=simpledialog.askstring(
                        "التحديث عبر الإنترنت",
                        "لم يتم تحديد مصدر التحديث بعد.\nأدخل رابط HTTPS لملف التحديث:",
                        parent=self.root)
                    if not feed_url:
                        return
                    feed_url=feed_url.strip()
                    if not feed_url.lower().startswith("https://"):
                        messagebox.showerror("رابط غير آمن","يجب أن يبدأ الرابط بـ https://",parent=self.root)
                        return
                    save_config(feed_url, "Stable")
            except Exception as exc:
                messagebox.showerror("التحديث عبر الإنترنت",str(exc),parent=self.root)
                return

            wait=tk.Toplevel(self.root)
            wait.title("التحديث عبر الإنترنت")
            wait.transient(self.root)
            wait.resizable(False,False)
            ttk.Label(wait,text="جارٍ البحث عن تحديث جديد...",padding=20,font=("Segoe UI",10,"bold")).pack()
            wait.update_idletasks()
            try:
                wait.grab_set()
            except Exception:
                pass

            def finish_check(result=None, error=None):
                try:
                    wait.grab_release()
                except Exception:
                    pass
                try:
                    wait.destroy()
                except Exception:
                    pass
                if error:
                    messagebox.showerror("التحديث عبر الإنترنت",f"تعذر فحص التحديث.\n\n{error}",parent=self.root)
                    return
                if not result.get("available"):
                    remote=result.get("feed",{}).get("version", CURRENT_APP_VERSION)
                    messagebox.showinfo("التحديث عبر الإنترنت",
                        f"أنت تستخدم أحدث إصدار متاح.\n\nالإصدار الحالي: {CURRENT_APP_VERSION}\nالإصدار على الخادم: {remote}",
                        parent=self.root)
                    return
                feed=result["feed"]
                notes="\n".join("• "+str(x) for x in feed.get("notes_ar",[])) or "لا توجد ملاحظات للإصدار."
                if not messagebox.askyesno("يتوفر تحديث جديد",
                    f"الإصدار الحالي: {CURRENT_APP_VERSION}\nالإصدار الجديد: {feed.get('version','-')}\n\n{notes}\n\n"
                    "هل تريد تنزيله والتحقق منه وتثبيته الآن؟",parent=self.root):
                    return

                prog=tk.Toplevel(self.root)
                prog.title("تنزيل التحديث")
                prog.transient(self.root)
                prog.resizable(False,False)
                label=ttk.Label(prog,text="جارٍ تنزيل حزمة التحديث...",padding=20,font=("Segoe UI",10,"bold"))
                label.pack()
                try:
                    prog.grab_set()
                except Exception:
                    pass

                def progress(done,total):
                    def ui():
                        if total:
                            pct=min(100,int(done*100/total))
                            label.config(text=f"جارٍ تنزيل حزمة التحديث... {pct}%")
                        else:
                            label.config(text=f"جارٍ تنزيل حزمة التحديث... {done/1024/1024:.1f} MB")
                    self.root.after(0,ui)

                def download_worker():
                    try:
                        package=download_package(feed,progress=progress)
                        meta=inspect_package(package)
                        if str(meta.get("version")) != str(feed.get("version")):
                            raise ValueError("رقم إصدار الحزمة لا يطابق معلومات التحديث على الخادم.")
                        launch_update(package)
                        self.root.after(0,lambda: download_done(feed,None))
                    except Exception as exc:
                        self.root.after(0,lambda e=str(exc): download_done(feed,e))

                def download_done(feed,error):
                    try:
                        prog.grab_release()
                    except Exception:
                        pass
                    try:
                        prog.destroy()
                    except Exception:
                        pass
                    if error:
                        messagebox.showerror("فشل التحديث",error,parent=self.root)
                        return
                    messagebox.showinfo("تم تنزيل التحديث",
                        f"تم تنزيل وفحص إصدار {feed.get('version','-')} بنجاح.\n"
                        "سيغلق البرنامج الآن ويثبت التحديث ثم يعيد التشغيل تلقائياً.",parent=self.root)
                    self.root.after(350,self.root.destroy)

                threading.Thread(target=download_worker,daemon=True).start()

            def worker():
                try:
                    result=check_update(feed_url,CURRENT_APP_VERSION,UPDATE_CHANNEL,timeout=8.0)
                    self.root.after(0,lambda r=result: finish_check(r,None))
                except Exception as exc:
                    self.root.after(0,lambda e=str(exc): finish_check(None,e))
            threading.Thread(target=worker,daemon=True).start()

        def show_last_update_result():
            try:
                import json as _json
                from pathlib import Path as _Path
                data_root=_Path(os.environ.get("MONEYTRANSFER_DATA_DIR", str(_Path(os.environ.get("LOCALAPPDATA", str(_Path.home()))) / "MoneyTransfer" / "Data")))
                result_path=data_root / "update_engine" / "last_update_result.json"
                if not result_path.is_file():
                    messagebox.showinfo("آخر تحديث","لا توجد نتيجة تحديث مسجلة بعد.",parent=self.root)
                    return
                data=_json.loads(result_path.read_text(encoding="utf-8-sig"))
                if data.get("ok"):
                    files=data.get("files") or []
                    messagebox.showinfo("آخر تحديث",
                        f"الحالة: ناجح ✅\nالإصدار: {data.get('version','-')}\nالتاريخ: {data.get('applied_at','-')}\nعدد الملفات: {len(files)}\n\nتم الاحتفاظ بنسخة رجوع لملفات البرنامج.",
                        parent=self.root)
                else:
                    messagebox.showerror("آخر تحديث",
                        f"الحالة: فشل وتمت محاولة الرجوع للإصدار السابق.\nالإصدار: {data.get('version','-')}\nالخطأ: {data.get('error','غير معروف')}",
                        parent=self.root)
            except Exception as exc:
                messagebox.showerror("آخر تحديث",f"تعذر قراءة نتيجة آخر تحديث.\n{exc}",parent=self.root)

        def show_production_readiness():
            try:
                info=self.server_request("GET","/api/v1/system/production-readiness",timeout=6.0)
                labels={"database":"قاعدة البيانات","migrations":"ترحيلات قاعدة البيانات","backup_folder":"مجلد النسخ الاحتياطي","private_remote_mode":"الاتصال البعيد الخاص","jwt_secret":"مفتاح جلسات API","sqlite_integrity":"قاعدة SQLite الحالية"}
                lines=[]
                for c in info.get("checks",[]):
                    lines.append(("✓ " if c.get("ok") else "✗ ")+labels.get(c.get("key"),c.get("key","-"))+" — "+str(c.get("detail","")))
                lines += ["",f"Database: {info.get('database_backend','-')}",f"Schema: {info.get('schema_version','-')}",f"Backups: {info.get('backup_count',0)}"]
                if info.get("database_backend")=="sqlite":
                    lines += ["","PostgreSQL: مخطط للمرحلة الإنتاجية النهائية ولن يتم تحويل بياناتك تلقائياً بهذا التحديث."]
                messagebox.showinfo("مركز الجاهزية التجارية","\n".join(lines),parent=self.root)
            except Exception as exc:
                messagebox.showerror("مركز الجاهزية التجارية",str(exc),parent=self.root)

        def create_server_backup_now():
            try:
                data=self.server_request("POST","/api/v1/system/backups",payload={},timeout=20.0)
                b=data.get("backup",{})
                messagebox.showinfo("نسخة احتياطية للسيرفر",f"تم إنشاء نسخة متسقة بنجاح.\n\nالملف: {b.get('file','-')}\nSHA-256: {b.get('sha256','-')}",parent=self.root)
            except Exception as exc:
                messagebox.showerror("نسخة احتياطية للسيرفر",str(exc),parent=self.root)

        def show_release_candidate_report():
            if not self.require_permission("settings","فحص الإصدار التجاري"): return
            labels={
                "database_ping":"اتصال قاعدة البيانات",
                "production_readiness":"جاهزية الخادم الحالي",
                "backup_exists":"وجود نسخة احتياطية للسيرفر",
                "backup_verified":"سلامة أحدث نسخة احتياطية",
                "ledger_balanced":"توازن القيود المالية",
                "ledger_consistent":"سلامة القيود حسب نوع العملية",
                "no_orphan_ledger_entries":"عدم وجود قيود يتيمة",
                "idempotency_unique":"عدم تكرار معرفات العمليات",
                "customer_debt_nonnegative":"سلامة أرصدة ديون العملاء",
            }
            try:
                win=tk.Toplevel(self.root); win.title("مركز جاهزية V8.0"); win.geometry("900x690"); win.minsize(780,580)
                win.transient(self.root)
                header=ttk.Frame(win,padding=(18,16)); header.pack(fill="x")
                ttk.Label(header,text="🧪 مركز جاهزية V8.0",font=(self.ui_font,18,"bold")).pack(side="right")
                status_var=tk.StringVar(value="جاري تشغيل الفحص...")
                score_var=tk.StringVar(value="--%")
                ttk.Label(header,textvariable=score_var,font=(self.ui_font,18,"bold")).pack(side="left",padx=8)
                ttk.Label(win,textvariable=status_var,font=(self.ui_font,11,"bold"),anchor="e").pack(fill="x",padx=18,pady=(0,8))

                tree=ttk.Treeview(win,columns=("state","detail"),show="tree headings",height=16)
                tree.heading("#0",text="الفحص"); tree.heading("state",text="الحالة"); tree.heading("detail",text="التفاصيل")
                tree.column("#0",width=270,anchor="e"); tree.column("state",width=110,anchor="center"); tree.column("detail",width=430,anchor="e")
                tree.pack(fill="both",expand=True,padx=18,pady=8)

                foot=ttk.Frame(win,padding=(18,8,18,16)); foot.pack(fill="x")
                notes_var=tk.StringVar(value="")
                ttk.Label(win,textvariable=notes_var,wraplength=840,justify="right",anchor="e").pack(fill="x",padx=18,pady=(0,4))

                def render(info):
                    for iid in tree.get_children(): tree.delete(iid)
                    score=info.get("score",0); ready=bool(info.get("commercial_release_ready"))
                    score_var.set(f"{score}%")
                    if ready:
                        status_var.set("✓ جميع فحوصات Release Candidate الحالية ناجحة")
                    else:
                        failed=sum(1 for c in info.get("checks",[]) if not c.get("ok"))
                        status_var.set(f"⚠ توجد {failed} نقطة تحتاج معالجة قبل V8.0")
                    for c in info.get("checks",[]):
                        key=c.get("key","")
                        state="ناجح ✓" if c.get("ok") else ("تحذير ⚠" if c.get("severity")=="warning" else "فشل ✗")
                        tree.insert("","end",text=labels.get(key,key),values=(state,c.get("detail","")))
                    notes_var.set("   |   ".join(str(x) for x in info.get("notes",[])))

                def refresh():
                    try:
                        render(self.server_request("GET","/api/v1/system/release-candidate",timeout=10.0))
                    except Exception as e:
                        messagebox.showerror("مركز جاهزية V8.0",str(e),parent=win)

                def backup_and_refresh():
                    try:
                        result=self.server_request("POST","/api/v1/system/release-candidate/prepare",payload={},timeout=30.0)
                        b=result.get("backup_created") or {}
                        v=result.get("backup_verification") or {}
                        if not result.get("ok"):
                            raise RuntimeError("تعذر إنشاء/التحقق من النسخة الاحتياطية الآمنة")
                        render(result.get("report") or {})
                        messagebox.showinfo("التجهيز الآمن",
                            "تم تجهيز Release Candidate بأمان.\n\n"
                            f"النسخة: {b.get('file','موجودة مسبقاً')}\n"
                            f"التحقق: {'ناجح ✓' if v.get('ok') else 'فشل'}",parent=win)
                    except Exception as e:
                        messagebox.showerror("التجهيز الآمن",str(e),parent=win)

                def show_financial_integrity():
                    try:
                        data=self.server_request("GET","/api/v1/system/financial-integrity?limit=1000",timeout=20.0)
                        dwin=tk.Toplevel(win); dwin.title("تشخيص سلامة القيود المالية V7.92"); dwin.geometry("1100x700"); dwin.minsize(900,560); dwin.transient(win)
                        top=ttk.Frame(dwin,padding=(16,12)); top.pack(fill="x")
                        ttk.Label(top,text="🔎 تشخيص سلامة القيود المالية",font=(self.ui_font,16,"bold")).pack(side="right")
                        summary=f"تم فحص {data.get('scanned',0)} عملية  |  سليمة: {data.get('consistent_count',0)}  |  تحتاج مراجعة: {data.get('anomaly_count',0)}  |  قيود محاسبية: {data.get('accounting_baseline_count',0)}  |  قديمة مستوردة: {data.get('legacy_count',0)}"
                        ttk.Label(dwin,text=summary,anchor="e",font=(self.ui_font,11,"bold")).pack(fill="x",padx=16,pady=(0,8))
                        ttk.Label(dwin,text="هذا الفحص للقراءة فقط ولا يغير أي رصيد أو عملية.",anchor="e").pack(fill="x",padx=16,pady=(0,8))
                        cols=("id","op","status","actual","expected","state","reason")
                        t=ttk.Treeview(dwin,columns=cols,show="headings",height=20)
                        heads={"id":"#","op":"العملية","status":"الحالة","actual":"الأثر الفعلي","expected":"المتوقع","state":"التصنيف","reason":"السبب"}
                        widths={"id":65,"op":150,"status":85,"actual":105,"expected":105,"state":120,"reason":350}
                        for c in cols:
                            t.heading(c,text=heads[c]); t.column(c,width=widths[c],anchor="e" if c not in ("id","actual","expected") else "center")
                        y=ttk.Scrollbar(dwin,orient="vertical",command=t.yview); t.configure(yscrollcommand=y.set)
                        t.pack(side="left",fill="both",expand=True,padx=(16,0),pady=8); y.pack(side="left",fill="y",pady=8)
                        for item in data.get("items",[]):
                            expected=item.get("expected_net_fils")
                            expected="-" if expected is None else f"{expected/1000:.3f} JD"
                            actual=f"{int(item.get('ledger_sum_fils',0))/1000:.3f} JD"
                            state="سليم ✓" if item.get("ok") else "مراجعة ⚠"
                            t.insert("","end",values=(item.get("transaction_id"),item.get("op_type",""),item.get("status",""),actual,expected,state,item.get("reason","")))
                        ttk.Button(top,text="إغلاق",command=dwin.destroy).pack(side="left",padx=4)
                    except Exception as e:
                        messagebox.showerror("تشخيص القيود المالية",str(e),parent=win)

                ttk.Button(foot,text="إغلاق",command=win.destroy).pack(side="left",padx=4)
                ttk.Button(foot,text="🔄 إعادة الفحص",command=refresh).pack(side="right",padx=4)
                ttk.Button(foot,text="⚡ تجهيز آمن لـ V8 وإعادة الفحص",command=backup_and_refresh).pack(side="right",padx=4)
                ttk.Button(foot,text="🔎 تشخيص القيود المالية",command=show_financial_integrity).pack(side="right",padx=4)
                ttk.Button(foot,text="فحص سلامة النظام",command=self.run_system_diagnostics).pack(side="right",padx=4)
                refresh()
            except Exception as e:
                messagebox.showerror("مركز جاهزية V8.0",str(e),parent=self.root)

        # Keep the update row short so the critical readiness action never gets clipped on normal screens.
        ttk.Button(update_box,text="🌐 البحث عن تحديث",command=check_online_update).pack(side="left",padx=4)
        ttk.Button(update_box,text="مصدر التحديث",command=configure_online_update_source).pack(side="left",padx=4)
        ttk.Button(update_box,text="تثبيت ZIP",command=select_update_package).pack(side="left",padx=4)
        ttk.Button(update_box,text="حالة آخر تحديث",command=show_last_update_result).pack(side="left",padx=4)
        ttk.Button(update_box,text="🧪 مركز جاهزية V8",command=show_release_candidate_report).pack(side="left",padx=4)
        ttk.Button(update_box,text="فحص التحديث",command=check_update_architecture).pack(side="left",padx=4)

        appearance=ttk.LabelFrame(inner,text="🌗 المظهر",padding=12)
        appearance.pack(fill="x",pady=6)
        ttk.Label(appearance,text="يمكن التبديل مباشرة، ويحفظ البرنامج اختيارك للجلسات القادمة.").pack(side="right",padx=8)
        theme_var=tk.StringVar(value="dark" if self.is_dark_mode else "light")
        def apply_selected_theme():
            self.set_appearance_mode(theme_var.get())
        ttk.Radiobutton(appearance,text="داكن",value="dark",variable=theme_var,command=apply_selected_theme).pack(side="left",padx=5)
        ttk.Radiobutton(appearance,text="فاتح",value="light",variable=theme_var,command=apply_selected_theme).pack(side="left",padx=5)

        general=ttk.LabelFrame(inner,text="🏪 هوية المنشأة والإعدادات العامة",padding=15)
        general.pack(fill="x",pady=6)

        ttk.Label(general,text="اسم المحل / المنشأة").grid(row=0,column=1,sticky="e",padx=5,pady=5)
        business=ttk.Entry(general,justify="right")
        business.insert(0,self.get_setting("business_name","نظام الإدارة المالية"))
        business.grid(row=0,column=0,sticky="ew",padx=5,pady=5)

        accounts=self.account_names()

        def account_combo(row,label,key,default):
            ttk.Label(general,text=label).grid(row=row,column=1,sticky="e",padx=5,pady=5)
            cb=ttk.Combobox(general,state="readonly",values=accounts)
            value=self.get_setting(key,default)
            cb.set(value if value in accounts else (accounts[0] if accounts else ""))
            cb.grid(row=row,column=0,sticky="ew",padx=5,pady=5)
            return cb

        cash=account_combo(1,"حساب النقد الافتراضي","default_cash_account","النقد كاش")
        comm=account_combo(2,"حساب العمولة الافتراضي","default_commission_account","النقد كاش")
        bill=account_combo(3,"حساب دفع الفواتير الافتراضي","default_bill_account","إي فواتيركم")
        withdraw=account_combo(4,"الحساب الافتراضي للسحب المالي","default_withdraw_account","البنك العربي")

        ttk.Label(general,text="العرض الافتراضي لكشف الحساب").grid(row=5,column=1,sticky="e",padx=5,pady=5)
        statement_view=ttk.Combobox(general,state="readonly",values=["جدول","بطاقات الحسابات"])
        sv=self.get_setting("statement_default_view","جدول")
        statement_view.set(sv if sv in ("جدول","بطاقات الحسابات") else "جدول")
        statement_view.grid(row=5,column=0,sticky="ew",padx=5,pady=5)

        ttk.Label(general,text="طريقة عرض العمليات").grid(row=6,column=1,sticky="e",padx=5,pady=5)
        operation_view=ttk.Combobox(general,state="readonly",values=["النظام الأصلي","بطاقات سريعة"])
        ov=self.get_setting("operation_view_mode","بطاقات سريعة")
        operation_view.set(ov if ov in ("النظام الأصلي","بطاقات سريعة") else "بطاقات سريعة")
        operation_view.grid(row=6,column=0,sticky="ew",padx=5,pady=5)
        general.columnconfigure(0,weight=1)

        defaults=ttk.LabelFrame(
            inner,text="🎯 الحسابات الافتراضية لكل عملية",padding=15
        )
        defaults.pack(fill="x",pady=6)

        ttk.Label(
            defaults,
            text="أي حساب جديد تضيفه يظهر تلقائياً في كل القوائم هنا عند إعادة فتح الإعدادات.",
            font=("Segoe UI",8)
        ).grid(row=0,column=0,columnspan=4,sticky="e",pady=(0,8))

        default_boxes={}

        def op_default(row,col,label,key,fallback,allow_empty=False):
            ttk.Label(defaults,text=label).grid(
                row=row*2+1,column=col,sticky="e",padx=5,pady=(4,1)
            )
            values=([""]+accounts) if allow_empty else accounts
            cb=ttk.Combobox(defaults,state="readonly",values=values,width=28)
            val=self.get_setting(key,fallback)
            if val in values:
                cb.set(val)
            elif fallback in values:
                cb.set(fallback)
            elif values:
                cb.set(values[0])
            cb.grid(row=row*2+2,column=col,sticky="ew",padx=5,pady=(0,5))
            default_boxes[key]=cb

        op_default(0,3,"الحوالة الصادرة - من","default_outgoing_source","البنك الإسلامي")
        op_default(0,2,"الحوالة الصادرة - إلى","default_outgoing_destination","النقد كاش")
        op_default(0,1,"الحوالة الواردة - من","default_incoming_source","النقد كاش")
        op_default(0,0,"الحوالة الواردة - إلى","default_incoming_destination","محفظة أورنج موني")

        op_default(1,3,"دفع فاتورة - من","default_bill_source","إي فواتيركم")
        op_default(1,2,"دفع فاتورة - إلى","default_bill_destination","النقد كاش")
        op_default(1,1,"نقل أموال - من","default_transfer_source","النقد كاش")
        op_default(1,0,"نقل أموال - إلى","default_transfer_destination","البنك الإسلامي")

        op_default(2,3,"بيع بطاقة - من","default_card_source","النقد كاش")
        op_default(2,2,"بيع بطاقة - إلى","default_card_destination","النقد كاش")
        op_default(2,1,"سحب مالي - من","default_withdraw_account","البنك العربي")
        op_default(2,0,"سحب مالي - إلى","default_withdraw_destination","",True)

        op_default(3,3,"دين للعميل - من","default_debt_account","النقد كاش")
        op_default(3,2,"دين للعميل - إلى","default_debt_destination","",True)
        op_default(3,1,"سداد دين - من","default_repayment_source","",True)
        op_default(3,0,"سداد دين - إلى","default_repayment_account","النقد كاش")

        op_default(4,3,"حساب إضافة العمولة","default_commission_account","النقد كاش")
        op_default(4,2,"حساب النقد العام","default_cash_account","النقد كاش")
        op_default(4,1,"حساب الفواتير العام","default_bill_account","إي فواتيركم")

        for c in range(4):
            defaults.columnconfigure(c,weight=1)

        cbox=ttk.LabelFrame(inner,text="⚡ تخصيص شاشة العمليات والاختصارات",padding=15)
        cbox.pack(fill="x",pady=6)
        ttk.Label(cbox,text="اختصارات المبلغ (قيم مفصولة بفواصل)").grid(row=0,column=1,sticky="e",padx=5,pady=4)
        amount_presets=ttk.Entry(cbox,justify="right")
        amount_presets.insert(0,self.get_setting("amount_presets","5,10,20,50,100"))
        amount_presets.grid(row=0,column=0,sticky="ew",padx=5,pady=4)
        ttk.Label(cbox,text="اختصارات العمولة (قيم مفصولة بفواصل)").grid(row=1,column=1,sticky="e",padx=5,pady=4)
        presets=ttk.Entry(cbox,justify="right")
        presets.insert(0,self.get_setting("commission_presets","0.250,0.500,0.750,1.000"))
        presets.grid(row=1,column=0,sticky="ew",padx=5,pady=4)
        ttk.Label(cbox,text="العملية الافتراضية عند فتح الشاشة").grid(row=2,column=1,sticky="e",padx=5,pady=4)
        default_operation=ttk.Combobox(cbox,state="readonly",values=["حوالة صادرة","حوالة واردة","دفع فاتورة","نقل أموال","بيع بطاقة خلوية","سحب مالي","دين للعميل","سداد دين"])
        default_operation.set(self.get_setting("default_operation","حوالة صادرة")); default_operation.grid(row=2,column=0,sticky="ew",padx=5,pady=4)
        ttk.Label(cbox,text="بعد إتمام العملية").grid(row=3,column=1,sticky="e",padx=5,pady=4)
        after_action=ttk.Combobox(cbox,state="readonly",values=["نفس العملية","شاشة العمليات","الرئيسية"])
        after_action.set(self.get_setting("after_transaction_action","نفس العملية")); after_action.grid(row=3,column=0,sticky="ew",padx=5,pady=4)
        ttk.Label(cbox,text="حجم خط الواجهة (9 - 16)").grid(row=4,column=1,sticky="e",padx=5,pady=4)
        font_size_var=tk.StringVar(value=self.get_setting("font_size","10"))
        ttk.Spinbox(cbox,from_=9,to=16,textvariable=font_size_var,width=8).grid(row=4,column=0,sticky="e",padx=5,pady=4)
        ttk.Label(cbox,text="كثافة الواجهة").grid(row=5,column=1,sticky="e",padx=5,pady=4)
        density_var=ttk.Combobox(cbox,state="readonly",values=["compact","comfortable"])
        density_var.set(self.get_setting("ui_density","compact")); density_var.grid(row=5,column=0,sticky="ew",padx=5,pady=4)
        ttk.Label(cbox,text="عدد أعمدة بطاقات العمليات (2 - 4)").grid(row=6,column=1,sticky="e",padx=5,pady=4)
        op_cols_var=tk.StringVar(value=self.get_setting("operation_columns","4"))
        ttk.Spinbox(cbox,from_=2,to=4,textvariable=op_cols_var,width=8).grid(row=6,column=0,sticky="e",padx=5,pady=4)
        ttk.Label(cbox,text="عدد أعمدة بطاقات الحسابات (2 - 5)").grid(row=7,column=1,sticky="e",padx=5,pady=4)
        acc_cols_var=tk.StringVar(value=self.get_setting("account_columns","4"))
        ttk.Spinbox(cbox,from_=2,to=5,textvariable=acc_cols_var,width=8).grid(row=7,column=0,sticky="e",padx=5,pady=4)
        ttk.Label(cbox,text="ترتيب العمليات (مفصولة بفواصل)").grid(row=8,column=1,sticky="e",padx=5,pady=4)
        operation_order_var=tk.StringVar(value=self.get_setting("operation_order","حوالة صادرة,حوالة واردة,دفع فاتورة,نقل أموال,بيع بطاقة خلوية,سحب مالي,دين للعميل,سداد دين"))
        ttk.Entry(cbox,textvariable=operation_order_var,justify="right").grid(row=8,column=0,sticky="ew",padx=5,pady=4)
        cbox.columnconfigure(0,weight=1)

        behavior=ttk.LabelFrame(inner,text="🧩 سلوك البرنامج",padding=15)
        behavior.pack(fill="x",pady=6)
        confirm_var=tk.BooleanVar(value=self.get_setting("confirm_transactions","1")=="1")
        maximize_var=tk.BooleanVar(value=self.get_setting("start_maximized","1")=="1")
        alert_var=tk.BooleanVar(value=self.get_setting("low_balance_alerts","1")=="1")
        duplicate_var=tk.BooleanVar(value=self.get_setting("duplicate_warning","1")=="1")
        ttk.Checkbutton(behavior,text="طلب تأكيد قبل حفظ كل عملية",variable=confirm_var).pack(anchor="e",pady=3)
        ttk.Checkbutton(behavior,text="فتح البرنامج مكبراً عند تسجيل الدخول",variable=maximize_var).pack(anchor="e",pady=3)
        ttk.Checkbutton(behavior,text="تنبيه انخفاض رصيد الحسابات",variable=alert_var).pack(anchor="e",pady=3)
        ttk.Checkbutton(behavior,text="تحذير عند الاشتباه بتكرار العملية",variable=duplicate_var).pack(anchor="e",pady=3)

        share=ttk.LabelFrame(inner,text="📤 البريد وواتساب",padding=15)
        share.pack(fill="x",pady=6)

        email_enabled=tk.BooleanVar(value=self.get_setting("email_enabled","0")=="1")
        wa_enabled=tk.BooleanVar(value=self.get_setting("whatsapp_enabled","0")=="1")
        ttk.Checkbutton(share,text="تفعيل البريد للتقارير وطلبات الاستعادة",variable=email_enabled).grid(row=0,column=0,columnspan=2,sticky="e",pady=4)
        ttk.Checkbutton(share,text="تفعيل واتساب للتقارير وطلبات الاستعادة",variable=wa_enabled).grid(row=1,column=0,columnspan=2,sticky="e",pady=4)

        fields={}
        for row,(key,label) in enumerate([
            ("report_email","البريد الافتراضي لإرسال التقارير"),
            ("report_whatsapp","واتساب الافتراضي لإرسال التقارير"),
            ("support_email","بريد المدير لطلبات نسيان كلمة المرور"),
            ("support_whatsapp","واتساب المدير لطلبات نسيان كلمة المرور"),
        ],start=2):
            ttk.Label(share,text=label).grid(row=row,column=1,sticky="e",padx=5,pady=4)
            e=ttk.Entry(share,justify="left")
            e.insert(0,self.get_setting(key,""))
            e.grid(row=row,column=0,sticky="ew",padx=5,pady=4)
            fields[key]=e
        share.columnconfigure(0,weight=1)

        ttk.Label(share,text="مزوّد بريد التقارير").grid(
            row=6,column=1,sticky="e",padx=5,pady=4
        )
        email_provider=ttk.Combobox(
            share,state="readonly",
            values=["تلقائي","Gmail","Yahoo","Outlook","برنامج البريد الافتراضي"]
        )
        ep=self.get_setting("email_provider","تلقائي")
        email_provider.set(ep or "تلقائي")
        email_provider.grid(row=6,column=0,sticky="ew",padx=5,pady=4)

        ttk.Label(share,text="مزوّد بريد استعادة كلمة المرور").grid(
            row=7,column=1,sticky="e",padx=5,pady=4
        )
        recovery_email_provider=ttk.Combobox(
            share,state="readonly",
            values=["تلقائي","Gmail","Yahoo","Outlook","برنامج البريد الافتراضي"]
        )
        rep=self.get_setting("recovery_email_provider","تلقائي")
        recovery_email_provider.set(rep or "تلقائي")
        recovery_email_provider.grid(row=7,column=0,sticky="ew",padx=5,pady=4)

        ttk.Label(
            share,
            text="واتساب يفتح المحادثة برسالة جاهزة، والبريد يفتح برنامج البريد برسالة جاهزة. "
                 "لا يتم تخزين كلمة مرور بريد أو واتساب داخل البرنامج.",
            wraplength=850,justify="right",
            font=("Segoe UI",8)
        ).grid(row=8,column=0,columnspan=2,sticky="e",pady=6)

        backup=ttk.LabelFrame(inner,text="💾 النسخ الاحتياطي",padding=15)
        backup.pack(fill="x",pady=6)
        backup_folder_var=tk.StringVar(value=self.get_setting("backup_folder",""))
        auto_backup_var=tk.BooleanVar(value=self.get_setting("auto_backup_shift","0")=="1")
        ttk.Label(backup,text="مجلد حفظ النسخ الاحتياطية").pack(anchor="e")
        folder_row=ttk.Frame(backup); folder_row.pack(fill="x",pady=5)
        ttk.Entry(folder_row,textvariable=backup_folder_var,justify="left").pack(side="left",fill="x",expand=True,padx=4)

        def choose_folder():
            folder=filedialog.askdirectory(title="اختر مجلد النسخ الاحتياطي")
            if folder:
                backup_folder_var.set(folder)
        ttk.Button(folder_row,text="📁 اختيار",command=choose_folder).pack(side="right",padx=4)
        ttk.Checkbutton(
            backup,text="نسخة احتياطية تلقائياً بعد إنهاء كل وردية",
            variable=auto_backup_var
        ).pack(anchor="e",pady=4)
        retention_row=ttk.Frame(backup); retention_row.pack(fill="x",pady=4)
        ttk.Label(retention_row,text="عدد النسخ التي يحتفظ بها البرنامج").pack(side="right",padx=5)
        backup_retention_var=tk.StringVar(value=self.get_setting("backup_retention_count","30"))
        ttk.Spinbox(retention_row,from_=5,to=200,textvariable=backup_retention_var,width=8).pack(side="right",padx=5)
        if self.has_permission("backup"):
            ttk.Button(
                backup,text="💾 إنشاء نسخة احتياطية الآن",command=lambda:self.backup_database()
            ).pack(anchor="e",pady=5)
            ttk.Button(backup,text="🛡 مركز حماية البيانات والاستعادة",command=self.show_backup_center).pack(anchor="e",pady=5)

        currency=ttk.LabelFrame(inner,text="💱 العملة والعرض",padding=15)
        currency.pack(fill="x",pady=6)
        ttk.Label(
            currency,
            text="الدينار الأردني JD — ثلاث خانات عشرية — مثال: 1,115.000 JD"
        ).pack(anchor="e")

        def save():
            try:
                vals=[self.parse_number(x.strip()) for x in presets.get().split(",") if x.strip()]
                if not vals or len(vals)>4 or any(v<0 for v in vals):
                    raise ValueError
            except ValueError:
                messagebox.showerror("خطأ","اختصارات العمولة غير صحيحة")
                return
            try:
                amount_vals=[self.parse_number(x.strip()) for x in amount_presets.get().split(",") if x.strip()]
                if not amount_vals or len(amount_vals)>8 or any(v<=0 for v in amount_vals): raise ValueError
                fs=int(font_size_var.get());
                op_cols=int(op_cols_var.get()); acc_cols=int(acc_cols_var.get()); retention=int(backup_retention_var.get())
                if fs<9 or fs>16 or op_cols<2 or op_cols>4 or acc_cols<2 or acc_cols>5 or retention<5 or retention>200: raise ValueError
                canonical_ops=["حوالة صادرة","حوالة واردة","دفع فاتورة","نقل أموال","بيع بطاقة خلوية","سحب مالي","دين للعميل","سداد دين"]
                ordered=[x.strip() for x in operation_order_var.get().split(",") if x.strip()]
                if set(ordered)!=set(canonical_ops) or len(ordered)!=len(canonical_ops): raise ValueError
            except ValueError:
                messagebox.showerror("خطأ","تحقق من الاختصارات وحجم الخط وكثافة الواجهة وترتيب العمليات وإعدادات النسخ")
                return

            values={
                "business_name": business.get().strip() or "نظام الإدارة المالية",
                "default_cash_account": cash.get(),
                "default_commission_account": comm.get(),
                "default_bill_account": bill.get(),
                "default_withdraw_account": withdraw.get(),
                "statement_default_view": statement_view.get(),
                "operation_view_mode": operation_view.get(),
                "commission_presets": ",".join(f"{v:.3f}" for v in vals),
                "amount_presets": ",".join(f"{v:g}" for v in amount_vals),
                "default_operation": default_operation.get(),
                "after_transaction_action": after_action.get(),
                "font_size": str(fs),
                "ui_density": density_var.get(),
                "operation_columns": str(op_cols),
                "account_columns": str(acc_cols),
                "operation_order": ",".join(ordered),
                "backup_retention_count": str(retention),
                "duplicate_warning": "1" if duplicate_var.get() else "0",
                "confirm_transactions": "1" if confirm_var.get() else "0",
                "start_maximized": "1" if maximize_var.get() else "0",
                "low_balance_alerts": "1" if alert_var.get() else "0",
                "appearance_mode": theme_var.get(),
                "backup_folder": backup_folder_var.get().strip(),
                "auto_backup_shift": "1" if auto_backup_var.get() else "0",
                "email_enabled": "1" if email_enabled.get() else "0",
                "whatsapp_enabled": "1" if wa_enabled.get() else "0",
                "email_provider": email_provider.get(),
                "recovery_email_provider": recovery_email_provider.get(),
            }
            for k,e in fields.items():
                values[k]=e.get().strip()
            for k,cb in default_boxes.items():
                values[k]=cb.get()
            for k,v in values.items():
                self.set_setting(k,v)

            self.root.title(f"{values['business_name']} - {self.username}")
            self.set_appearance_mode(values["appearance_mode"], persist=False)
            self.root.option_add("*Font", (self.ui_font, fs))
            messagebox.showinfo("تم","تم حفظ جميع الإعدادات. ستظهر قيم الاختصارات فور فتح شاشة العمليات، ويُطبق حجم الخط بالكامل بعد إعادة تشغيل البرنامج.")

        tools_bar=ttk.Frame(inner); tools_bar.pack(fill="x",pady=(8,2))
        ttk.Button(tools_bar,text="📤 تصدير الإعدادات",command=self.export_commercial_settings).pack(side="right",padx=4)
        ttk.Button(tools_bar,text="📥 استيراد الإعدادات",command=self.import_commercial_settings).pack(side="right",padx=4)
        ttk.Button(
            inner,text="✅ حفظ جميع الإعدادات",
            command=save,style="Accent.TButton"
        ).pack(anchor="e",pady=12,ipadx=20,ipady=6)

        inner.update_idletasks()
        self.enable_edit_shortcuts_recursive(inner)
        self.root.after_idle(
            lambda: self.page_canvas.configure(
                scrollregion=self.page_canvas.bbox("all")
            )
        )

    def export_commercial_settings(self):
        if not self.require_permission("settings","تصدير الإعدادات"):
            return
        path=filedialog.asksaveasfilename(title="تصدير إعدادات MoneyTransfer",defaultextension=".json",filetypes=[("JSON","*.json")],initialfile="MoneyTransfer_Settings.json")
        if not path: return
        conn=get_db(); rows=conn.execute("SELECT key,value FROM settings ORDER BY key").fetchall(); conn.close()
        excluded={"remembered_username"}
        payload={"product":"MoneyTransfer","format":1,"exported_at":datetime.now().isoformat(timespec="seconds"),"settings":{k:v for k,v in rows if k not in excluded}}
        try:
            Path(path).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
            self.log("تصدير إعدادات",Path(path).name)
            messagebox.showinfo("تم","تم تصدير الإعدادات فقط. لا يحتوي الملف على أرصدة أو عمليات أو عملاء.")
        except Exception as exc:
            messagebox.showerror("خطأ",str(exc))

    def import_commercial_settings(self):
        if not self.require_permission("settings","استيراد الإعدادات"):
            return
        path=filedialog.askopenfilename(title="استيراد إعدادات MoneyTransfer",filetypes=[("JSON","*.json")])
        if not path: return
        try:
            payload=json.loads(Path(path).read_text(encoding="utf-8"))
            if payload.get("product")!="MoneyTransfer" or not isinstance(payload.get("settings"),dict):
                raise ValueError("ملف الإعدادات غير صالح")
            protected={"remembered_username"}
            settings={str(k):str(v) for k,v in payload["settings"].items() if k not in protected}
            if not messagebox.askyesno("تأكيد الاستيراد",f"سيتم استيراد {len(settings)} إعداداً فقط دون لمس البيانات المالية. متابعة؟"):
                return
            conn=get_db(); cur=conn.cursor()
            for k,v in settings.items():
                cur.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,v))
            conn.commit(); conn.close()
            self.log("استيراد إعدادات",Path(path).name)
            messagebox.showinfo("تم","تم استيراد الإعدادات. أعد فتح البرنامج لتطبيق كل تغييرات الواجهة.")
        except Exception as exc:
            messagebox.showerror("فشل الاستيراد",str(exc))

    def _cleanup_old_backups(self):
        try:
            root=self._backup_root()
            if not root: return
            keep=max(5,min(200,int(self.get_setting("backup_retention_count","30"))))
            files=sorted(Path(root).glob("MoneyTransfer_Backup_*.db"),key=lambda p:p.stat().st_mtime,reverse=True)
            for old in files[keep:]:
                try:
                    sha=Path(str(old)+".sha256")
                    old.unlink()
                    if sha.exists(): sha.unlink()
                except Exception: pass
        except Exception:
            pass

    def sanitize_filename(self, name):
        safe = re.sub(r'[\\/:*?"<>|]+', "_", str(name))
        safe = safe.strip().replace(" ", "_")
        return safe or "report"

    def choose_report_path(self, title, ext):
        filename = self.sanitize_filename(title) + ext
        return filedialog.asksaveasfilename(
            title="حفظ التقرير",
            defaultextension=ext,
            initialfile=filename,
            filetypes=[
                ("PDF", "*.pdf"),
                ("HTML", "*.html"),
                ("Text", "*.txt"),
                ("All files", "*.*")
            ]
        )

    def save_text_report(self, title, body):
        path = filedialog.asksaveasfilename(
            title="حفظ التقرير كنص",
            defaultextension=".txt",
            initialfile=self.sanitize_filename(title)+".txt",
            filetypes=[("Text", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return None
        with open(path, "w", encoding="utf-8") as f:
            f.write(body)
        messagebox.showinfo("تم", f"تم حفظ التقرير:\n{path}")
        return path

    def save_report_html(self, title, body, open_after=False):
        path = self.choose_report_path(title, ".html")
        if not path:
            return None

        business = self.get_setting("business_name","نظام الإدارة المالية")
        body_html = (
            body.replace("&","&amp;")
                .replace("<","&lt;")
                .replace(">","&gt;")
                .replace("\n","<br>")
        )

        html = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
body {{
  font-family: "Segoe UI", Tahoma, Arial, sans-serif;
  direction: rtl;
  margin: 28px;
  color: #111827;
}}
.header {{
  border-bottom: 2px solid #1f2937;
  padding-bottom: 10px;
  margin-bottom: 18px;
}}
h1 {{ margin: 0; font-size: 22px; }}
h2 {{ margin: 6px 0 0 0; font-size: 16px; color: #4b5563; }}
pre {{
  white-space: pre-wrap;
  line-height: 1.7;
  font-size: 13px;
  border: 1px solid #d1d5db;
  background: #f9fafb;
  padding: 14px;
}}
.footer {{
  margin-top: 20px;
  font-size: 11px;
  color: #6b7280;
  border-top: 1px solid #e5e7eb;
  padding-top: 8px;
}}
@media print {{
  button {{ display: none; }}
  body {{ margin: 12mm; }}
}}
</style>
</head>
<body>
<button onclick="window.print()" style="padding:10px 18px;margin-bottom:14px">طباعة / حفظ PDF</button>
<div class="header">
<h1>{business}</h1>
<h2>{title}</h2>
</div>
<pre>{body_html}</pre>
<div class="footer">Developed by Anas alomran</div>
</body>
</html>"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

        if open_after:
            webbrowser.open(Path(path).as_uri())
        else:
            messagebox.showinfo("تم", f"تم حفظ التقرير:\n{path}")
        return path

    def save_report_pdf(self, title, body):
        """يحاول إنشاء PDF حقيقي. إن لم تتوفر مكتبة reportlab يحفظ HTML للطباعة."""
        path = self.choose_report_path(title, ".pdf")
        if not path:
            return None

        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.enums import TA_RIGHT
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            from reportlab.lib.units import mm

            # أفضل خطوط ويندوز للعربية.
            font_candidates = [
                r"C:\Windows\Fonts\arial.ttf",
                r"C:\Windows\Fonts\tahoma.ttf",
                r"C:\Windows\Fonts\seguiemj.ttf",
            ]
            font_name = "Helvetica"
            for fp in font_candidates:
                if os.path.exists(fp):
                    font_name = "ArabicWinFont"
                    pdfmetrics.registerFont(TTFont(font_name, fp))
                    break

            styles = getSampleStyleSheet()
            arabic = ParagraphStyle(
                "Arabic",
                parent=styles["Normal"],
                fontName=font_name,
                fontSize=10,
                leading=15,
                alignment=TA_RIGHT,
                rightIndent=0,
            )
            title_style = ParagraphStyle(
                "TitleArabic",
                parent=styles["Title"],
                fontName=font_name,
                fontSize=16,
                leading=20,
                alignment=TA_RIGHT,
            )

            doc = SimpleDocTemplate(
                path,
                pagesize=A4,
                rightMargin=14*mm,
                leftMargin=14*mm,
                topMargin=14*mm,
                bottomMargin=14*mm,
            )

            story = []
            business = self.get_setting("business_name","نظام الإدارة المالية")
            story.append(Paragraph(business, title_style))
            story.append(Paragraph(title, title_style))
            story.append(Spacer(1, 8))

            for line in body.splitlines():
                safe = (
                    line.replace("&","&amp;")
                        .replace("<","&lt;")
                        .replace(">","&gt;")
                )
                if not safe.strip():
                    story.append(Spacer(1, 6))
                else:
                    story.append(Paragraph(safe, arabic))

            story.append(Spacer(1, 12))
            story.append(Paragraph("Developed by Anas alomran", arabic))
            doc.build(story)

            messagebox.showinfo("تم", f"تم حفظ PDF:\n{path}")
            return path

        except Exception as e:
            # fallback عملي: HTML يطبع عربي ممتاز من المتصفح ويمكن حفظه PDF.
            messagebox.showwarning(
                "PDF",
                "لم أستطع إنشاء PDF مباشر على هذا الجهاز.\n"
                "سأحفظ التقرير كصفحة HTML قابلة للطباعة والحفظ كـ PDF من المتصفح.\n\n"
                f"السبب: {e}"
            )
            return self.save_report_html(title, body, open_after=True)

    def print_report(self, title, body):
        """يفتح التقرير للطباعة. أفضل طريقة شاملة لكل الطابعات هي نافذة طباعة المتصفح."""
        path = self.save_report_html(title, body, open_after=True)
        if path:
            messagebox.showinfo(
                "الطباعة",
                "فتحت صفحة التقرير في المتصفح.\n"
                "اضغط Ctrl+P لاختيار أي طابعة على الجهاز أو Save as PDF."
            )

    def report_actions_window(self, title, body):
        win = tk.Toplevel(self.root)
        win.title("حفظ / طباعة / مشاركة")
        win.geometry("470x380")
        win.resizable(False, False)

        f = ttk.Frame(win, padding=18)
        f.pack(fill="both", expand=True)

        ttk.Label(
            f, text=title,
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="e", pady=(0,10))

        ttk.Button(
            f, text="💾 حفظ PDF",
            command=lambda: self.save_report_pdf(title, body)
        ).pack(fill="x", pady=4)

        ttk.Button(
            f, text="🌐 حفظ/فتح HTML للطباعة",
            command=lambda: self.save_report_html(title, body, open_after=True)
        ).pack(fill="x", pady=4)

        ttk.Button(
            f, text="🖨 فتح للطباعة واختيار الطابعة",
            command=lambda: self.print_report(title, body)
        ).pack(fill="x", pady=4)

        ttk.Button(
            f, text="📄 حفظ ملف نصي",
            command=lambda: self.save_text_report(title, body)
        ).pack(fill="x", pady=4)

        if self.get_setting("email_enabled","0")=="1":
            ttk.Button(
                f, text="📧 إرسال بالبريد",
                command=lambda: self.share_email(title, body)
            ).pack(fill="x", pady=4)

        if self.get_setting("whatsapp_enabled","0")=="1":
            ttk.Button(
                f, text="💬 إرسال/نسخ للواتساب",
                command=lambda: self.share_whatsapp(body)
            ).pack(fill="x", pady=4)

        ttk.Label(
            f,
            text="ملاحظة: اختيار الطابعة يتم من نافذة الطباعة في المتصفح، وهذا يعمل مع معظم الطابعات المثبتة على Windows.",
            font=("Segoe UI", 8),
            wraplength=420,
            justify="right"
        ).pack(anchor="e", pady=10)

    def detect_email_provider(self, email, configured="تلقائي"):
        configured=(configured or "تلقائي").strip()
        if configured!="تلقائي":
            return configured
        domain=email.split("@")[-1].lower() if "@" in email else ""
        if domain in ("gmail.com","googlemail.com"):
            return "Gmail"
        if "yahoo." in domain:
            return "Yahoo"
        if domain in ("outlook.com","hotmail.com","live.com","msn.com"):
            return "Outlook"
        return "برنامج البريد الافتراضي"

    def open_email_compose(self, recipient, subject, body, provider="تلقائي"):
        recipient=(recipient or "").strip()
        if not recipient:
            messagebox.showwarning("البريد","لم يتم تحديد عنوان البريد.")
            return
        provider=self.detect_email_provider(recipient,provider)
        to_q=quote(recipient); sub_q=quote(subject); body_q=quote(body)

        if provider=="Gmail":
            url=f"https://mail.google.com/mail/?view=cm&fs=1&to={to_q}&su={sub_q}&body={body_q}"
        elif provider=="Yahoo":
            url=f"https://compose.mail.yahoo.com/?to={to_q}&subject={sub_q}&body={body_q}"
        elif provider=="Outlook":
            url=f"https://outlook.live.com/mail/0/deeplink/compose?to={to_q}&subject={sub_q}&body={body_q}"
        else:
            url=f"mailto:{recipient}?subject={sub_q}&body={body_q}"
        webbrowser.open(url)

    def share_email(self, subject, body, recipient=None):
        if self.get_setting("email_enabled","0")!="1":
            messagebox.showinfo("البريد","البريد غير مفعّل من الإعدادات.")
            return
        to=(recipient or self.get_setting("report_email","")).strip()
        if not to:
            messagebox.showwarning("البريد","حدد بريد التقارير من الإعدادات.")
            return
        provider=self.get_setting("email_provider","تلقائي")
        self.open_email_compose(to,subject,body,provider)

    def share_whatsapp(self, body, number=None):
        if self.get_setting("whatsapp_enabled","0")!="1":
            messagebox.showinfo("واتساب","واتساب غير مفعّل من الإعدادات.")
            return

        target = re.sub(
            r"\D","",
            (number or self.get_setting("report_whatsapp","")).strip()
        )
        if not target:
            messagebox.showwarning("واتساب","حدد رقم واتساب التقارير من الإعدادات.")
            return

        win = tk.Toplevel(self.root)
        win.title("إرسال واتساب")
        win.geometry("500x330")
        win.resizable(False, False)

        f = ttk.Frame(win, padding=18)
        f.pack(fill="both", expand=True)

        ttk.Label(
            f,
            text="اختر طريقة فتح واتساب",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="e", pady=(0,8))

        def copy_msg():
            self.root.clipboard_clear()
            self.root.clipboard_append(body)
            self.root.update()
            messagebox.showinfo("تم", "تم نسخ نص الرسالة.", parent=win)

        ttk.Button(
            f,
            text="1) فتح تطبيق واتساب المثبت على الكمبيوتر",
            command=lambda: webbrowser.open(
                f"whatsapp://send?phone={target}&text={quote(body)}"
            )
        ).pack(fill="x", pady=5)

        ttk.Button(
            f,
            text="2) فتح رابط واتساب في المتصفح",
            command=lambda: webbrowser.open(
                f"https://wa.me/{target}?text={quote(body)}"
            )
        ).pack(fill="x", pady=5)

        ttk.Button(
            f,
            text="3) نسخ الرسالة فقط",
            command=copy_msg
        ).pack(fill="x", pady=5)

        ttk.Label(
            f,
            text="إذا ظهرت شاشة سوداء في المتصفح، استخدم الخيار الأول لتطبيق واتساب أو الخيار الثالث وانسخ الرسالة يدويًا.",
            wraplength=440,
            justify="right",
            font=("Segoe UI", 8)
        ).pack(anchor="e", pady=10)

        ttk.Button(f, text="إغلاق", command=win.destroy).pack(pady=5)

    def build_balances_share_text(self):
        conn=get_db()
        rows=conn.execute("""
            SELECT name,balance FROM accounts WHERE active=1 ORDER BY id
        """).fetchall()
        conn.close()
        business=self.get_setting("business_name","نظام الإدارة المالية")
        lines=[
            business,
            "كشف الأرصدة",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "-"*30
        ]
        total=0.0
        for name,balance in rows:
            total+=float(balance)
            lines.append(f"{name}: {float(balance):,.3f} JD")
        lines.append("-"*30)
        lines.append(f"الإجمالي: {total:,.3f} JD")
        return "\n".join(lines)

    def build_shift_share_text(self, shift_id, business_date, start, rows, accounts, total_comm):
        business=self.get_setting("business_name","نظام الإدارة المالية")
        lines=[
            business,
            f"تقرير الوردية #{shift_id}",
            f"تاريخ العمل: {business_date}",
            f"بداية الوردية: {start}",
            "-"*35,
            "العمليات:"
        ]
        for i,r in enumerate(rows,1):
            lines.append(
                f"{i}) {r[2]} | {float(r[5]):,.3f} JD | "
                f"عمولة {float(r[6]):,.3f} JD | {r[1]}"
            )
        lines.append("-"*35)
        lines.append("الأرصدة:")
        total=0.0
        for name,balance in accounts:
            total+=float(balance)
            lines.append(f"{name}: {float(balance):,.3f} JD")
        lines.append(f"مجموع الأرصدة: {total:,.3f} JD")
        lines.append(f"عمولات الوردية: {float(total_comm):,.3f} JD")
        return "\n".join(lines)

    def build_account_statement_share_text(self, account_name):
        conn=get_db()
        params=[]
        where="status='active'"
        if account_name and account_name!="جميع الحسابات":
            where += " AND (source_account=? OR destination_account=? OR commission_account=?)"
            params=[account_name,account_name,account_name]
        rows=conn.execute(f"""
            SELECT created_at,op_type,source_account,destination_account,
                   amount,commission,details
            FROM transactions
            WHERE {where}
            ORDER BY created_at,id
            LIMIT 300
        """,params).fetchall()
        conn.close()
        title=account_name or "جميع الحسابات"
        lines=[
            self.get_setting("business_name","نظام الإدارة المالية"),
            f"كشف الحساب: {title}",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "-"*35
        ]
        for r in rows:
            lines.append(
                f"{r[0]} | {r[1]} | {float(r[4]):,.3f} JD | "
                f"عمولة {float(r[5]):,.3f} JD | {r[6] or ''}"
            )
        return "\n".join(lines)

    def share_text_choice(self, title, body):
        self.report_actions_window(title, body)

    def _backup_root(self):
        folder=self.get_setting("backup_folder","").strip()
        if not folder:
            folder=os.environ.get("MONEYTRANSFER_BACKUP_DIR","").strip()
        return folder

    def verify_backup_file(self, path):
        try:
            conn=sqlite3.connect(path); row=conn.execute("PRAGMA integrity_check").fetchone(); conn.close()
            return bool(row and str(row[0]).lower()=="ok")
        except Exception:
            return False

    def backup_database(self, silent=False):
        if not silent and not self.require_permission("backup","النسخ الاحتياطي"): return None
        if not os.path.exists(DB_NAME):
            if not silent: messagebox.showerror("خطأ","ملف قاعدة البيانات غير موجود")
            return None
        folder=self._backup_root()
        if not folder and not silent:
            folder=filedialog.askdirectory(title="اختر مكان حفظ النسخة الاحتياطية")
            if folder: self.set_setting("backup_folder",folder)
        if not folder: return None
        try:
            os.makedirs(folder,exist_ok=True); stamp=datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            filename=os.path.join(folder,f"MoneyTransfer_Backup_{stamp}.db")
            src=sqlite3.connect(DB_NAME); dst=sqlite3.connect(filename); src.backup(dst); dst.close(); src.close()
            if not self.verify_backup_file(filename):
                try: os.remove(filename)
                except Exception: pass
                raise RuntimeError("فشل فحص سلامة النسخة الاحتياطية")
            digest=hashlib.sha256(Path(filename).read_bytes()).hexdigest()
            Path(filename+".sha256").write_text(digest,encoding="utf-8")
            self._cleanup_old_backups()
            self.log("نسخة احتياطية",filename+" | verified")
            if not silent: messagebox.showinfo("تم","تم إنشاء النسخة وفحص سلامتها بنجاح.\n\n"+filename)
            return filename
        except Exception as e:
            if not silent: messagebox.showerror("خطأ",str(e))
            return None

    def restore_database_safe(self):
        if not self.require_permission("backup","استعادة النسخة الاحتياطية"): return
        path=filedialog.askopenfilename(title="اختر نسخة MoneyTransfer",filetypes=[("SQLite backup","*.db"),("All files","*.*")])
        if not path: return
        if not self.verify_backup_file(path):
            messagebox.showerror("نسخة غير صالحة","فشل PRAGMA integrity_check. لن تتم الاستعادة."); return
        if not messagebox.askyesno("تأكيد حساس","سيتم أولاً إنشاء نسخة حماية من البيانات الحالية، ثم استعادة النسخة المختارة. هل تريد المتابعة؟"): return
        safety=self.backup_database(silent=True)
        if not safety:
            messagebox.showerror("تم إلغاء الاستعادة","تعذر إنشاء نسخة حماية للبيانات الحالية."); return
        try:
            tmp=DB_NAME+".restore_tmp"
            shutil.copy2(path,tmp)
            if not self.verify_backup_file(tmp): raise RuntimeError("فشل فحص النسخة المؤقتة")
            os.replace(tmp,DB_NAME)
            self.log("استعادة نسخة احتياطية",f"{path} | safety={safety}")
            messagebox.showinfo("تمت الاستعادة","تمت الاستعادة بنجاح.\nنسخة الحماية السابقة:\n"+safety+"\n\nأعد تشغيل البرنامج الآن.")
        except Exception as e:
            messagebox.showerror("فشل الاستعادة",str(e))

    def show_backup_center(self):
        if not self.require_permission("backup","النسخ الاحتياطي"): return
        win=tk.Toplevel(self.root); win.title("مركز النسخ الاحتياطي وحماية البيانات"); win.geometry("760x520"); win.transient(self.root)
        f=ttk.Frame(win,padding=18); f.pack(fill="both",expand=True)
        ttk.Label(f,text="💾 مركز حماية البيانات",font=(self.ui_font,18,"bold")).pack(anchor="e",pady=(0,8))
        folder=self._backup_root(); ttk.Label(f,text="مجلد النسخ: "+(folder or "غير محدد"),wraplength=700).pack(anchor="e",pady=4)
        status="قاعدة البيانات الحالية سليمة ✓" if self.verify_backup_file(DB_NAME) else "تحذير: فحص قاعدة البيانات الحالية لم ينجح"
        ttk.Label(f,text=status,font=(self.ui_font,11,"bold")).pack(anchor="e",pady=8)
        bar=ttk.Frame(f); bar.pack(fill="x",pady=8)
        ttk.Button(bar,text="💾 نسخة الآن",command=lambda:[self.backup_database(),refresh()]).pack(side="right",padx=4)
        ttk.Button(bar,text="♻ استعادة آمنة",command=self.restore_database_safe).pack(side="right",padx=4)
        ttk.Button(bar,text="🔄 تحديث السجل",command=lambda:refresh()).pack(side="right",padx=4)
        tree=ttk.Treeview(f,columns=("name","size","date","check"),show="headings",height=12)
        for c,h,w in [("name","النسخة",300),("size","الحجم",100),("date","التاريخ",150),("check","السلامة",90)]: tree.heading(c,text=h); tree.column(c,width=w,anchor="center")
        tree.pack(fill="both",expand=True,pady=8)
        def refresh():
            for i in tree.get_children(): tree.delete(i)
            root=self._backup_root()
            if not root or not os.path.isdir(root): return
            files=sorted(Path(root).glob("*.db"),key=lambda x:x.stat().st_mtime,reverse=True)[:100]
            for x in files:
                tree.insert("","end",values=(x.name,f"{x.stat().st_size/1024/1024:.2f} MB",datetime.fromtimestamp(x.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),"✓" if self.verify_backup_file(str(x)) else "✗"))
        refresh()

    def logout(self):
        if not messagebox.askyesno("تسجيل الخروج","هل تريد تسجيل الخروج؟"):
            return

        for w in self.root.winfo_children():
            w.destroy()

        self.root.state("normal")
        self.root.resizable(False, False)
        self.root.geometry("430x320")

        def login_again(username, role):
            for w in self.root.winfo_children():
                w.destroy()
            FinancialApp(self.root, username, role)

        LoginWindow(self.root, login_again)

    def show_users(self):
        if self.role!="admin":
            messagebox.showwarning("غير مسموح","إدارة المستخدمين للمدير فقط.")
            return

        self.clear_content()

        ttk.Label(
            self.content,text="👤 المستخدمون والصلاحيات",
            font=("Segoe UI",20,"bold")
        ).pack(anchor="e",pady=10)

        ttk.Label(
            self.content,
            text="يمكن تحديد اسم المستخدم وكلمة المرور ووسائل الاستعادة وصلاحية كل جزء مهم.",
            font=("Segoe UI",9)
        ).pack(anchor="e",pady=(0,6))

        frame=ttk.Frame(self.content)
        frame.pack(fill="both",expand=True,pady=5)

        cols=("id","user","role","email","whatsapp","status")
        tree=ttk.Treeview(frame,columns=cols,show="headings",height=10)
        defs=[
            ("id","#",60),("user","اسم المستخدم",180),("role","النوع",100),
            ("email","بريد الاستعادة",220),("whatsapp","واتساب",150),
            ("status","الحالة",90)
        ]
        for c,h,w in defs:
            tree.heading(c,text=h)
            tree.column(c,width=w,minwidth=70,anchor="center",stretch=(c=="email"))
        vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview)
        hs=ttk.Scrollbar(frame,orient="horizontal",command=tree.xview)
        tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tree.grid(row=0,column=0,sticky="nsew")
        vs.grid(row=0,column=1,sticky="ns")
        hs.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)

        def reload():
            tree.delete(*tree.get_children())
            conn=get_db()
            rows=conn.execute("""
                SELECT id,username,role,recovery_email,recovery_whatsapp,active
                FROM users ORDER BY id
            """).fetchall()
            conn.close()
            for r in rows:
                tree.insert("", "end", values=(
                    r[0],r[1],
                    "مدير" if r[2]=="admin" else "موظف",
                    r[3] or "",r[4] or "",
                    "فعال" if r[5] else "معطل"
                ))

        def open_editor(uid=None):
            conn=get_db()
            if uid:
                row=conn.execute("""
                    SELECT id,username,role,recovery_email,recovery_whatsapp,active
                    FROM users WHERE id=?
                """,(uid,)).fetchone()
            else:
                row=None
            existing_perms={}
            if uid:
                existing_perms=dict(conn.execute("""
                    SELECT permission,allowed FROM user_permissions WHERE user_id=?
                """,(uid,)).fetchall())
            conn.close()

            win=tk.Toplevel(self.root)
            win.title("تعديل مستخدم" if uid else "إضافة مستخدم")
            win.geometry("760x720")
            win.minsize(650,550)

            outer=ttk.Frame(win,padding=10)
            outer.pack(fill="both",expand=True)

            canvas=tk.Canvas(outer,highlightthickness=0)
            sb=ttk.Scrollbar(outer,orient="vertical",command=canvas.yview)
            inner=ttk.Frame(canvas,padding=8)
            wid=canvas.create_window((0,0),window=inner,anchor="nw")
            inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.bind("<Configure>",lambda e:canvas.itemconfigure(wid,width=e.width))
            canvas.configure(yscrollcommand=sb.set)
            canvas.pack(side="left",fill="both",expand=True)
            sb.pack(side="right",fill="y")

            ttk.Label(
                inner,text="تعديل المستخدم" if uid else "إضافة مستخدم",
                font=("Segoe UI",15,"bold")
            ).pack(anchor="e",pady=6)

            basic=ttk.LabelFrame(inner,text="بيانات الدخول والاستعادة",padding=12)
            basic.pack(fill="x",pady=6)

            ttk.Label(basic,text="اسم المستخدم").grid(row=0,column=1,sticky="e",padx=5,pady=4)
            username=ttk.Entry(basic,justify="right")
            username.grid(row=0,column=0,sticky="ew",padx=5,pady=4)

            ttk.Label(
                basic,
                text="كلمة المرور الجديدة" if uid else "كلمة المرور"
            ).grid(row=1,column=1,sticky="e",padx=5,pady=4)
            password=ttk.Entry(basic,show="*",justify="right")
            password.grid(row=1,column=0,sticky="ew",padx=5,pady=4)

            if uid:
                ttk.Label(
                    basic,text="اتركها فارغة إذا لم ترد تغييرها",
                    font=("Segoe UI",8)
                ).grid(row=2,column=0,sticky="e",padx=5)

            ttk.Label(basic,text="نوع المستخدم").grid(row=3,column=1,sticky="e",padx=5,pady=4)
            role=ttk.Combobox(basic,state="readonly",values=["employee","admin"])
            role.grid(row=3,column=0,sticky="ew",padx=5,pady=4)

            ttk.Label(basic,text="بريد الاستعادة").grid(row=4,column=1,sticky="e",padx=5,pady=4)
            email=ttk.Entry(basic,justify="left")
            email.grid(row=4,column=0,sticky="ew",padx=5,pady=4)

            ttk.Label(basic,text="رقم واتساب الاستعادة").grid(row=5,column=1,sticky="e",padx=5,pady=4)
            whatsapp=ttk.Entry(basic,justify="left")
            whatsapp.grid(row=5,column=0,sticky="ew",padx=5,pady=4)

            active=tk.BooleanVar(value=True if row is None else bool(row[5]))
            ttk.Checkbutton(
                basic,text="المستخدم فعال",variable=active
            ).grid(row=6,column=0,columnspan=2,sticky="e",pady=6)
            basic.columnconfigure(0,weight=1)

            if row:
                username.insert(0,row[1])
                role.set(row[2])
                email.insert(0,row[3] or "")
                whatsapp.insert(0,row[4] or "")
            else:
                role.set("employee")

            perms_box=ttk.LabelFrame(inner,text="الصلاحيات التفصيلية",padding=12)
            perms_box.pack(fill="x",pady=6)
            perm_vars={}
            for i,(key,label) in enumerate(PERMISSIONS):
                default = existing_perms.get(
                    key,
                    1 if (not uid and key in (
                        "operations","statements","accounts","customers",
                        "reports","reconcile","end_shift","share"
                    )) else 0
                )
                var=tk.BooleanVar(value=bool(default))
                perm_vars[key]=var
                ttk.Checkbutton(
                    perms_box,text=label,variable=var
                ).grid(row=i//2,column=i%2,sticky="e",padx=10,pady=4)
            perms_box.columnconfigure(0,weight=1)
            perms_box.columnconfigure(1,weight=1)

            ttk.Label(
                inner,
                text="المدير يملك جميع الصلاحيات دائماً لمنع قفل النظام على نفسه.",
                font=("Segoe UI",8)
            ).pack(anchor="e",pady=4)

            def save():
                uname=username.get().strip()
                pwd=password.get()
                r=role.get()
                if not uname:
                    messagebox.showwarning("تنبيه","اسم المستخدم مطلوب",parent=win)
                    return
                if not uid and not pwd:
                    messagebox.showwarning("تنبيه","كلمة المرور مطلوبة للمستخدم الجديد",parent=win)
                    return
                if pwd and len(pwd)<4:
                    messagebox.showwarning("تنبيه","اجعل كلمة المرور 4 أحرف/أرقام على الأقل",parent=win)
                    return

                conn=get_db(); cur=conn.cursor()
                try:
                    if uid:
                        if pwd:
                            cur.execute("""
                                UPDATE users
                                SET username=?,password=?,role=?,recovery_email=?,
                                    recovery_whatsapp=?,active=?
                                WHERE id=?
                            """,(
                                uname,hash_password(pwd),r,email.get().strip(),
                                whatsapp.get().strip(),1 if active.get() else 0,uid
                            ))
                        else:
                            cur.execute("""
                                UPDATE users
                                SET username=?,role=?,recovery_email=?,
                                    recovery_whatsapp=?,active=?
                                WHERE id=?
                            """,(
                                uname,r,email.get().strip(),whatsapp.get().strip(),
                                1 if active.get() else 0,uid
                            ))
                        target_id=uid
                    else:
                        cur.execute("""
                            INSERT INTO users(
                                username,password,role,recovery_email,
                                recovery_whatsapp,active
                            ) VALUES(?,?,?,?,?,?)
                        """,(
                            uname,hash_password(pwd),r,email.get().strip(),
                            whatsapp.get().strip(),1 if active.get() else 0
                        ))
                        target_id=cur.lastrowid

                    cur.execute("DELETE FROM user_permissions WHERE user_id=?",(target_id,))
                    for key,var in perm_vars.items():
                        cur.execute("""
                            INSERT INTO user_permissions(user_id,permission,allowed)
                            VALUES(?,?,?)
                        """,(target_id,key,1 if var.get() else 0))

                    conn.commit(); conn.close()
                    self.log(
                        "تعديل مستخدم" if uid else "إضافة مستخدم",
                        uname
                    )
                    win.destroy(); reload()
                except sqlite3.IntegrityError:
                    conn.rollback(); conn.close()
                    messagebox.showerror("خطأ","اسم المستخدم مستخدم مسبقاً",parent=win)
                except Exception as ex:
                    conn.rollback(); conn.close()
                    messagebox.showerror("خطأ",str(ex),parent=win)

            ttk.Button(
                inner,
                text="✅ حفظ المستخدم والصلاحيات",
                command=save
            ).pack(anchor="e",pady=12,ipadx=20,ipady=5)

            win.update_idletasks()
            self.bind_mousewheel_recursive(inner,canvas)
            self.enable_edit_shortcuts_recursive(inner)

        def selected_id():
            sel=tree.selection()
            if not sel:
                messagebox.showwarning("تنبيه","اختر مستخدماً أولاً")
                return None
            return int(tree.item(sel[0])["values"][0])

        bar=ttk.Frame(self.content); bar.pack(fill="x",pady=6)
        ttk.Button(
            bar,text="➕ إضافة مستخدم",
            command=lambda:open_editor(None)
        ).pack(side="right",padx=5)
        ttk.Button(
            bar,text="✏ تعديل المستخدم والصلاحيات",
            command=lambda:(lambda uid: open_editor(uid) if uid else None)(selected_id())
        ).pack(side="right",padx=5)

        reload()

def main():
    # ترقية قاعدة البيانات القديمة قبل فتح شاشة الدخول.
    init_db()

    root = tk.Tk()

    def start_app(username, role):
        for widget in root.winfo_children():
            widget.destroy()
        FinancialApp(root, username, role)

    LoginWindow(root, start_app)
    root.mainloop()


if __name__ == "__main__":
    main()


from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime

class LoginIn(BaseModel):
    username: str
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    username: str

class AccountOut(BaseModel):
    id: int
    name: str
    account_type: str
    balance_fils: int
    balance_jod: str
    active: bool

class AccountCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    account_type: str = "other"
    opening_balance_fils: int = Field(default=0, ge=0)
    warning_limit_fils: int = Field(default=0, ge=0)

class CustomerOut(BaseModel):
    id: int
    name: str
    phone: str = ""
    address: str = ""
    notes: str = ""
    debt_balance_fils: int
    debt_balance_jod: str
    debt_limit_fils: int
    debt_limit_jod: str
    active: bool

class TransactionCreate(BaseModel):
    client_tx_id: str = Field(min_length=8, max_length=64)
    op_type: str = Field(min_length=1, max_length=80)
    source_account_id: Optional[int] = None
    destination_account_id: Optional[int] = None
    amount_fils: int = Field(gt=0)
    commission_fils: int = Field(default=0, ge=0)
    commission_account_id: Optional[int] = None
    customer_id: Optional[int] = None
    details: str = ""

class TransactionOut(BaseModel):
    id: int
    client_tx_id: str
    created_at: datetime
    op_type: str
    amount_fils: int
    commission_fils: int
    status: str
    details: str

class SyncPushIn(BaseModel):
    items: list[TransactionCreate]

class SyncPushItemResult(BaseModel):
    client_tx_id: str
    status: Literal["created", "duplicate", "rejected"]
    transaction_id: Optional[int] = None
    message: str = ""

class SyncPushOut(BaseModel):
    results: list[SyncPushItemResult]


class TransactionReverseIn(BaseModel):
    reason: str = Field(min_length=1, max_length=500)

class TransactionEditIn(BaseModel):
    reason: str = Field(min_length=1, max_length=500)
    replacement: TransactionCreate

class AuditOut(BaseModel):
    id: int
    created_at: datetime
    username: str = ""
    action: str
    transaction_id: Optional[int] = None
    details: str = ""


class ShiftAccountSnapshotOut(BaseModel):
    account_id: int
    account_name: str
    system_balance_fils: int
    system_balance_jod: str

class ShiftCurrentOut(BaseModel):
    id: int
    business_date: str
    started_at: datetime
    status: str
    total_commission_fils: int
    total_commission_jod: str
    program_total_fils: int
    program_total_jod: str
    accounts: list[ShiftAccountSnapshotOut]

class ShiftCloseAccountIn(BaseModel):
    account_id: int
    actual_balance_fils: int = Field(ge=0)
    reason: str = Field(default="", max_length=500)

class ShiftCloseIn(BaseModel):
    accounts: list[ShiftCloseAccountIn] = Field(min_length=1)

class ShiftBalanceOut(BaseModel):
    account_id: int
    account_name: str
    system_balance_fils: int
    actual_balance_fils: int
    difference_fils: int
    reason: str = ""

class ShiftOut(BaseModel):
    id: int
    business_date: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    status: str
    total_commission_fils: int
    program_total_fils: int
    actual_total_fils: int
    difference_fils: int
    balances: list[ShiftBalanceOut] = []


class DeviceRegisterIn(BaseModel):
    device_id: str = Field(min_length=8, max_length=80)
    platform: Literal["windows", "android", "ios", "test"]
    device_name: str = Field(default="", max_length=120)
    app_version: str = Field(default="", max_length=40)

class DeviceOut(BaseModel):
    device_id: str
    platform: str
    device_name: str
    app_version: str
    last_tx_cursor: int
    active: bool

class MobileSyncPushIn(BaseModel):
    device_id: str = Field(min_length=8, max_length=80)
    items: list[TransactionCreate] = Field(default_factory=list)

class MobileSyncPullOut(BaseModel):
    server_cursor: int
    has_more: bool
    transactions: list[TransactionOut]

class MeOut(BaseModel):
    user_id: int
    username: str
    role: str
    server_time: datetime

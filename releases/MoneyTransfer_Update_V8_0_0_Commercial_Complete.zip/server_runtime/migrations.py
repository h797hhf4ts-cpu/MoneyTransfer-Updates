# -*- coding: utf-8 -*-
"""Small ordered migration runner. Add future migrations here; never edit old migrations."""
from sqlalchemy import text
from .database import engine

MIGRATIONS = [
    (1, "v7_8_1_update_foundation", [
        "CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
    ]),
    (2, "v7_9_0_safe_updater", [
        "CREATE TABLE IF NOT EXISTS update_history (id INTEGER PRIMARY KEY AUTOINCREMENT, version TEXT NOT NULL, status TEXT NOT NULL, details TEXT, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
    ]),
    (3, "v7_11_desktop_finalization", [
        "CREATE INDEX IF NOT EXISTS ix_transactions_created_at ON transactions(created_at)",
        "CREATE INDEX IF NOT EXISTS ix_ledger_entries_transaction_id ON ledger_entries(transaction_id)"
    ]),
    (4, "v7_12_mobile_phase2", [
        "CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY AUTOINCREMENT, device_id VARCHAR(80) NOT NULL UNIQUE, user_id INTEGER, platform VARCHAR(30) NOT NULL DEFAULT 'unknown', device_name VARCHAR(120) NOT NULL DEFAULT '', app_version VARCHAR(40) NOT NULL DEFAULT '', last_tx_cursor INTEGER NOT NULL DEFAULT 0, active BOOLEAN NOT NULL DEFAULT 1, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id))",
        "CREATE INDEX IF NOT EXISTS ix_devices_device_id ON devices(device_id)",
        "CREATE INDEX IF NOT EXISTS ix_devices_user_id ON devices(user_id)"
    ]),
    (5, "v7_20_mobile_phase2_complete", [
        "CREATE INDEX IF NOT EXISTS ix_devices_last_seen_at ON devices(last_seen_at)",
        "CREATE INDEX IF NOT EXISTS ix_transactions_shift_id ON transactions(shift_id)",
        "CREATE INDEX IF NOT EXISTS ix_transactions_customer_id ON transactions(customer_id)"
    ]),
    (6, "v7_60_production_foundation", [
        "CREATE TABLE IF NOT EXISTS system_meta (meta_key TEXT PRIMARY KEY, meta_value TEXT NOT NULL, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE INDEX IF NOT EXISTS ix_audit_log_created_at ON audit_log(created_at)",
        "CREATE INDEX IF NOT EXISTS ix_ledger_entries_account_id ON ledger_entries(account_id)"
    ]),
]

def apply_migrations():
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"))
        done={r[0] for r in conn.execute(text("SELECT version FROM schema_migrations"))}
        for version,name,statements in MIGRATIONS:
            if version in done: continue
            for sql in statements: conn.execute(text(sql))
            conn.execute(text("INSERT INTO schema_migrations(version,name) VALUES (:v,:n)"),{"v":version,"n":name})


import hashlib, hmac, secrets
from datetime import datetime, timedelta, timezone
import jwt
from .config import load_config

cfg = load_config()

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    iterations = 220_000
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        bytes.fromhex(salt),
        iterations
    ).hex()
    return f"pbkdf2_sha256${iterations}${salt}${digest}"

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, iterations, salt, digest = stored.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        candidate = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            bytes.fromhex(salt),
            int(iterations)
        ).hex()
        return hmac.compare_digest(candidate, digest)
    except Exception:
        return False

def create_token(user_id: int, username: str, role: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user_id),
        "username": username,
        "role": role,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(hours=int(cfg["token_hours"]))).timestamp()),
    }
    return jwt.encode(payload, cfg["jwt_secret"], algorithm="HS256")

def decode_token(token: str):
    return jwt.decode(token, cfg["jwt_secret"], algorithms=["HS256"])

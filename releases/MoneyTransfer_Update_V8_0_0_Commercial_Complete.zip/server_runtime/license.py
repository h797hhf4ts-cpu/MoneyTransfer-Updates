# -*- coding: utf-8 -*-
"""MoneyTransfer V8 offline signed licensing.
Only the RSA public key is embedded in the application. Seller private key is
kept in a separate Seller Tools package and must never be uploaded publicly.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import base64, hashlib, json, hmac
from .config import DATA_DIR

PUBLIC_N = 26031207819497271040040414992256321069717279611635441697492487623547676390698668318569693747929166878085695001876111667068118896791691011167439721229447808846937522023726724796335405846380231857248908971261277835609605067793892318612327775219321699369124316402214503725748403563760178325917536977063926954959375860345745803991875652152367748931378462148386992403444119362577744396042456344386291391526917564511840976993887783423721067234661153787524292410222086756710593573021271830805976574161899080552371481492248021607350000726215411130651486011500498935548861512993567977331683637980636553980653439398996230041239
PUBLIC_E = 65537
LICENSE_FILE = DATA_DIR / "license.json"
TRIAL_DAYS = 30
_SHA256_DI_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")

def _b64d(s):
    s=str(s).strip(); return base64.urlsafe_b64decode(s + "="*((4-len(s)%4)%4))

def _verify_signature(message, signature):
    k=(PUBLIC_N.bit_length()+7)//8
    if len(signature)!=k: return False
    em=pow(int.from_bytes(signature,'big'), PUBLIC_E, PUBLIC_N).to_bytes(k,'big')
    digest=hashlib.sha256(message).digest(); t=_SHA256_DI_PREFIX+digest
    if len(t)+11>k: return False
    expected=b"\x00\x01" + b"\xff"*(k-len(t)-3) + b"\x00" + t
    return hmac.compare_digest(em, expected)

def decode_and_verify(token):
    try:
        a,b=str(token or '').strip().split('.',1)
        payload_raw=_b64d(a); sig=_b64d(b)
        if not _verify_signature(payload_raw,sig): return None,"invalid_signature"
        payload=json.loads(payload_raw.decode('utf-8'))
        if payload.get('product')!='MoneyTransfer': return None,'wrong_product'
        return payload,None
    except Exception as exc: return None,'invalid_token'

def _parse_iso_date(value):
    if not value: return None
    try: return datetime.fromisoformat(str(value).replace('Z','+00:00')).date()
    except Exception:
        try: return datetime.strptime(str(value),'%Y-%m-%d').date()
        except Exception: return None

def license_status(installation):
    iid=str(installation.get('installation_id',''))
    token=''
    if LICENSE_FILE.exists():
        try: token=json.loads(LICENSE_FILE.read_text(encoding='utf-8-sig')).get('token','')
        except Exception: token=''
    if token:
        payload,err=decode_and_verify(token)
        if payload and str(payload.get('installation_id','')) in {iid,'*'}:
            exp=_parse_iso_date(payload.get('expires_at'))
            today=datetime.now(timezone.utc).date()
            active=(exp is None or exp>=today)
            return {'status':'active' if active else 'expired','activated':True,'valid':active,
                    'installation_id':iid,'customer':payload.get('customer',''),'shop_name':payload.get('shop_name',''),
                    'plan':payload.get('plan','Commercial'),'expires_at':payload.get('expires_at') or 'perpetual',
                    'issued_at':payload.get('issued_at',''),'license_id':payload.get('license_id',''),
                    'message':'الترخيص مفعل' if active else 'انتهت صلاحية الترخيص'}
        if payload:
            return {'status':'invalid','activated':False,'valid':False,'installation_id':iid,'message':'مفتاح التفعيل يخص تثبيتاً آخر'}
    started=str(installation.get('trial_started_at') or installation.get('created_at') or '')
    try: dt=datetime.fromisoformat(started.replace('Z','+00:00'))
    except Exception: dt=datetime.now(timezone.utc)
    if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
    end=(dt+timedelta(days=TRIAL_DAYS)).date(); today=datetime.now(timezone.utc).date(); days=(end-today).days
    return {'status':'trial' if days>=0 else 'trial_expired','activated':False,'valid':days>=0,'installation_id':iid,
            'trial_days_remaining':max(0,days),'trial_ends_at':end.isoformat(),
            'message':f'فترة تجريبية: {max(0,days)} يوم متبقٍ' if days>=0 else 'انتهت الفترة التجريبية'}

def activate_license(token, installation):
    payload,err=decode_and_verify(token)
    if not payload: raise ValueError('مفتاح التفعيل غير صالح أو التوقيع غير صحيح.')
    iid=str(installation.get('installation_id',''))
    if str(payload.get('installation_id','')) not in {iid,'*'}: raise ValueError('مفتاح التفعيل يخص جهازاً/تثبيتاً آخر.')
    exp=_parse_iso_date(payload.get('expires_at'))
    if exp is not None and exp < datetime.now(timezone.utc).date(): raise ValueError('مفتاح التفعيل منتهي الصلاحية.')
    LICENSE_FILE.write_text(json.dumps({'token':str(token).strip(),'activated_at':datetime.now(timezone.utc).isoformat(timespec='seconds')},ensure_ascii=False,indent=2),encoding='utf-8')
    return license_status(installation)

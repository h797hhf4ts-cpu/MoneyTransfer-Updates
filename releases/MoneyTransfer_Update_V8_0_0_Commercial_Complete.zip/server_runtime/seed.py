from datetime import datetime
from pathlib import Path
import os
import sqlite3
from sqlalchemy import select
from .database import Base, engine, SessionLocal
from .models import User, Account, Customer, Shift, Transaction, LedgerEntry
from .security import hash_password

DEFAULT_ACCOUNTS = [
    ("النقد كاش", "cash"),
    ("البنك الإسلامي", "bank"),
    ("البنك العربي", "bank"),
    ("محفظة أورنج موني", "wallet"),
    ("محفظة أورنج موني وكيل", "wallet"),
    ("محفظة أورنج موني وكيل RMEJ", "wallet"),
    ("إي فواتيركم", "bill"),
]

ROOT_DIR = Path(__file__).resolve().parents[1]
_legacy_override = os.environ.get("MONEYTRANSFER_DESKTOP_DB", "").strip()
LEGACY_DB = Path(_legacy_override).expanduser().resolve() if _legacy_override else (ROOT_DIR / "financial_pos.db")


def _legacy_snapshot():
    """Read the copied V6.9 database once to seed the new server safely."""
    if not LEGACY_DB.exists():
        return [], [], [], []
    conn = sqlite3.connect(str(LEGACY_DB))
    try:
        accounts = conn.execute(
            "SELECT name, account_type, balance, warning_limit, active FROM accounts ORDER BY id"
        ).fetchall()
        users = conn.execute(
            "SELECT username, password, role, active FROM users ORDER BY id"
        ).fetchall()
        customer_cols = {r[1] for r in conn.execute("PRAGMA table_info(customers)").fetchall()}
        if customer_cols:
            def col(name, fallback):
                return name if name in customer_cols else fallback
            customers = conn.execute(
                f"SELECT name, {col('phone', "''")}, {col('address', "''")}, "
                f"{col('notes', "''")}, debt_balance, {col('debt_limit', '0')}, "
                f"{col('active', '1')} FROM customers ORDER BY id"
            ).fetchall()
        else:
            customers = []
        tx_cols = {r[1] for r in conn.execute("PRAGMA table_info(transactions)").fetchall()}
        txs = []
        if tx_cols:
            txs = conn.execute("""
                SELECT id,created_at,op_type,source_account,destination_account,
                       amount,commission,commission_account,customer_name,details,status
                FROM transactions ORDER BY id
            """).fetchall()
        return accounts, users, customers, txs
    except sqlite3.Error:
        return [], [], [], []
    finally:
        conn.close()


def init_server_db():
    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        legacy_accounts, legacy_users, legacy_customers, legacy_txs = _legacy_snapshot()

        # Import users from the copied desktop database. Existing PBKDF2 hashes are compatible.
        if legacy_users:
            for username, password_hash, role, active in legacy_users:
                if not db.scalar(select(User).where(User.username == username)):
                    db.add(User(
                        username=username,
                        password_hash=password_hash,
                        role=role,
                        active=bool(active),
                    ))
        elif not db.scalar(select(User).where(User.username == "admin")):
            db.add(User(
                username="admin",
                password_hash=hash_password("admin123"),
                role="admin",
                active=True,
            ))

        # Import customers and their debt balances from the copied desktop database.
        if legacy_customers:
            for name, phone, address, notes, debt_balance, debt_limit, active in legacy_customers:
                if not db.scalar(select(Customer).where(Customer.name == name)):
                    db.add(Customer(
                        name=name,
                        phone=phone or "",
                        address=address or "",
                        notes=notes or "",
                        debt_balance_fils=int(round(float(debt_balance or 0) * 1000)),
                        debt_limit_fils=int(round(float(debt_limit or 0) * 1000)),
                        active=bool(active),
                    ))

        # First server start: seed balances from the copied V6.9 DB, converted to integer fils.
        existing_count = len(db.scalars(select(Account)).all())
        if existing_count == 0 and legacy_accounts:
            for name, typ, balance, warning_limit, active in legacy_accounts:
                db.add(Account(
                    name=name,
                    account_type=typ or "other",
                    balance_fils=int(round(float(balance or 0) * 1000)),
                    warning_limit_fils=int(round(float(warning_limit or 0) * 1000)),
                    active=bool(active),
                ))
        else:
            for name, typ in DEFAULT_ACCOUNTS:
                if not db.scalar(select(Account).where(Account.name == name)):
                    db.add(Account(
                        name=name,
                        account_type=typ,
                        balance_fils=0,
                        warning_limit_fils=0,
                        active=True,
                    ))


        # V7.8: import legacy transaction history once for server reports/statements.
        # Account balances are NOT changed here; they were already seeded from the current legacy snapshot.
        db.flush()
        if legacy_txs and not db.scalar(select(Transaction.id).limit(1)):
            account_by_name={a.name:a for a in db.scalars(select(Account)).all()}
            user_by_name={u.username:u for u in db.scalars(select(User)).all()}
            customer_by_name={c.name:c for c in db.scalars(select(Customer)).all()}
            def add_effect(effects,name,delta):
                if name and name in account_by_name:
                    effects[name]=effects.get(name,0)+int(round(float(delta)*1000))
            for lid,created_at,op,src,dst,amount,comm,comm_acc,cust,details,status in legacy_txs:
                try:
                    created=datetime.strptime(created_at,'%Y-%m-%d %H:%M:%S')
                except Exception:
                    created=datetime.now()
                tx=Transaction(
                    client_tx_id=f'legacy-{lid:010d}', created_at=created, op_type=op or '',
                    amount_fils=int(round(float(amount or 0)*1000)),
                    commission_fils=int(round(float(comm or 0)*1000)), details=details or '',
                    status=status or 'active', performed_by_id=(user_by_name.get('admin').id if user_by_name.get('admin') else None),
                    customer_id=(customer_by_name.get(cust).id if cust in customer_by_name else None),
                )
                db.add(tx); db.flush()
                if (status or 'active')!='active':
                    continue
                effects={}
                a=float(amount or 0); c=float(comm or 0)
                # Same accounting rules used by the legacy desktop statement engine.
                if op=='حوالة صادرة':
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                elif op=='حوالة واردة':
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                elif op=='دفع فاتورة':
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                elif op=='نقل أموال':
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                elif op=='بيع بطاقة خلوية':
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                elif op=='سحب مالي':
                    add_effect(effects,src,-a)
                elif op=='دين للعميل':
                    add_effect(effects,src,-a)
                elif op=='سداد دين':
                    add_effect(effects,dst or src,a)
                elif op and op.startswith('عكس:'):
                    # Reverse rows already encode source/destination and signed commission in legacy DB.
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                else:
                    add_effect(effects,src,-a); add_effect(effects,dst,a); add_effect(effects,comm_acc,c)
                for name,delta in effects.items():
                    if delta:
                        db.add(LedgerEntry(transaction_id=tx.id,account_id=account_by_name[name].id,amount_fils=delta,entry_type='legacy'))

        if not db.scalar(select(Shift).where(Shift.status == "open")):
            now = datetime.now()
            db.add(Shift(
                business_date=now.strftime("%Y-%m-%d"),
                started_at=now,
                status="open",
            ))

        db.commit()
    finally:
        db.close()

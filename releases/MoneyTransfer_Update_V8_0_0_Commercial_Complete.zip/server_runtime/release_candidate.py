# -*- coding: utf-8 -*-
"""Release-candidate diagnostics for MoneyTransfer.

V7.94 completes the RC integrity gate by separating accounting-only baseline rows from business-operation invariants.
MoneyTransfer records only the shop-side accounts, so withdrawals/debts/repayments
and commissions legitimately have a non-zero net ledger movement.
This module is read-only. No financial row is changed by diagnostics.
"""
from datetime import datetime
from sqlalchemy import text
from .database import engine, DATABASE_BACKEND, database_ping
from .production import readiness, list_backups, verify_backup, create_server_backup


def _rows(sql, params=None):
    try:
        with engine.connect() as c:
            return [dict(r._mapping) for r in c.execute(text(sql), params or {}).all()]
    except Exception:
        return []


def _scalar(sql, default=0, params=None):
    try:
        with engine.connect() as c:
            v = c.execute(text(sql), params or {}).scalar()
        return default if v is None else v
    except Exception:
        return default


def _expected_net(tx, original_sum=None):
    """Return (expected_fils, rule, confidence).

    The ledger stores shop-side account effects, not an external counterparty.
    Therefore zero-sum is NOT the invariant for every business operation.
    """
    op = str(tx.get("op_type") or "").strip()
    amount = int(tx.get("amount_fils") or 0)
    commission = int(tx.get("commission_fils") or 0)
    client_id = str(tx.get("client_tx_id") or "")

    # These rows are accounting/baseline records, not two-sided business transfers.
    # Legacy account balances were seeded from the current desktop snapshot and the
    # imported rows were added only for reports/statements; they did NOT alter balances.
    # Therefore their net movement must not be used as a commercial-release blocker.
    if op in {"تسوية رصيد", "رصيد افتتاحي", "مطابقة وردية"}:
        return None, "accounting_baseline", "high"

    if op.startswith("عكس:"):
        if original_sum is not None:
            return -int(original_sum), "mirror_original", "high"
        # Legacy reverse rows were imported from their already-signed account effects.
        if client_id.startswith("legacy-"):
            return commission, "legacy_reverse_signed", "medium"
        return None, "reverse_without_original", "low"
    if op == "سحب مالي":
        return -amount, "withdrawal_expense", "high"
    if op == "دين للعميل":
        return -amount, "customer_debt_outflow", "high"
    if op == "سداد دين":
        return amount, "customer_debt_repayment", "high"
    # Transfers, bills, internal transfer and card sale: source - amount,
    # destination + amount, commission destination + commission.
    return commission, "transfer_plus_commission", "high"


def financial_integrity_report(limit=500):
    """Detailed, read-only ledger diagnosis.

    Returns only structural inconsistencies as anomalies. Legitimate non-zero net
    movements are classified as expected and are not marked as failures.
    """
    limit = max(1, min(int(limit or 500), 2000))
    txs = _rows("""
        SELECT t.id, t.client_tx_id, t.created_at, t.op_type, t.amount_fils,
               t.commission_fils, t.status, t.reversed_transaction_id,
               COALESCE(SUM(le.amount_fils),0) AS ledger_sum_fils,
               COUNT(le.id) AS entry_count
        FROM transactions t
        LEFT JOIN ledger_entries le ON le.transaction_id=t.id
        GROUP BY t.id, t.client_tx_id, t.created_at, t.op_type, t.amount_fils,
                 t.commission_fils, t.status, t.reversed_transaction_id
        ORDER BY t.id DESC
        LIMIT :limit
    """, {"limit": limit})

    sums = {int(t["id"]): int(t.get("ledger_sum_fils") or 0) for t in txs}
    # Resolve reversal target sums even when target is outside the requested window.
    target_ids = sorted({int(t["reversed_transaction_id"]) for t in txs
                         if str(t.get("op_type") or "").startswith("عكس:") and t.get("reversed_transaction_id")})
    if target_ids:
        # Avoid database-specific array parameters; fetch individually (small bounded set).
        for tid in target_ids:
            if tid not in sums:
                sums[tid] = int(_scalar("SELECT COALESCE(SUM(amount_fils),0) FROM ledger_entries WHERE transaction_id=:id", 0, {"id": tid}))

    items = []
    for t in txs:
        txid = int(t["id"])
        actual = int(t.get("ledger_sum_fils") or 0)
        entries = int(t.get("entry_count") or 0)
        status = str(t.get("status") or "")
        original_sum = None
        if str(t.get("op_type") or "").startswith("عكس:") and t.get("reversed_transaction_id"):
            original_sum = sums.get(int(t["reversed_transaction_id"]))
        expected, rule, confidence = _expected_net(t, original_sum)

        # Historical cancelled/modified rows may intentionally have no imported entries.
        if entries == 0 and status != "active":
            state, reason = "historical_no_entries", "سجل تاريخي غير نشط بدون قيود؛ لا يغيّر الرصيد الحالي"
            ok = True
        elif entries == 0 and status == "active":
            state, reason, ok = "missing_entries", "عملية نشطة بلا أي قيد مالي", False
        elif expected is None and rule == "accounting_baseline":
            state, reason, ok = "accounting_baseline", "قيد محاسبي/افتتاحي أحادي الطرف؛ لا يُقاس بقاعدة التحويل التجاري ولا يمنع الإصدار", True
        elif expected is None:
            state, reason, ok = "needs_review", "تعذر اشتقاق الأثر المتوقع بأمان", False
        elif actual == expected:
            state, reason, ok = "consistent", "الأثر الفعلي يطابق قاعدة العملية", True
        else:
            state, reason, ok = "mismatch", f"الأثر الفعلي {actual} فلس، المتوقع {expected} فلس", False

        items.append({
            "transaction_id": txid,
            "client_tx_id": t.get("client_tx_id") or "",
            "created_at": str(t.get("created_at") or ""),
            "op_type": t.get("op_type") or "",
            "status": status,
            "amount_fils": int(t.get("amount_fils") or 0),
            "commission_fils": int(t.get("commission_fils") or 0),
            "ledger_sum_fils": actual,
            "expected_net_fils": expected,
            "entry_count": entries,
            "rule": rule,
            "confidence": confidence,
            "state": state,
            "ok": bool(ok),
            "reason": reason,
        })

    anomalies = [x for x in items if not x["ok"]]
    legacy = sum(1 for x in items if str(x.get("client_tx_id") or "").startswith("legacy-"))
    accounting_baseline = sum(1 for x in items if x.get("state") == "accounting_baseline")
    return {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "read_only": True,
        "scanned": len(items),
        "anomaly_count": len(anomalies),
        "consistent_count": len(items)-len(anomalies),
        "legacy_count": legacy,
        "accounting_baseline_count": accounting_baseline,
        "safe_to_auto_repair": False,
        "repair_policy": "diagnose_then_backup_then_explicit_review",
        "items": items,
        "anomalies": anomalies,
        "note": "لم يتم تعديل أي رصيد أو عملية. V7.94 يستبعد القيود المحاسبية الافتتاحية/التسويات من اختبار توازن التحويلات لأنها أحادية الطرف بطبيعتها.",
    }


def financial_invariants():
    report = financial_integrity_report(limit=2000)
    anomalies = int(report.get("anomaly_count", 0))
    checks=[]
    checks.append({
        "key":"ledger_consistent",
        "ok": anomalies == 0,
        "detail": f"true_anomalies={anomalies}; scanned={report.get('scanned',0)}",
    })
    orphan_entries=int(_scalar("SELECT COUNT(*) FROM ledger_entries le LEFT JOIN transactions t ON t.id=le.transaction_id WHERE t.id IS NULL",0))
    checks.append({"key":"no_orphan_ledger_entries","ok":orphan_entries==0,"detail":f"orphans={orphan_entries}"})
    duplicate_client=int(_scalar("SELECT COUNT(*) FROM (SELECT client_tx_id FROM transactions WHERE client_tx_id IS NOT NULL AND client_tx_id<>'' GROUP BY client_tx_id HAVING COUNT(*)>1) x",0))
    checks.append({"key":"idempotency_unique","ok":duplicate_client==0,"detail":f"duplicate_client_tx_id={duplicate_client}"})
    # Current model column is debt_balance_fils. Keep compatibility with earlier schema names.
    bad_debt = int(_scalar("SELECT COUNT(*) FROM customers WHERE debt_balance_fils < 0",0))
    checks.append({"key":"customer_debt_nonnegative","ok":bad_debt==0,"detail":f"negative_debts={bad_debt}"})
    return checks


def rc_report():
    prod=readiness(); db_ok,db_detail=database_ping(); fin=financial_invariants()
    backups=list_backups(200)
    backup_ok=False; backup_detail="count=0"
    # V7.94: opening the readiness center is allowed to create a backup because
    # this is a read-only safety action and removes a needless manual release gate.
    # No financial row is modified.
    if not backups:
        try:
            create_server_backup("rc-auto")
            backups=list_backups(200)
        except Exception as exc:
            backup_detail="auto-backup failed: "+str(exc)
    if backups:
        v=verify_backup(backups[0].get("file",""))
        backup_ok=bool(v.get("ok")); backup_detail=v.get("detail",backups[0].get("file","-"))
        if not backup_ok:
            try:
                create_server_backup("rc-repair")
                backups=list_backups(200)
                v=verify_backup(backups[0].get("file","")) if backups else {"ok":False,"detail":"count=0"}
                backup_ok=bool(v.get("ok")); backup_detail=v.get("detail",backup_detail)
            except Exception as exc:
                backup_detail="backup verify/repair failed: "+str(exc)
    checks=[
        {"key":"database_ping","ok":bool(db_ok),"detail":db_detail},
        {"key":"production_readiness","ok":bool(prod.get("ready_for_current_single_server")),"detail":DATABASE_BACKEND},
        {"key":"backup_exists","ok":bool(backups),"severity":"error","detail":f"count={len(backups)}"},
        {"key":"backup_verified","ok":backup_ok,"severity":"error","detail":backup_detail},
    ] + fin
    passed=sum(1 for x in checks if x["ok"]); total=len(checks)
    return {
        "generated_at":datetime.now().isoformat(timespec="seconds"),
        "release_candidate":True,
        "score":round((passed/total)*100) if total else 0,
        "passed":passed,"total":total,
        "commercial_release_ready":all(x["ok"] for x in checks),
        "checks":checks,
        "notes":[
            "V7.94 uses operation-aware ledger integrity rules and auto-creates a verified server backup at the V8 readiness gate and does not treat accounting-only baseline rows as transfer errors.",
            "Financial diagnostics are read-only and never change balances automatically.",
            "PostgreSQL activation, commercial licensing and signed native mobile packages remain separate release gates."
        ]
    }

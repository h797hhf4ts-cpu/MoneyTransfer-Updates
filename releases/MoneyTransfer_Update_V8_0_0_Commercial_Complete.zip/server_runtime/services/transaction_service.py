from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import Account, Customer, Transaction, LedgerEntry, Shift, AuditLog
from ..schemas import TransactionCreate


def _get_account(db: Session, account_id: int | None):
    if account_id is None:
        return None
    return db.get(Account, account_id)


def create_transaction(db: Session, payload: TransactionCreate, user_id: int | None):
    duplicate = db.scalar(
        select(Transaction).where(Transaction.client_tx_id == payload.client_tx_id)
    )
    if duplicate:
        return duplicate, "duplicate"

    src = _get_account(db, payload.source_account_id)
    dst = _get_account(db, payload.destination_account_id)
    comm_acc = _get_account(db, payload.commission_account_id)
    customer = db.get(Customer, payload.customer_id) if payload.customer_id is not None else None

    if payload.source_account_id is not None and not src:
        raise ValueError("Source account not found")
    if payload.destination_account_id is not None and not dst:
        raise ValueError("Destination account not found")
    if payload.commission_account_id is not None and not comm_acc:
        raise ValueError("Commission account not found")
    if payload.customer_id is not None and not customer:
        raise ValueError("Customer not found")
    if src and dst and src.id == dst.id and payload.op_type != "بيع بطاقة خلوية":
        raise ValueError("Source and destination accounts must be different")

    effects: dict[int, int] = {}
    customer_delta = 0

    def add_effect(account: Account | None, amount: int):
        if account is not None:
            effects[account.id] = effects.get(account.id, 0) + amount

    if payload.op_type == "سحب مالي":
        if src is None or dst is not None:
            raise ValueError("Expense withdrawal requires source only")
        if payload.commission_fils != 0 or comm_acc is not None:
            raise ValueError("Expense withdrawal never uses commission")
        if customer is not None:
            raise ValueError("Expense withdrawal does not use a customer")
        add_effect(src, -payload.amount_fils)

    elif payload.op_type == "دين للعميل":
        if src is None or dst is not None:
            raise ValueError("Customer debt requires source account only")
        if customer is None or not customer.active:
            raise ValueError("Active customer is required for debt")
        if payload.commission_fils != 0 or comm_acc is not None:
            raise ValueError("Customer debt does not use commission")
        new_debt = customer.debt_balance_fils + payload.amount_fils
        if customer.debt_limit_fils > 0 and new_debt > customer.debt_limit_fils:
            raise ValueError(
                f"Customer debt limit exceeded. limit={customer.debt_limit_fils} fils, "
                f"after={new_debt} fils"
            )
        add_effect(src, -payload.amount_fils)
        customer_delta = payload.amount_fils

    elif payload.op_type == "سداد دين":
        if src is not None or dst is None:
            raise ValueError("Debt repayment requires destination account only")
        if customer is None or not customer.active:
            raise ValueError("Active customer is required for repayment")
        if payload.commission_fils != 0 or comm_acc is not None:
            raise ValueError("Debt repayment does not use commission")
        if payload.amount_fils > customer.debt_balance_fils:
            raise ValueError(
                f"Repayment exceeds customer debt. debt={customer.debt_balance_fils} fils"
            )
        add_effect(dst, +payload.amount_fils)
        customer_delta = -payload.amount_fils

    elif payload.op_type == "بيع بطاقة خلوية":
        if src is None or dst is None:
            raise ValueError("Card sale requires source and destination accounts")
        if customer is not None:
            raise ValueError("Card sale does not use debt customer")
        add_effect(src, -payload.amount_fils)
        add_effect(dst, +payload.amount_fils)
        if payload.commission_fils:
            if comm_acc is None:
                raise ValueError("Commission account is required")
            add_effect(comm_acc, +payload.commission_fils)

    else:
        if src is None or dst is None:
            raise ValueError("This operation requires source and destination accounts")
        if customer is not None:
            raise ValueError("This operation does not use debt customer")
        add_effect(src, -payload.amount_fils)
        add_effect(dst, +payload.amount_fils)
        if payload.commission_fils:
            if comm_acc is None:
                raise ValueError("Commission account is required")
            add_effect(comm_acc, +payload.commission_fils)

    accounts_by_id = {}
    for account_id, delta in effects.items():
        acc = db.get(Account, account_id)
        accounts_by_id[account_id] = acc
        if acc.balance_fils + delta < 0:
            raise ValueError(
                f"Insufficient balance in account '{acc.name}'. "
                f"Current={acc.balance_fils} fils, required={abs(delta)} fils"
            )

    open_shift = db.scalar(
        select(Shift).where(Shift.status == "open").order_by(Shift.id.desc())
    )

    tx = Transaction(
        client_tx_id=payload.client_tx_id,
        op_type=payload.op_type,
        amount_fils=payload.amount_fils,
        commission_fils=payload.commission_fils,
        details=payload.details,
        performed_by_id=user_id,
        shift_id=open_shift.id if open_shift else None,
        customer_id=customer.id if customer else None,
        status="active",
    )
    db.add(tx)
    db.flush()

    for account_id, amount in effects.items():
        db.add(LedgerEntry(
            transaction_id=tx.id,
            account_id=account_id,
            amount_fils=amount,
            entry_type="commission" if (
                payload.commission_fils and
                payload.commission_account_id == account_id and
                amount == payload.commission_fils
            ) else "movement"
        ))
        accounts_by_id[account_id].balance_fils += amount

    if customer is not None and customer_delta:
        customer.debt_balance_fils += customer_delta

    db.commit()
    db.refresh(tx)
    return tx, "created"


def reverse_transaction(db: Session, tx_id: int, reason: str, user_id: int | None, final_status: str = "cancelled"):
    tx = db.get(Transaction, tx_id)
    if not tx:
        raise ValueError("Transaction not found")
    if tx.status != "active":
        raise ValueError("Transaction is not active and cannot be reversed again")
    entries = list(db.scalars(select(LedgerEntry).where(LedgerEntry.transaction_id == tx.id)).all())
    if not entries:
        raise ValueError("Transaction has no ledger entries")
    # Validate reverse balances before changing anything.
    for entry in entries:
        acc = db.get(Account, entry.account_id)
        reverse_delta = -entry.amount_fils
        if acc.balance_fils + reverse_delta < 0:
            raise ValueError(f"Cannot reverse because account '{acc.name}' would become negative")
    customer = db.get(Customer, tx.customer_id) if tx.customer_id else None
    customer_reverse = 0
    if customer:
        if tx.op_type == "دين للعميل": customer_reverse = -tx.amount_fils
        elif tx.op_type == "سداد دين": customer_reverse = tx.amount_fils
        if customer.debt_balance_fils + customer_reverse < 0:
            raise ValueError("Cannot reverse because customer debt would become negative")
    open_shift = db.scalar(select(Shift).where(Shift.status == "open").order_by(Shift.id.desc()))
    rev = Transaction(
        client_tx_id=f"reverse-{tx.id}-{__import__('uuid').uuid4().hex}",
        op_type="عكس: " + tx.op_type, amount_fils=tx.amount_fils,
        commission_fils=-tx.commission_fils, details=f"عكس العملية #{tx.id} | السبب: {reason}",
        performed_by_id=user_id, shift_id=open_shift.id if open_shift else None,
        reversed_transaction_id=tx.id, customer_id=tx.customer_id, status="active")
    db.add(rev); db.flush()
    for entry in entries:
        acc=db.get(Account,entry.account_id); delta=-entry.amount_fils
        acc.balance_fils += delta
        db.add(LedgerEntry(transaction_id=rev.id, account_id=entry.account_id, amount_fils=delta, entry_type="reversal"))
    if customer and customer_reverse: customer.debt_balance_fils += customer_reverse
    tx.status=final_status; tx.reversed_transaction_id=rev.id
    db.add(AuditLog(user_id=user_id, action="cancel" if final_status=="cancelled" else "edit_reverse", transaction_id=tx.id, details=reason))
    db.commit(); db.refresh(rev)
    return tx, rev

def edit_transaction_server(db: Session, tx_id: int, replacement, reason: str, user_id: int | None):
    # Atomic behavior: reverse old, then create replacement; rollback all if replacement fails.
    tx=db.get(Transaction,tx_id)
    if not tx or tx.status != "active": raise ValueError("Transaction is not active")
    # Inline reverse without commit by temporarily using nested transaction logic.
    entries=list(db.scalars(select(LedgerEntry).where(LedgerEntry.transaction_id==tx.id)).all())
    if not entries: raise ValueError("Transaction has no ledger entries")
    for e in entries:
        acc=db.get(Account,e.account_id)
        if acc.balance_fils-e.amount_fils < 0: raise ValueError(f"Cannot edit because account '{acc.name}' would become negative while reversing old transaction")
    customer=db.get(Customer,tx.customer_id) if tx.customer_id else None
    cdelta=0
    if customer:
        if tx.op_type=="دين للعميل": cdelta=-tx.amount_fils
        elif tx.op_type=="سداد دين": cdelta=tx.amount_fils
        if customer.debt_balance_fils+cdelta < 0: raise ValueError("Cannot edit because customer debt would become negative")
    for e in entries: db.get(Account,e.account_id).balance_fils -= e.amount_fils
    if customer and cdelta: customer.debt_balance_fils += cdelta
    tx.status="modified"
    # create replacement using same session logic manually after flushing old state; create_transaction commits.
    db.flush()
    newtx,state=create_transaction(db,replacement,user_id)
    if state=="duplicate": raise ValueError("Replacement client_tx_id already exists")
    tx.reversed_transaction_id=newtx.id
    db.add(AuditLog(user_id=user_id, action="edit", transaction_id=tx.id, details=f"replacement={newtx.id} | {reason}"))
    db.commit(); db.refresh(newtx)
    return tx,newtx

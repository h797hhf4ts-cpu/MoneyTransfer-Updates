const $=id=>document.getElementById(id);
// Always call the API on the same host/port that served the mobile UI.
// This avoids stale/incorrect localhost addresses on iPhone/Android.
const API=''; // same-origin: /mobile and /api are served by the same FastAPI server
const OPS=['حوالة صادرة','حوالة واردة','دفع فاتورة','نقل أموال','بيع بطاقة خلوية','سحب مالي','دين للعميل','سداد دين'];
let state={token:localStorage.mt_token||'',user:null,accounts:[],customers:[],shift:null,cursor:+(localStorage.mt_cursor||0),caps:null,lastResults:[]};
let deferredInstall=null;
function makeUuid(){
  // crypto.randomUUID() is unavailable on iPhone/Android when the app is served over plain HTTP on a LAN.
  // Use it when available, otherwise generate a UUID-compatible id with getRandomValues (or a last-resort PRNG).
  if(globalThis.crypto && typeof globalThis.crypto.randomUUID==='function') return globalThis.crypto.randomUUID();
  let bytes=new Uint8Array(16);
  if(globalThis.crypto && typeof globalThis.crypto.getRandomValues==='function') globalThis.crypto.getRandomValues(bytes);
  else for(let i=0;i<16;i++) bytes[i]=Math.floor(Math.random()*256);
  bytes[6]=(bytes[6]&0x0f)|0x40; bytes[8]=(bytes[8]&0x3f)|0x80;
  const hex=[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}
const deviceId=()=>{let d=localStorage.mt_device;if(!d){d='web-'+makeUuid().replaceAll('-','');localStorage.mt_device=d}return d};
const queue=()=>{try{return JSON.parse(localStorage.mt_queue||'[]')}catch{return[]}};
const saveQueue=q=>{localStorage.mt_queue=JSON.stringify(q);updateQueue()};
function fils(v){let n=Number(String(v||'0').replaceAll(',','').replace('JD','').trim());if(!Number.isFinite(n))throw Error('المبلغ غير صحيح');return Math.round(n*1000)}
function money(v){return (Number(v||0)/1000).toLocaleString('en-US',{minimumFractionDigits:3,maximumFractionDigits:3})+' JD'}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function toast(t){let x=$('toast');x.textContent=t;x.style.display='block';clearTimeout(window._toast);window._toast=setTimeout(()=>x.style.display='none',3000)}
async function req(path,opt={}){let h={'Content-Type':'application/json',...(opt.headers||{})};if(state.token)h.Authorization='Bearer '+state.token;let r;try{r=await fetch(API+path,{...opt,headers:h,cache:'no-store'})}catch(e){throw Error('تعذر الوصول إلى السيرفر '+location.origin+' — '+(e&&e.message?e.message:'fetch failed'))}let data=await r.json().catch(()=>({}));if(!r.ok)throw Error(data.detail||data.message||('HTTP '+r.status));return data}
function setNet(ok){$('netBadge').textContent=ok?'متصل':'بدون اتصال';$('netBadge').className='badge '+(ok?'ok':'off');$('serverState').textContent=ok?'متصل':'Offline'}
function setTheme(mode){document.body.classList.toggle('dark',mode==='dark');localStorage.mt_theme=mode;$('themeBtn')&&($('themeBtn').textContent=mode==='dark'?'☀':'◐')}
async function login(){try{$('loginStatus').textContent='جارٍ الاتصال...';let d=await req('/api/v1/auth/login',{method:'POST',body:JSON.stringify({username:$('username').value.trim(),password:$('password').value})});state.token=d.access_token;localStorage.mt_token=state.token;await startApp()}catch(e){$('loginStatus').textContent=e.message}}
function platform(){if(/iPhone|iPad|iPod/.test(navigator.userAgent))return'ios';if(/Android/.test(navigator.userAgent))return'android';return'test'}
async function register(){return req('/api/v2/devices/register',{method:'POST',body:JSON.stringify({device_id:deviceId(),platform:platform(),device_name:navigator.platform||'Mobile',app_version:'8.0.0'})})}
async function bootstrap(){await register();let b=await req('/api/v2/mobile/bootstrap?device_id='+encodeURIComponent(deviceId()));state.user=b.user;state.accounts=b.accounts;state.customers=b.customers;state.shift=b.shift;state.caps=await req('/api/v2/mobile/capabilities').catch(()=>null);localStorage.mt_bootstrap=JSON.stringify({user:state.user,accounts:state.accounts,customers:state.customers,shift:state.shift,caps:state.caps});renderCached();return b}
async function startApp(){try{await req('/api/v1/health');await bootstrap();$('loginView').classList.add('hidden');$('appView').classList.remove('hidden');setNet(true);await syncNow(false)}catch(e){if(/401|token|expired|disabled|Invalid username/i.test(e.message)){logout()}else{setNet(false);if($('syncLog'))$('syncLog').textContent='Connection error: '+e.message+' | Origin: '+location.origin;if(state.token){$('loginView').classList.add('hidden');$('appView').classList.remove('hidden');renderCached()}}}}
function renderCached(){let c={};try{c=JSON.parse(localStorage.mt_bootstrap||'{}')}catch{};state.user=state.user||c.user;state.accounts=state.accounts.length?state.accounts:(c.accounts||[]);state.customers=state.customers.length?state.customers:(c.customers||[]);state.shift=state.shift||c.shift;state.caps=state.caps||c.caps;$('userInfo').textContent=state.user?state.user.username+' | '+state.user.role:'';$('deviceId').textContent=deviceId();$('cursor').textContent=state.cursor;$('shiftNo').textContent=state.shift?.id||'-';let total=state.accounts.reduce((s,a)=>s+Number(a.balance_fils||0),0);$('totalBalance').textContent=money(total);let rows=state.accounts.map(a=>`<div class="row"><div><b>${esc(a.name)}</b><br><small>${esc(a.type||'')}</small></div><div class="money">${money(a.balance_fils)}</div></div>`).join('');$('homeAccounts').innerHTML=rows;renderCustomerList();fillSelects();updateQueue();renderShiftBasic();loadMobileDashboard().catch(()=>{})}
function fillSelects(){let o=state.accounts.map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join('');['source','destination','commissionAccount','statementAccount'].forEach(id=>$(id).innerHTML=o);$('customer').innerHTML=state.customers.map(c=>`<option value="${c.id}">${esc(c.name)} — ${money(c.debt_balance_fils)}</option>`).join('');$('historyOp').innerHTML='<option value="">كل العمليات</option>'+OPS.map(x=>`<option>${x}</option>`).join('');opChanged()}
function opChanged(){let op=$('opType').value,debt=op==='دين للعميل',repay=op==='سداد دين',exp=op==='سحب مالي';$('srcWrap').classList.toggle('hidden',repay);$('dstWrap').classList.toggle('hidden',debt||exp);$('commWrap').classList.toggle('hidden',debt||repay||exp);$('custWrap').classList.toggle('hidden',!(debt||repay));if(debt||repay||exp)$('commission').value='0.000';previewTx()}
function txPayload(){let op=$('opType').value,debt=op==='دين للعميل',repay=op==='سداد دين',exp=op==='سحب مالي';let comm=(debt||repay||exp)?0:fils($('commission').value);let src=repay?null:+$('source').value,dst=(debt||exp)?null:+$('destination').value,cust=(debt||repay)?+$('customer').value:null;let p={client_tx_id:'mob-'+makeUuid().replaceAll('-',''),op_type:op,source_account_id:src,destination_account_id:dst,amount_fils:fils($('amount').value),commission_fils:comm,commission_account_id:(debt||repay||exp||comm===0)?null:+$('commissionAccount').value,customer_id:cust,details:$('details').value.trim()};if(p.amount_fils<=0)throw Error('أدخل مبلغاً أكبر من صفر');if(src&&dst&&src===dst&&op!=='بيع بطاقة خلوية')throw Error('حساب المصدر والوجهة يجب أن يكونا مختلفين');if((debt||repay)&&!cust)throw Error('اختر العميل');if(comm>0&&!p.commission_account_id)throw Error('اختر حساب العمولة');return p}
function accName(id){return state.accounts.find(a=>a.id===+id)?.name||'-'}
function transactionEffects(p){let e={};const add=(id,v)=>{if(id)e[id]=(e[id]||0)+v};if(p.op_type==='سحب مالي'||p.op_type==='دين للعميل'){add(p.source_account_id,-p.amount_fils)}else if(p.op_type==='سداد دين'){add(p.destination_account_id,p.amount_fils)}else{add(p.source_account_id,-p.amount_fils);add(p.destination_account_id,p.amount_fils);if(p.commission_fils)add(p.commission_account_id,p.commission_fils)}return e}
function renderEffects(p){let e=transactionEffects(p);let rows=Object.entries(e).filter(([,v])=>v!==0).map(([id,v])=>`<div class="effect-row"><span>${esc(accName(id))}</span><b class="${v>=0?'effect-plus':'effect-minus'}">${v>=0?'+':''}${money(v)}</b></div>`);if((p.op_type==='دين للعميل'||p.op_type==='سداد دين')&&p.customer_id){let c=state.customers.find(x=>x.id===+p.customer_id);let d=p.op_type==='دين للعميل'?p.amount_fils:-p.amount_fils;rows.push(`<div class="effect-row"><span>دين ${esc(c?.name||'العميل')}</span><b class="${d>=0?'effect-minus':'effect-plus'}">${d>=0?'+':''}${money(d)}</b></div>`)}$('txEffects').innerHTML=rows.join('')}
function previewTx(){try{let p=txPayload();let txt=`${p.op_type} | المبلغ ${money(p.amount_fils)}`;if(p.commission_fils)txt+=` | العمولة ${money(p.commission_fils)}`;$('txPreview').textContent=txt;renderEffects(p)}catch(e){$('txPreview').textContent=e.message||'';$('txEffects').innerHTML=''}}
async function saveTx(){let btn=$('saveTx');if(btn.disabled)return;try{let p=txPayload();renderEffects(p);let effects=Object.entries(transactionEffects(p)).filter(([,v])=>v!==0).map(([id,v])=>`${accName(id)} ${v>=0?'+':''}${money(v)}`).join('\n');let msg=`تأكيد العملية\n${p.op_type} — ${money(p.amount_fils)}${p.commission_fils?`\nالعمولة: ${money(p.commission_fils)}`:''}\n\nالتأثير المتوقع:\n${effects}`;if(!confirm(msg))return;btn.disabled=true;btn.textContent='جارٍ الحفظ...';let q=queue();q.push({...p,_queued_at:new Date().toISOString()});saveQueue(q);toast(navigator.onLine?'جارٍ إرسال العملية للسيرفر':'تم حفظ العملية محليًا حتى عودة الاتصال');await syncNow(false);$('amount').value='';$('details').value='';previewTx()}catch(e){toast(e.message)}finally{btn.disabled=false;btn.textContent='حفظ العملية'}}
async function syncNow(show=true){try{setNet(true);let q=queue();if(q.length){let out=await req('/api/v2/sync/push',{method:'POST',body:JSON.stringify({device_id:deviceId(),items:q})});state.lastResults=out.results;localStorage.mt_last_results=JSON.stringify(out.results);let ok=new Set(out.results.filter(x=>x.status==='created'||x.status==='duplicate').map(x=>x.client_tx_id));saveQueue(q.filter(x=>!ok.has(x.client_tx_id)));$('syncLog').textContent=out.results.map(x=>(x.status==='created'?'تم':x.status==='duplicate'?'مكرر بأمان':'مرفوض')+' | '+x.client_tx_id+' | '+(x.message||'')).join('\n')}
 let pull=await req('/api/v2/sync/pull?device_id='+encodeURIComponent(deviceId())+'&after_id='+state.cursor+'&limit=200');state.cursor=pull.server_cursor;localStorage.mt_cursor=String(state.cursor);await bootstrap();$('cursor').textContent=state.cursor;if(show)toast('اكتملت المزامنة');loadMobileDashboard().catch(()=>{});refreshSyncStatus().catch(()=>{});loadMobileDashboard().catch(()=>{})}catch(e){setNet(false);$('syncLog').textContent='Offline: '+e.message;if(show)toast('تعذر الاتصال — العمليات محفوظة على الجهاز')}}
function clearRejected(){let rejected=new Set((state.lastResults||[]).filter(x=>x.status==='rejected').map(x=>x.client_tx_id));if(!rejected.size){toast('لا توجد عمليات مرفوضة معروفة');return}if(!confirm('حذف العمليات المرفوضة من قائمة الانتظار؟ لن يتم حذف أي عملية مسجلة في السيرفر.'))return;saveQueue(queue().filter(x=>!rejected.has(x.client_tx_id)));toast('تم حذف العمليات المرفوضة من قائمة الانتظار')}
function updateQueue(){let n=queue().length;$('queueCount').textContent=n;$('pending').textContent=n;if($('queueHealth'))$('queueHealth').textContent=n?('يوجد '+n+' عملية بانتظار الإرسال'):'لا توجد عمليات معلقة'}
async function loadHistory(){try{let op=$('historyOp').value,status=$('historyStatus').value;let d=await req('/api/v2/mobile/transactions?limit=200&op_type='+encodeURIComponent(op)+'&status='+encodeURIComponent(status));localStorage.mt_history=JSON.stringify(d);renderHistory(d);setNet(true)}catch(e){let d={items:[]};try{d=JSON.parse(localStorage.mt_history||'{"items":[]}')}catch{};renderHistory(d);toast('عرض آخر سجل محفوظ — لا يوجد اتصال')}}
function renderHistory(d){let admin=state.user?.role==='admin';$('historyList').innerHTML=(d.items||[]).map(t=>{let moves=(t.movements||[]).map(m=>`${m.amount_fils>=0?'+':''}${money(m.amount_fils)} ${esc(m.account_name)}`).join(' • ');return `<div class="tx-card"><div class="tx-main"><b>#${t.id} — ${esc(t.op_type)}</b><div class="tx-meta"><span class="tag ${t.status==='active'?'ok':'bad'}">${esc(t.status)}</span><span class="tag">${money(t.amount_fils)}</span><span class="tag">عمولة ${money(t.commission_fils)}</span></div><small>${new Date(t.created_at).toLocaleString('ar-JO')}</small><div class="movement">${esc(moves)}</div>${t.customer_name?`<div class="movement">العميل: ${esc(t.customer_name)}</div>`:''}${t.details?`<div class="movement">${esc(t.details)}</div>`:''}${admin&&t.status==='active'?`<button class="admin-action" onclick="reverseTx(${t.id})">إلغاء / عكس</button>`:''}</div></div>`}).join('')||'<div class="muted">لا توجد عمليات</div>'}
async function reverseTx(id){let reason=prompt('اكتب سبب الإلغاء / العكس:');if(!reason)return;try{await req('/api/v2/mobile/transactions/'+id+'/reverse',{method:'POST',body:JSON.stringify({reason})});toast('تم عكس العملية');await syncNow(false);await loadHistory()}catch(e){toast(e.message)}}
async function loadStatement(){try{let id=+$('statementAccount').value,d=await req('/api/v2/mobile/account-statement?account_id='+id+'&limit=400');localStorage.mt_statement=JSON.stringify(d);renderStatement(d)}catch(e){toast(e.message)}}
function renderStatement(d){$('statementSummary').innerHTML=`<b>${esc(d.account?.name||'')}</b> — الرصيد الحالي <span class="money">${money(d.account?.balance_fils||0)}</span>`;$('statementList').innerHTML=(d.items||[]).map(x=>`<div class="row"><div><b>#${x.transaction_id} ${esc(x.op_type)}</b><br><small>${new Date(x.created_at).toLocaleString('ar-JO')} ${x.details?'— '+esc(x.details):''}</small></div><div class="money">${x.amount_fils>=0?'+':''}${money(x.amount_fils)}</div></div>`).join('')||'<div class="muted">لا توجد حركات</div>'}
async function loadReport(){try{let f=$('reportFrom').value,t=$('reportTo').value,d=await req('/api/v2/mobile/report-summary?date_from='+encodeURIComponent(f)+'&date_to='+encodeURIComponent(t));$('rCount').textContent=d.commercial_count;$('rVolume').textContent=money(d.commercial_amount_fils);$('rComm').textContent=money(d.net_commission_fils);$('rAccounting').textContent=d.accounting_count;$('reportList').innerHTML=(d.groups||[]).map(g=>`<div class="row"><div><b>${esc(g.op_type)}</b><br><small>${esc(g.category)} — ${g.count} عملية</small></div><div class="money">${money(g.amount_fils)}<br><small>ربح ${money(g.commission_fils)}</small></div></div>`).join('')}catch(e){toast(e.message)}}
function renderShiftBasic(){if(!state.shift){$('shiftInfo').textContent='لا توجد وردية مفتوحة';return}$('shiftInfo').innerHTML=`الوردية <b>#${state.shift.id}</b> — تاريخ العمل ${esc(state.shift.business_date||'')}<br><small>بدأت: ${state.shift.started_at?new Date(state.shift.started_at).toLocaleString('ar-JO'):'-'}</small>`}
async function loadShift(){try{let s=await req('/api/v2/mobile/shift');state.shift=s;renderShiftBasic();$('shiftAccounts').innerHTML=s.accounts.map(a=>`<div class="row"><div>${esc(a.account_name)}</div><div class="money">${money(a.system_balance_fils)}</div></div>`).join('');let admin=state.user?.role==='admin';$('closeShiftBox').classList.toggle('hidden',!admin);if(admin)$('shiftCloseInputs').innerHTML=s.accounts.map(a=>`<div class="shift-input" data-id="${a.account_id}" data-system="${a.system_balance_fils}"><div><label>${esc(a.account_name)}</label><input class="actual" inputmode="decimal" value="${(a.system_balance_fils/1000).toFixed(3)}"></div><div><label>الفرق</label><div class="money diff">0.000 JD</div></div><div class="wide"><label>السبب عند وجود فرق</label><input class="reason" placeholder="سبب الفرق"></div></div>`).join('');let h=await req('/api/v2/mobile/shifts?limit=20');$('shiftHistory').innerHTML=h.map(x=>`<div class="row"><div><b>وردية #${x.id}</b><br><small>${esc(x.business_date)} — ${x.status}</small></div><div class="money">فرق ${x.difference_fils>=0?'+':''}${money(x.difference_fils)}</div></div>`).join('');bindShiftInputs()}catch(e){toast(e.message)}}
function bindShiftInputs(){document.querySelectorAll('.shift-input .actual').forEach(inp=>inp.oninput=()=>{let box=inp.closest('.shift-input'),sys=+box.dataset.system;try{let d=fils(inp.value)-sys;box.querySelector('.diff').textContent=(d>=0?'+':'')+money(d)}catch{}})}
async function closeShift(){if(!confirm('هل تريد إنهاء الوردية بعد مراجعة الأرصدة الفعلية؟'))return;try{let accounts=[...document.querySelectorAll('.shift-input')].map(box=>({account_id:+box.dataset.id,actual_balance_fils:fils(box.querySelector('.actual').value),reason:box.querySelector('.reason').value.trim()}));let out=await req('/api/v2/mobile/shifts/'+state.shift.id+'/close',{method:'POST',body:JSON.stringify({accounts})});toast('تم إنهاء الوردية #'+out.id);await syncNow(false);await loadShift()}catch(e){toast(e.message)}}
function page(name){document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===name));document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));$('page-'+name).classList.remove('hidden');if(name==='history')loadHistory();if(name==='statement')loadStatement();if(name==='reports')loadReport();if(name==='shift')loadShift();if(name==='customers')renderCustomerList();if(name==='sync'){loadSyncStatus();loadDevices()}}
function logout(){localStorage.removeItem('mt_token');state.token='';location.reload()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>page(b.dataset.page));
$('loginBtn').onclick=login;$('password').onkeydown=e=>{if(e.key==='Enter')login()};$('opType').onchange=opChanged;['amount','commission'].forEach(id=>$(id).oninput=previewTx);['source','destination','commissionAccount','customer'].forEach(id=>$(id).onchange=previewTx);$('saveTx').onclick=saveTx;$('syncBtn').onclick=()=>syncNow(true);$('clearRejectedBtn').onclick=clearRejected;$('logoutBtn').onclick=logout;$('refreshHistory').onclick=loadHistory;$('historyOp').onchange=loadHistory;$('historyStatus').onchange=loadHistory;$('loadStatement').onclick=loadStatement;$('loadReport').onclick=loadReport;$('refreshShift').onclick=loadShift;$('closeShiftBtn').onclick=closeShift;$('themeBtn').onclick=()=>setTheme(document.body.classList.contains('dark')?'light':'dark');
document.querySelectorAll('.commission-shortcuts button').forEach(b=>b.onclick=()=>{$('commission').value=b.dataset.c;previewTx()});
window.addEventListener('online',()=>syncNow(false));window.addEventListener('offline',()=>setNet(false));window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;$('installBtn').textContent='تثبيت التطبيق'});$('installBtn').onclick=async()=>{if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null}else $('installHelp').classList.toggle('hidden')};
async function recoverConnection(){try{let h=await req('/api/v1/health');setNet(!!h.ok);if($('syncLog'))$('syncLog').textContent='API: '+location.origin+' | Health: OK | '+(h.api_version||'');if(h.ok&&state.token)await startApp();return !!h.ok}catch(e){setNet(false);if($('syncLog'))$('syncLog').textContent='API: '+location.origin+' | ERROR: '+e.message;return false}}
try{state.lastResults=JSON.parse(localStorage.mt_last_results||'[]')}catch{}
setTheme(localStorage.mt_theme||'dark');
// Force the newest mobile shell after an update; stale service-worker assets were the cause of false Offline state on some phones.
if('serviceWorker' in navigator){navigator.serviceWorker.getRegistrations().then(rs=>Promise.all(rs.map(r=>r.unregister()))).catch(()=>{})}
if(state.token)recoverConnection();else recoverConnection();


async function loadMobileDashboard(){try{let d=await req('/api/v2/mobile/dashboard');if($('totalBalance'))$('totalBalance').textContent=money(d.total_balance_fils);if($('serverState'))$('serverState').textContent='متصل • '+d.today_count+' عملية اليوم';return d}catch(e){return null}}

// ===== V7.50 Sync + Mobile Mega =====
function renderCustomerList(){
  if(!$('customersList'))return;
  let q=($('customerSearch')?.value||'').trim().toLowerCase();
  let rows=(state.customers||[]).filter(c=>!q||String(c.name||'').toLowerCase().includes(q)||String(c.phone||'').includes(q));
  let total=(state.customers||[]).reduce((s,c)=>s+Math.max(0,Number(c.debt_balance_fils||0)),0);
  let count=(state.customers||[]).filter(c=>Number(c.debt_balance_fils||0)>0).length;
  if($('debtTotal'))$('debtTotal').textContent=money(total);
  if($('debtCount'))$('debtCount').textContent=String(count);
  $('customersList').innerHTML=rows.map(c=>{
    let bal=Number(c.debt_balance_fils||0), lim=Number(c.debt_limit_fils||0);
    let near=lim>0 && bal>=lim*0.8;
    return `<button class="customer-row ${near?'near-limit':''}" onclick="loadCustomerStatement(${c.id})"><span><b>${esc(c.name)}</b><br><small>${esc(c.phone||'بدون هاتف')} — الحد ${money(lim)}</small></span><strong class="money">${money(bal)}</strong></button>`
  }).join('')||'<div class="muted">لا توجد نتائج</div>';
}
async function loadCustomerStatement(id){
  try{
    let d=await req('/api/v2/mobile/customers/'+id+'/statement');
    let c=d.customer||{};
    $('customerStatementTitle').textContent='كشف '+(c.name||'العميل');
    $('customerStatementSummary').innerHTML=`الدين الحالي <b class="money">${money(c.debt_balance_fils||0)}</b> — الحد ${money(c.debt_limit_fils||0)}${c.phone?`<br><small>${esc(c.phone)}</small>`:''}`;
    $('customerStatementList').innerHTML=(d.transactions||[]).slice().reverse().map(t=>`<div class="row"><div><b>#${t.id} ${esc(t.op_type)}</b><br><small>${new Date(t.created_at).toLocaleString('ar-JO')}${t.details?' — '+esc(t.details):''}</small></div><div class="money">${t.delta_fils>=0?'+':''}${money(t.delta_fils)}<br><small>الرصيد ${money(t.balance_fils)}</small></div></div>`).join('')||'<div class="muted">لا توجد حركات دين</div>';
    $('customerStatementBox').classList.remove('hidden');
    $('customerStatementBox').scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){toast(e.message)}
}
async function loadSyncStatus(){
  if(!state.token)return;
  try{
    let d=await req('/api/v2/mobile/sync-status?device_id='+encodeURIComponent(deviceId()));
    if($('syncLag'))$('syncLag').textContent=String(d.lag||0);
    if($('deviceState'))$('deviceState').textContent=d.active?'فعال':'موقوف';
    if($('serverCursor'))$('serverCursor').textContent=String(d.server_cursor||0);
    if($('pendingPull'))$('pendingPull').textContent=String(d.lag||0);
    if($('lastSeen'))$('lastSeen').textContent=d.last_seen_at?new Date(d.last_seen_at).toLocaleString('ar-JO'):'-';
  }catch(e){if($('syncLag'))$('syncLag').textContent='-'}
}
async function loadDevices(){
  if(!$('deviceAdminBox'))return;
  let admin=state.user?.role==='admin';
  $('deviceAdminBox').classList.toggle('hidden',!admin);
  if(!admin)return;
  try{
    let rows=await req('/api/v2/mobile/devices');
    $('devicesList').innerHTML=(rows||[]).map(d=>`<div class="device-card"><div><b>${esc(d.device_name||d.device_id)}</b><br><small>${esc(d.platform||'')} — ${esc(d.app_version||'')}</small><br><code>${esc(d.device_id)}</code></div><div><span class="tag ${d.active?'ok':'bad'}">${d.active?'فعال':'معطل'}</span><br><button class="${d.active?'danger':'secondary'} mini device-toggle" data-id="${esc(d.device_id)}" data-active="${d.active?'0':'1'}">${d.active?'تعطيل':'تفعيل'}</button></div></div>`).join('')||'<div class="muted">لا توجد أجهزة</div>';
    document.querySelectorAll('.device-toggle').forEach(b=>b.onclick=()=>setDeviceState(b.dataset.id,b.dataset.active==='1'));
  }catch(e){$('devicesList').innerHTML='<div class="muted">'+esc(e.message)+'</div>'}
}
async function setDeviceState(id,active){
  if(id===deviceId()&&!active&&!confirm('هذا هو الجهاز الحالي. إذا عطّلته ستتوقف مزامنته فوراً. متابعة؟'))return;
  else if(id!==deviceId()&&!confirm('تعطيل هذا الجهاز؟ لن تُحذف بياناته ويمكن تفعيله لاحقاً.'))return;
  try{
    await req('/api/v2/mobile/devices/'+encodeURIComponent(id)+'/state',{method:'POST',body:JSON.stringify({active})});
    toast(active?'تم تفعيل الجهاز':'تم تعطيل الجهاز');
    await loadDevices();
  }catch(e){toast(e.message)}
}
document.querySelectorAll('.amount-shortcuts button').forEach(b=>b.onclick=()=>{$('amount').value=b.dataset.a;previewTx();$('amount').focus()});
if($('customerSearch'))$('customerSearch').oninput=renderCustomerList;
if($('closeCustomerStatement'))$('closeCustomerStatement').onclick=()=>$('customerStatementBox').classList.add('hidden');
if($('refreshDevicesBtn'))$('refreshDevicesBtn').onclick=loadDevices;

// Refresh sync status after every successful online synchronization.
const _syncNowV750=syncNow;
syncNow=async function(show=true){
  await _syncNowV750(show);
  if(state.token){await loadSyncStatus().catch(()=>{});}
};
// Conservative foreground auto-sync: every 30 seconds only while page is visible and online.
setInterval(()=>{if(state.token&&navigator.onLine&&!document.hidden)syncNow(false)},30000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&state.token&&navigator.onLine)syncNow(false)});

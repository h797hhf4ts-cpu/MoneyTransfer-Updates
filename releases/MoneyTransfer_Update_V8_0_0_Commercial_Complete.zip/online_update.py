# -*- coding: utf-8 -*-
"""MoneyTransfer production online updater.

Stable channel uses one official source only.  The saved local source can no
longer make Stable silently follow an old feed.  GitHub Contents API is used
first (fresh repository content), with raw.githubusercontent.com as fallback.
"""
from pathlib import Path
import base64
import hashlib
import json
import os
import re
import tempfile
import time
from urllib.parse import urlparse, urlsplit, urlunsplit, parse_qsl, urlencode
from urllib.request import Request, urlopen

DATA_ROOT = Path(os.environ.get(
    "MONEYTRANSFER_DATA_DIR",
    str(Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MoneyTransfer" / "Data")
)).resolve()
UPDATE_ROOT = DATA_ROOT / "update_engine"
CONFIG_FILE = UPDATE_ROOT / "online_update.json"
DOWNLOAD_DIR = UPDATE_ROOT / "downloads"
DEFAULT_CHANNEL = "Stable"
OFFICIAL_RAW_FEED = "https://raw.githubusercontent.com/h797hhf4ts-cpu/MoneyTransfer-Updates/main/latest.json"
OFFICIAL_API_FEED = "https://api.github.com/repos/h797hhf4ts-cpu/MoneyTransfer-Updates/contents/latest.json?ref=main"
DEFAULT_FEED_URL = OFFICIAL_RAW_FEED
MAX_PACKAGE_BYTES = 250 * 1024 * 1024


def _cache_bust_url(url):
    parts = urlsplit(str(url).strip())
    pairs = list(parse_qsl(parts.query, keep_blank_values=True))
    pairs = [(k, v) for k, v in pairs if k != "_mt_cb"]
    pairs.append(("_mt_cb", str(int(time.time() * 1000))))
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(pairs), parts.fragment))


def _version_tuple(value):
    nums = [int(x) for x in re.findall(r"\d+", str(value))]
    return tuple((nums + [0, 0, 0, 0])[:4])


def is_newer(remote, current):
    return _version_tuple(remote) > _version_tuple(current)


def load_config():
    """Stable is always pinned to the official feed.

    We keep the config file only for channel metadata/backward compatibility;
    an old user-saved URL cannot override the production Stable source.
    """
    UPDATE_ROOT.mkdir(parents=True, exist_ok=True)
    return {"feed_url": OFFICIAL_RAW_FEED, "channel": DEFAULT_CHANNEL, "source_locked": True}


def save_config(feed_url, channel=DEFAULT_CHANNEL):
    """For Stable, persist the official URL regardless of supplied old URL."""
    UPDATE_ROOT.mkdir(parents=True, exist_ok=True)
    ch = str(channel or DEFAULT_CHANNEL).strip() or DEFAULT_CHANNEL
    value = OFFICIAL_RAW_FEED if ch.lower() == "stable" else str(feed_url).strip()
    data = {"feed_url": value, "channel": ch, "source_locked": ch.lower() == "stable"}
    CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def _validate_remote_url(url, allow_local=False):
    p = urlparse(str(url).strip())
    if p.scheme == "https" and p.netloc:
        return
    if allow_local and p.scheme == "http" and p.hostname in {"127.0.0.1", "localhost"}:
        return
    raise ValueError("رابط التحديث يجب أن يبدأ بـ https:// حفاظاً على أمان التحديث.")


def _validate_feed(data):
    if not isinstance(data, dict):
        raise ValueError("صيغة معلومات التحديث غير صحيحة.")
    required = {"product", "version", "package_url", "sha256"}
    missing = required - set(data)
    if missing:
        raise ValueError("معلومات التحديث ناقصة: " + ", ".join(sorted(missing)))
    if data.get("product") != "MoneyTransfer":
        raise ValueError("مصدر التحديث لا يخص MoneyTransfer.")
    package_url = str(data.get("package_url", "")).strip()
    _validate_remote_url(package_url, allow_local=True)
    digest = str(data.get("sha256", "")).lower().strip()
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("بصمة SHA-256 في معلومات التحديث غير صحيحة.")
    data = dict(data)
    data["package_url"] = package_url
    data["sha256"] = digest
    data.setdefault("channel", DEFAULT_CHANNEL)
    data.setdefault("notes_ar", [])
    return data


def _fetch_official_via_api(timeout=8.0):
    url = _cache_bust_url(OFFICIAL_API_FEED)
    req = Request(url, headers={
        "User-Agent": "MoneyTransfer-Updater/8.0.0",
        "Accept": "application/vnd.github+json",
        "Cache-Control": "no-cache, no-store, max-age=0",
        "Pragma": "no-cache",
    })
    with urlopen(req, timeout=timeout) as r:
        raw = r.read(2 * 1024 * 1024)
    envelope = json.loads(raw.decode("utf-8-sig"))
    encoded = str(envelope.get("content", "")).replace("\n", "")
    if not encoded:
        raise ValueError("GitHub API لم يُرجع محتوى latest.json.")
    feed_raw = base64.b64decode(encoded)
    data = json.loads(feed_raw.decode("utf-8-sig"))
    data = _validate_feed(data)
    data["_source"] = "github-api"
    data["_feed_sha"] = str(envelope.get("sha", ""))
    return data


def _fetch_raw(url, timeout=8.0):
    _validate_remote_url(url, allow_local=True)
    request_url = _cache_bust_url(url)
    req = Request(request_url, headers={
        "User-Agent": "MoneyTransfer-Updater/8.0.0",
        "Accept": "application/json",
        "Cache-Control": "no-cache, no-store, max-age=0",
        "Pragma": "no-cache",
    })
    with urlopen(req, timeout=timeout) as r:
        raw = r.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise ValueError("ملف معلومات التحديث أكبر من الحد المسموح.")
    data = _validate_feed(json.loads(raw.decode("utf-8-sig")))
    data["_source"] = "raw"
    return data


def fetch_feed(feed_url=None, timeout=8.0):
    # Production Stable: repository API first, official raw fallback.
    try:
        return _fetch_official_via_api(timeout=timeout)
    except Exception as api_exc:
        try:
            return _fetch_raw(OFFICIAL_RAW_FEED, timeout=timeout)
        except Exception as raw_exc:
            raise RuntimeError(f"تعذر قراءة مصدر التحديث الرسمي. GitHub API: {api_exc}; Raw: {raw_exc}")


def check_update(feed_url, current_version, channel=DEFAULT_CHANNEL, timeout=8.0):
    feed = fetch_feed(feed_url, timeout=timeout)
    remote_channel = str(feed.get("channel", DEFAULT_CHANNEL)).strip().lower()
    wanted_channel = str(channel or DEFAULT_CHANNEL).strip().lower()
    if wanted_channel and remote_channel != wanted_channel:
        return {"available": False, "reason": "channel", "feed": feed,
                "current_version": str(current_version), "remote_version": str(feed.get("version", ""))}
    newer = is_newer(feed.get("version"), current_version)
    return {"available": newer, "reason": "newer" if newer else "current", "feed": feed,
            "current_version": str(current_version), "remote_version": str(feed.get("version", ""))}


def download_package(feed, progress=None, timeout=20.0):
    url = str(feed["package_url"])
    expected = str(feed["sha256"]).lower()
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    safe_version = re.sub(r"[^0-9A-Za-z._-]+", "_", str(feed.get("version", "update")))
    final_path = DOWNLOAD_DIR / f"MoneyTransfer_Update_{safe_version}.zip"
    fd, tmp_name = tempfile.mkstemp(prefix="moneytransfer_update_", suffix=".zip", dir=str(DOWNLOAD_DIR))
    os.close(fd)
    tmp_path = Path(tmp_name)
    h = hashlib.sha256()
    total = 0
    try:
        req = Request(_cache_bust_url(url), headers={"User-Agent": "MoneyTransfer-Updater/8.0.0", "Accept": "application/zip,*/*", "Cache-Control":"no-cache"})
        with urlopen(req, timeout=timeout) as r, open(tmp_path, "wb") as out:
            length = r.headers.get("Content-Length")
            expected_size = int(length) if length and length.isdigit() else None
            if expected_size and expected_size > MAX_PACKAGE_BYTES:
                raise ValueError("حزمة التحديث أكبر من الحد المسموح.")
            while True:
                chunk = r.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_PACKAGE_BYTES:
                    raise ValueError("حزمة التحديث أكبر من الحد المسموح.")
                out.write(chunk); h.update(chunk)
                if progress: progress(total, expected_size)
        actual = h.hexdigest().lower()
        if actual != expected:
            raise ValueError("فشل التحقق من SHA-256. تم إلغاء التحديث لحماية البرنامج.")
        if final_path.exists(): final_path.unlink()
        tmp_path.replace(final_path)
        return final_path
    except Exception:
        try: tmp_path.unlink(missing_ok=True)
        except Exception: pass
        raise
